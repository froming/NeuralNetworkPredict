# dice2cry

> 分类：Crypto

## 题目描述

Web + Crypto 结合。cookie 中放 RSA 信息，存在文件泄露，通过参数绕过 + RSA mod 3 oracle 攻击还原明文。

## 考察知识点

- PHP 参数名绕过（`this[is.able` 绕过点变下划线）
- RSA Least Significant Bit Oracle（推广到 mod 3）

## 解法

1. 访问题目，cookie 里放有 RSA 信息（c、n、e），且存在文件泄露 `/abi.php.bak`。
2. 传递参数 `$_POST['this_is.able']`，但点会被替换成下划线，用 `this[is.able` 绕过。
3. 密码学部分：将 RSA LSB Oracle 攻击推广到 mod 3 情况：

```python
import requests, json
from libnum import n2s
from fractions import Fraction
from Crypto.Util.number import *

def give_result_of_mod3(mm):
    data = {'this[is.able': str(mm)}
    r = requests.post(url=url, data=data, cookies=Cookie)
    return int(json.loads(r.content)['num'])

def hack(c, e, n):
    R = n % 3
    j = 1
    exp3 = 3
    length = n
    low_bound = Fraction(0, 1)
    while length > 1:
        tmp_c = (pow(exp3, e, n) * c) % n
        r = give_result_of_mod3(tmp_c)
        k = (-r * inverse(R, 3)) % 3
        low_bound += Fraction(k * n, exp3)
        exp3 *= 3
        length = length // 3
        j += 1
    return int(low_bound)

res = hack(c, e, n)
print(n2s(res))
```

## 参考答案

`flag{92ab3055092aad3e1856481091`

## 来源

- 作者：一叶飘零 | https://www.4hou.com/posts/yMvW
