# upload（强网先锋）

> 分类：Misc

## 题目描述

pcap 流量分析 + steghide 图片隐写。从流量中导出图片，steghide 提取隐藏文件。

## 考察知识点

- 流量分析（导出文件）
- steghide 隐写（爆破密码）

## 解法

1. 下载 `.pcap` 附件，追踪 TCP 流发现文件头和 filename，是 JPEG 图片。
2. 右键导出分组字节流，后缀 jpg，看到一张图片。
3. 图片文件名提示隐写软件 steghide，用 `steghide info a.jpg` 发现需要密码。
4. 暴力破解密码（脚本遍历字典），得密码 `123456`。
5. `steghide extract -sf a.jpg` 提取 flag.txt，cat 查看 flag。

## 参考答案

（flag 通过 steghide 提取 flag.txt）

## 来源

- 作者：洛柒尘 | https://blog.csdn.net/ewyherayh/article/details/108192265
