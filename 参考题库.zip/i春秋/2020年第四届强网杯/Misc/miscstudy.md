# miscstudy

> 分类：Misc

## 题目描述

多层 Misc 题。TLS 解密 + PNG 隐写 + base64/二进制/二维码 + 百度网盘 + JPEG 隐写 + CRC32 碰撞 + 盲水印 + SNOW 隐写，flag 分七部分拼接。

## 考察知识点

- TLS 流量解密
- PNG IDAT 提取
- base64/二进制转二维码
- steghide/JPHS（JPEG 隐写）
- CRC32 碰撞
- 盲水印
- SNOW 隐写

## 解法

1. Wireshark 过滤 HTTP，找到链接 `http://39.99.247.28/fonts/1`，访问获得 flag 前两部分。保存页面，设置环境变量 `SSLKEYLOGFILE` 指向该文件，Wireshark TLS 首选项导入 key 解密 TLS。
2. TLS 解密后隐藏了一张图片，winhex 打开，末尾 base64 解密得 flag 第三部分。
3. 图片最下面 4 组 IDAT，去掉头和尾，合并前三组得 base64，解码得二进制，用 PIL 脚本转二维码。
4. 二维码扫码得百度网盘链接，下载解压得图片，steghide 爆破密码 `power123`，JPHS 提取得 flag 第四部分（内含新百度网盘链接）。
5. 下载得到 level5.zip、level6.zip、level7.zip，三个文本文件不超过 5 字节，用 CRC32 碰撞脚本爆破 level6.zip，得 flag 第六部分 `Level6_isready`。
6. 用 level5.zip 中的 1.png 做明文密钥，Advanced Archive Password Recovery 明文爆破 level7.zip。
7. 解压得 4.png 和 5.png（分辨率相同大小不同），盲水印分离得 flag 第七部分 `level7ishere`。
8. 图中有网址 `http://39.99.247.28/final_level`，页面复制了百度，源码注释的空格/TAB 是 SNOW 隐写，用 SNOW 工具破解（密码 `no one can find me`）得最后一部分。

拼接所有部分得 flag。

## 参考答案

`flag{level1_begin_and_level2_is_comelevel3_start_itlevel4_here_alllevel5_is_aaalevel6_isreadylevel7isherethe_misc_examaaaaaaa_!!!}`

## 来源

- 作者：洛柒尘 | https://blog.csdn.net/ewyherayh/article/details/108192265
