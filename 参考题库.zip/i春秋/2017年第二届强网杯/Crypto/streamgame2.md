# streamgame2

> 分类：Crypto

## 题目描述

LFSR 题，flag 长度 27 位（中间 21 位），爆破还原。

## 考察知识点

- LFSR
- 爆破

## 解法

与 streamgame1 相同，只是 mask 改为 `0x100002`，flag 中间 21 位。遍历爆破：

```python
def lfsr(R, mask):
    output = (R << 1) & 0xffffff
    i = (R & mask) & 0xffffff
    lastbit = 0
    while i != 0:
        lastbit ^= (i & 1)
        i = i >> 1
    output ^= lastbit
    return (output, lastbit)

mask = 0x100002
for R in range(0, 0b111111111111111111111):
    tmpr = R
    for i in range(12):
        tmp = 0
        for j in range(8):
            (R, out) = lfsr(R, mask)
            tmp = (tmp << 1) ^ out
        # 匹配 key（0xB2 0xE9 0x0E 0x13 0xA0）
```

## 参考答案

（flag 通过 LFSR 爆破得到）

## 来源

- 作者：tinyfisher | https://www.freebuf.com/articles/network/166979.html
