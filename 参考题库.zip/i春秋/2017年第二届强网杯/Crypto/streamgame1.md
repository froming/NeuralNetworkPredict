# streamgame1

> 分类：Crypto

## 题目描述

LFSR 线性反馈移位寄存器，flag 长度 25 位（格式 flag{}，中间 19 位），爆破还原。

## 考察知识点

- LFSR（线性反馈移位寄存器）
- 爆破

## 解法

算法为 LFSR（mask 0b1010011000100011100），flag 中间 19 位，直接爆破遍历：

```python
def lfsr(R, mask):
    output = (R << 1) & 0xffffff
    i = (R & mask) & 0xffffff
    lastbit = 0
    while i != 0:
        lastbit ^= (i & 1)
        i = i >> 1
    output ^= lastbit
    return (output, lastbit)

mask = 0b1010011000100011100
for R in range(0, 0b1111111111111111111):
    tmpr = R
    for i in range(12):
        tmp = 0
        for j in range(8):
            (R, out) = lfsr(R, mask)
            tmp = (tmp << 1) ^ out
        # 比较 key 的各位，匹配则继续，前 5 组（0x55 0x38 0xF7 0x42 0xC1）匹配即得 tmpr
```

tmpr 的二进制形式就是 flag 中间部分。

## 参考答案

（flag 通过 LFSR 爆破得到）

## 来源

- 作者：tinyfisher | https://www.freebuf.com/articles/network/166979.html
