# streamgame4

> 分类：Crypto

## 题目描述

NLFSR（非线性反馈移位寄存器），flag 长度 21 位，爆破还原。

## 考察知识点

- NLFSR（非线性反馈移位寄存器）
- 爆破

## 解法

换成 NLFSR（mask 0b110110011011001101110），flag 中间 21 位，遍历爆破：

```python
def nlfsr(R, mask):
    output = (R << 1) & 0xffffff
    i = (R & mask) & 0xffffff
    lastbit = 0
    changesign = True
    while i != 0:
        if changesign:
            lastbit &= (i & 1)
            changesign = False
        else:
            lastbit ^= (i & 1)
        i = i >> 1
    output ^= lastbit
    return (output, lastbit)

mask = 0b110110011011001101110
for R in range(0, 0b111111111111111111111):
    tmpr = R
    for i in range(12):
        tmp = 0
        for j in range(8):
            (R, out) = nlfsr(R, mask)
            tmp = (tmp << 1) ^ out
        # 匹配 key（0xD1 0xD9 0x40 0x43 0x93）
```

## 参考答案

（flag 通过 NLFSR 爆破得到）

## 来源

- 作者：tinyfisher | https://www.freebuf.com/articles/network/166979.html
