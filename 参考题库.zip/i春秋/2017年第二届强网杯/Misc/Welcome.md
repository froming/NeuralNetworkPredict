# Welcome

> 分类：Misc

## 题目描述

bmp 图片隐写，用 Stegsolve 的 Stereogram 功能找到 flag。

## 考察知识点

- 图片隐写（Stegsolve Stereogram）

## 解法

1. 下载文件，winhex 查看文件头为 `424D`（BMP 文件）。
2. notepad 打开无 flag，binwalk 无隐藏文件。
3. 用 Stegsolve 打开，Stereogram 不断设置 offset，当 offset 为 80 时出现 flag。

## 参考答案

（flag 通过 Stegsolve Stereogram offset=80 获得）

## 来源

- 作者：tinyfisher | https://www.freebuf.com/articles/network/166979.html
