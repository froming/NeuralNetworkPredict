# Nonstandard

> 分类：Reverse

## 题目描述

VC 程序，无壳，运行后提示输入 flag。关键函数 sub_401480 校验。

## 考察知识点

- IDA 逆向
- 算法逆向

## 解法

1. PEiD 查壳发现无壳，VC 程序。
2. IDA 载入，搜索关键字符串，找到关键函数 `sub_401480`。
3. 输入经过 `sub_401480` 校验，逆向算法得到 flag。

## 参考答案

（flag 通过逆向 sub_401480 得到，见原博客 iqiqiya）

## 来源

- 作者：iqiqiya | https://iqiqiya.blog.csdn.net/article/details/81872485
