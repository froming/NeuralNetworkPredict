# simplecheck

> 分类：Reverse

## 题目描述

Android APK 逆向。输入 flag，经二次方程校验，爆破还原。

## 考察知识点

- Android APK 逆向
- 爆破

## 解法

1. 运行 apk，输入 flag 错误返回"sorry its wrong"。
2. 反编译关键函数 `a(paramString)`，需返回 true。

关键逻辑：

```java
if (paramString.length() != b.length) return false;  // flag 长度 = 34
// arrayOfInt[0] = 0，flag 赋值到 arrayOfInt[1] ~ arrayOfInt[34]
for (int m = 0; m < c.length; m++) {
    // 需满足：
    // a[m] == b[m]*arrayOfInt[m]^2 + c[m]*arrayOfInt[m] + d[m]
    // 且 a[m+1] == b[m]*arrayOfInt[m+1]^2 + c[m]*arrayOfInt[m+1] + d[m]
}
```

爆破（遍历 ASCII 32-126）：

```python
a = [0, 146527998, 205327308, ...]
b = [13710, 46393, 49151, ...]
c = [38129, 57355, 22538, ...]
d = [0, -341994984, -370404060, ...]

flag = ""
for m in range(1, 34):
    for f1 in range(32, 127):
        if (a[m] == b[m-1]*f1*f1 + c[m-1]*f1 + d[m-1]) and (a[m] == b[m]*f1*f1 + c[m]*f1 + d[m]):
            flag += chr(f1)
            break
print(flag + "}")
```

## 参考答案

（flag 通过二次方程爆破得到）

## 来源

- 作者：tinyfisher | https://www.freebuf.com/articles/network/166979.html
