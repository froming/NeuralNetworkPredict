# web签到

> 分类：Web

## 题目描述

三道 md5 判断关卡（==弱类型、===强类型、string 强转），需逐步绕过。

## 考察知识点

- PHP md5 弱类型比较（0e 开头）
- md5 数组绕过（null）
- md5 碰撞（fastcoll）

## 解法

**第一关**：`param1 != param2 && md5(param1) == md5(param2)`（== 弱类型）。

- 绕过方式1：`param1=240610708&param2=QNKCDZO`（两者 md5 都是 0e 开头，科学计数法比较为 0）。
- 绕过方式2：`param1[]=1&param2[]=2`（md5(数组) 报错返回 null，null==null）。

**第二关**：`param1 !== param2 && md5(param1) === md5(param2)`（=== 强类型）。

- 只能用数组绕过：`param1[]=1&param2[]=2`（null===null）。

**第三关**：强判断 + 强制 string 类型，只能 md5 碰撞。

- 用 fastcoll 生成两个 md5 一致的文件，内容 url 编码后传入。

## 参考答案

（flag 通过三关 md5 判断获得）

## 来源

- 作者：tinyfisher | https://www.freebuf.com/articles/network/166979.html
