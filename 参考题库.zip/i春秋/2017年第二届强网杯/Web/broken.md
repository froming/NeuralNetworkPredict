# broken

> 分类：Web

## 题目描述

JSFuck 编码题。进入有 file 链接，点进去是一串 JSFuck 代码，但代码损坏（缺少 `]`）。

## 考察知识点

- JSFuck 编码/解码

## 解法

1. 点进 file 链接，得到一串 JSFuck（`[]()!+` 组成的代码）。
2. 丢在线网站解密报错，说明格式损坏。
3. 复制到浏览器控制台，末尾加 `]` 提示语法错误。删除最后的 `()`，再加上 `]`，运行得到 `Array [ Array[1] ]`。
4. 点击 `Array[1]` 即可看到 flag。

## 参考答案

（flag 通过 JSFuck 解码后点击数组元素获得）

## 来源

- 作者：Pr0ph3t | https://blog.pr0ph3t.com/posts/%E5%BC%BA%E7%BD%91%E6%9D%AF-Web-Writeup/
- 作者：烟敛寒林o | https://blog.csdn.net/dyw_666666/article/details/89874060
