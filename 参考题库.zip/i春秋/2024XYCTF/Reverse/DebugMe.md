# DebugMe

> 分类：Reverse

## 题目描述
Android 逆向题。这题附加调试器即可完成，但 Android Studio 即使开了全局调试，也需要 apk 自身开启调试功能，因此需要重新打包 apk；而 Android 版本过高还会出现对齐问题导致安装不上。

## 考察知识点
- Android 动态调试
- apk 重打包与 debuggable 配置

## 解法
原文只有简述：

> 这题好像附加调试器即可，但是 android studio 即使开了全局调试，也需要 apk 开启调试功能，结果我还得重新打包 apk，android 版本太高还有对齐问题安装不上，总之也算坐牢了。

即：给 apk 开启调试（debgguable）后重新打包，附加调试器动态分析即可得到 flag。

## 参考答案
（未给出）

## 来源
- 作者：jht3 | https://jht3qaq.github.io/2024/04/26/XYCTF2024-Writeup/
