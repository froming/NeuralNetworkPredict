# What's this

> 分类：Reverse

## 题目描述
Lua 逆向题。程序其实是 Lua 脚本，用 unluac 反编译后得到 base64 + 字符替换 + reverse + 加 3 + xor 8 的加密链，逆向还原即可。

## 考察知识点
- Lua 逆向（unluac）
- base64 / 字符替换 / reverse / xor 组合还原

## 解法
1. DIE 提示是 Lua，用 unluac 反编译：

```
java -jar unluac_2023_12_24.jar "what's this (1)" >> out.txt
```

2. 反编译得到加密链：

```lua
require("base64")
obfuscated_output = to_base64(output)
obfuscated_output = string.reverse(obfuscated_output)
obfuscated_output = string.gsub(obfuscated_output, "g", "3")
obfuscated_output = string.gsub(obfuscated_output, "H", "4")
obfuscated_output = string.gsub(obfuscated_output, "W", "6")
if obfuscated_output == "==AeuFEcwxGPuJ0PBNzbC16ctFnPB5DPzI0bwx6bu9GQ2F1XOR1U" then
  print("You get the flag.")
end
```

即 `output -> b64 -> 替换 -> reverse -> enc`。

3. 向上找 `output` 的赋值：

```lua
for i = 1, string.len(flag) do
  temp = string.byte(value, i)
  temp = string.char(temp + 3)
  output = output .. temp
end
```

即 `value -> +3 -> output`。

4. 再向上找 `value` 的赋值：

```lua
while true do
  local temp = string.byte(flag, i)
  temp = string.char(Xor(temp, 8) % 256)
  value = value .. temp
  i = i + 1
  if i > string.len(flag) then break end
end
```

即 `flag -> xor 8 -> value`。

5. 用 CyberChef 依次执行：Reverse → 替换回 3→g、4→H、6→W → From Base64 → 减 3 → XOR 8，得到 flag。

## 参考答案
（见截图 / CyberChef 输出，原文未直接给出 flag 字符串）

## 来源
- 作者：jht3 | https://jht3qaq.github.io/2024/04/26/XYCTF2024-Writeup/
