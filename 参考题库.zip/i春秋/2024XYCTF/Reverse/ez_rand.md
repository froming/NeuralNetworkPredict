# ez_rand

> 分类：Reverse

## 题目描述
随机数逆向题。`srand` 的种子使用 int16（0~0xFFFF），范围极小，直接爆破种子还原 flag。

## 考察知识点
- rand/srand 逆向
- 种子爆破

## 解法
`srand` 用的 int16，这不爆破？爆破脚本如下：

```c
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
const unsigned char enc[] = {0x5D,0x0C,0x6C,0xEA,0x46,0x19,0xFC,0x34,0xB2,0x62,0x23,0x07,0x62,0x22,0x6E,0xFB,0xB4,0xE8,0xF2,0xA9,0x91,0x12,0x21,0x86,0xDB,0x8E,0xE9,0x43,0x4D};
int main(){
    char ans[0x100]={0};
    for(int i=0;i<=0xFFFF;i++){
        srand(i);
        for(int i=0;i<29;i++){
            ans[i] = enc[i]^(rand()%0xFF);
        }
        if(strncmp(ans,"XYCTF",5)==0)break;
        if(strncmp(ans,"xyctf",5)==0)break;
        if(strncmp(ans,"flag",4)==0)break;
    }
    printf(ans);
    return 0;
}
```

## 参考答案
XYCTF{R@nd_1s_S0_S0_S0_easy!}

## 来源
- 作者：jht3 | https://jht3qaq.github.io/2024/04/26/XYCTF2024-Writeup/
