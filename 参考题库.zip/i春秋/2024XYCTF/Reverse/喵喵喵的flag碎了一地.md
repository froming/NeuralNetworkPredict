# 喵喵喵的flag碎了一地

> 分类：Reverse

## 题目描述
IDA 静态分析入门题。flag 被拆散分布在程序中，通过 string_view 与函数分析把碎片拼起来还原。

## 考察知识点
- IDA 静态分析
- string_view 逆向
- 汇编阅读

## 解法
使用 IDA 观察 string_view 和 func，跟踪 func 中的赋值与汇编逻辑，把散落的 flag 碎片拼出来。

## 参考答案
flag{My_fl@g_h4s_br0ken_4parT_Bu7_Y0u_c@n_f1x_1t!}

## 来源
- 作者：jht3 | https://jht3qaq.github.io/2024/04/26/XYCTF2024-Writeup/
