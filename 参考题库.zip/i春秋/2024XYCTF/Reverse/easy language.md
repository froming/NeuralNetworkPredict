# easy language

> 分类：Reverse

## 题目描述
易语言逆向题。程序使用 AES-ECB 加密，且带调试器检测。需绕过 debuger 检测，从比较函数附近提取密文与 key，再解密。

## 考察知识点
- 易语言逆向
- AES-ECB 解密
- 反调试绕过

## 解法
1. 装易语言插件可补全函数。看到有 AES-ECB 加密，以及字符集比较逻辑。
2. 绕过 debuger 检测：在检测函数处改变 RIP 跳过即可。
3. 在比较函数附近的内存找到 base64 编码后的密文字符串。
4. 在 AES 加密函数附近找到 key，动调发现 IV 为 0。
5. AES-ECB 解密 + base64 解码得到 flag。

## 参考答案
（见截图，原文未直接给出 flag 字符串）

## 来源
- 作者：jht3 | https://jht3qaq.github.io/2024/04/26/XYCTF2024-Writeup/
