# baby unity

> 分类：Reverse

## 题目描述
Unity IL2CPP 逆向题。程序经过 UPX 加壳，脱壳后使用 Il2CppDumper 还原符号，加密函数为 base64 之后再进行一次异或。

## 考察知识点
- UPX 脱壳
- Il2CppDumper / IL2CPP 逆向
- base64 与 xor 还原

## 解法
1. 先用 UPX 脱壳。
2. 使用 Il2CppDumper 能生成一个 26MB 的 `script.json`，再配合 Il2CppDumper 自带的 `ida_with_struct_py3.py` 把符号加载进 IDA。
3. 观察加密函数，可以看到操作就是 base64 之后 xor 了一下，随后还原异或即可解出 flag。

## 参考答案
（见截图，原文未直接给出 flag 字符串）

## 来源
- 作者：jht3 | https://jht3qaq.github.io/2024/04/26/XYCTF2024-Writeup/
