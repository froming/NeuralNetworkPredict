# Findme

> 分类：Reverse

## 题目描述
算法还原题。程序通过自定义密码表（RC4 风格）+ random 插值加密一个文件，还原后得到 GIF，打开 GIF 即可看到 flag。

## 考察知识点
- 密码表生成（RC4 风格）还原
- random 插值跳过
- 文件格式识别

## 解法
1. 程序生成密码表（作者直接抄了一遍生成代码），配合 random 插值，重新跑一遍代码还原即可。

关键代码（生成密码表 + 解密还原）：

```c
#include<stdio.h>
#include<string.h>
#include<stdint.h>
#include<stdlib.h>
#include<assert.h>
uint8_t byte_14001D960[512];
const char* Str = "Find_Doraemon";
uint8_t byte_14001D201;
void init(){
  char v9[532];
  int j;
  int v7 = strlen(Str);
  int v11 = 0;
  int v12 = 0;
  memset(v9, 0, 0x200);
  for ( j = 0; j < 0x200; ++j )
  {
    byte_14001D960[j] = -(char)j;
    v9[j] = Str[j % v7];
  }
  while ( v11 < 512 )
  {
    v12 = ((unsigned __int8)v9[v11] + byte_14001D960[v11] + v12) % 512;
    byte_14001D201 = byte_14001D960[v11];
    byte_14001D960[v11] = byte_14001D960[v12];
    byte_14001D960[v12] = byte_14001D201;
    ++v11;
  }
}

int main(){
	int v13=0,v14=0,v11=0,v12,i,v8;
	uint8_t v15,v16;
	init();
	for(int i=0;i<512;i++){
		if(i%16==0)printf("\n");
		printf("%02X ",byte_14001D960[i]);
	}
	FILE* fin=fopen(R"(C:\Users\jht3\Downloads\Findme\Doraemon1)","rb");
	FILE* fout=fopen(R"(C:\Users\jht3\Downloads\Findme\Doraemon3)","wb");
	while(!feof(fin)){
		v13 = (v13 + 1) % 512;
		v14 = (byte_14001D960[v13] + v14) % 512;
		byte_14001D201 = byte_14001D960[v13];
		byte_14001D960[v13] = byte_14001D960[v14];
		byte_14001D960[v14] = byte_14001D201;
		v16 = byte_14001D960[(unsigned __int8)((byte_14001D960[v14] + byte_14001D960[v13]) % 512)];
		v15 = v16 ^ fgetc(fin);
      	fputc(v15, fout);
      	srand(byte_14001D960[v11 % 512]);
		v12 = rand() % 4;
		for ( i = 0; i < v12; ++i )
		{
			v8 = rand();
			if(!feof(fin))assert(v8 % 0x100==fgetc(fin));
			else break;
		}
		++v11;
	}
	fclose(fin);
	fclose(fout);
	return 0;
}
```

2. 得到 `Dorameon3` 后，查看代码发现读入一个 xor key，再做一次 xor 14。观察到有 `Doraemon` 字符循环，猜测 xor key 就是 `Doraemon`，填充后还原。
3. CyberChef 识别出还原结果是 GIF，打开即可看到 flag。

## 参考答案
（见截图，原文未直接给出 flag 字符串）

## 来源
- 作者：jht3 | https://jht3qaq.github.io/2024/04/26/XYCTF2024-Writeup/
