# ez_enc

> 分类：Reverse

## 题目描述
加密逆向题。核心加密为 `inp[i] = key[i%6] ^ (inp[i+1] + (inp[i] % 20))` 形式的异或加法，直接使用 z3 求解还原输入。

## 考察知识点
- z3 约束求解
- 异或/加法混合加密还原

## 解法
手算没算明白，直接用 z3 秒了：

```python
from z3 import *

inp = [BitVec(f'inp_{i}',8) for i in range(34)]

key = [ord(i) for i in "IMouto"]
for i in range(len(inp)-1):
    inp[i]= key[i%6]^(inp[i+1]+(inp[i]%20))

ans = [0x27,0x24,0x17,0x0B,0x50,0x03,0xC8,0x0C,0x1F,0x17,0x36,0x55,0xCB,0x2D,0xE9,0x32,0x0E,0x11,0x26,0x02,0x0C,0x07,0xFC,0x27,0x3D,0x2D,0xED,0x35,0x59,0xEB,0x3C,0x3E,0xE4,0x7D]

s = Solver()
for i in range(len(inp)):
    s.add(ans[i]==inp[i])

print(s.check())
ans = s.model()
ans = dict(zip([str(i) for i in ans],[ans[i] for i in ans]))
for i in range(34):
    print(chr(ans[f"inp_{i}"].as_long()),end="")
```

## 参考答案
（未给出，原文未贴出脚本输出结果）

## 来源
- 作者：jht3 | https://jht3qaq.github.io/2024/04/26/XYCTF2024-Writeup/
