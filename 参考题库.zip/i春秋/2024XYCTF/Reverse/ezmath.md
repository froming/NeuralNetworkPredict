# ezmath

> 分类：Reverse

## 题目描述
Python 打包（PyInstaller）逆向题。通过 pyinstxtractor 拆包 + pycdc 反编译还原源码，得到一个巨大的多项式等式，整理后即可得到 flag。

## 考察知识点
- PyInstaller 拆包（pyinstxtractor）
- pyc 反编译（pycdc）
- 数学公式整理 / 方程求解

## 解法
1. 拆包：

```
python pyinstxtractor.py ezmath.exe
```

2. 用 pycdc 反编译得到一个大表达式，整理后形如：

```
(((((((((((((((((((((flag[23]*flag[23]) + (flag[12]*flag[12]) + ... )) + 297412 == 0
```

3. 该式直接用 z3 跑不通（要用 Real 类型才能跑通），但观察到每一个 `flag[i]` 都有 `flag[i]*flag[i] - flag[i]*num` 的形式，手动整理出各位置的 num：

```python
diff = [176,178,134,168,140,246,226,110,174,178,142,230,198,170,234,224,232,168,178,176,212,220,212,150,222,242,170,168,150,232,142,250]
```

4. 其中 176、178 明显对应 `X`、`Y`，把每个数除以 2 即得到 ASCII 码，还原出 flag。

## 参考答案
XYCTF{q7WYGscUuptTYXjnjKoyUTKtG}

## 来源
- 作者：jht3 | https://jht3qaq.github.io/2024/04/26/XYCTF2024-Writeup/
