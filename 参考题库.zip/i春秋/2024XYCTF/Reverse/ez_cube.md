# ez_cube

> 分类：Reverse

## 题目描述
魔方模拟逆向题。程序模拟三阶魔方，初始状态只有 3 个中心块被打乱，操作序列长度为 12 且只有 R/U/r/u 四种操作，通过爆破 + 剪枝找出还原操作序列。

## 考察知识点
- 魔方状态模拟
- 爆破与剪枝

## 解法
观察到长度只有 12，操作还只有 4 种，那就爆破，由于要求最简操作还可做剪枝：

```python
import itertools

chars = ["R", "U", "r", "u"]
length = 12
permutations = itertools.product(chars, repeat=length)
result = ["".join(p) for p in permutations if len(p) == length]
result = [
    i for i in result
    if not any([k in i for k in ["Rr","rR","Uu","uU","RRR","rrr","UUU","uuu"]])
]

def check(ans):
    RedFace = ["Red"] * 9
    BlueFace = ["Blue"] * 9
    GreenFace = ["Green"] * 9
    OrangeFace = ["Orange"] * 9
    YellowFace = ["Yellow"] * 9
    WhiteFace = ["White"] * 9

    BlueFace[1] = "Red"
    RedFace[1] = "Green"
    GreenFace[1] = "Blue"

    def R():
        v1 = RedFace[2]; v2 = RedFace[5]; v3 = RedFace[8]
        RedFace[2] = WhiteFace[2]; RedFace[5] = WhiteFace[5]; RedFace[8] = WhiteFace[8]
        WhiteFace[2] = OrangeFace[6]; WhiteFace[5] = OrangeFace[3]; WhiteFace[8] = OrangeFace[0]
        OrangeFace[0] = YellowFace[8]; OrangeFace[3] = YellowFace[5]; OrangeFace[6] = YellowFace[2]
        YellowFace[2] = v1; YellowFace[5] = v2; YellowFace[8] = v3
        v4 = GreenFace[1]; GreenFace[1] = GreenFace[3]; GreenFace[3] = GreenFace[7]; GreenFace[7] = GreenFace[5]; GreenFace[5] = v4
        v5 = GreenFace[0]; GreenFace[0] = GreenFace[6]; GreenFace[6] = GreenFace[8]; GreenFace[8] = GreenFace[2]; GreenFace[2] = v5

    def U():
        v1 = RedFace[0]; v2 = RedFace[1]; v3 = RedFace[2]
        RedFace[0] = GreenFace[0]; RedFace[1] = GreenFace[1]; RedFace[2] = GreenFace[2]
        GreenFace[0] = OrangeFace[0]; GreenFace[1] = OrangeFace[1]; GreenFace[2] = OrangeFace[2]
        OrangeFace[0] = BlueFace[0]; OrangeFace[1] = BlueFace[1]; OrangeFace[2] = BlueFace[2]
        BlueFace[0] = v1; BlueFace[1] = v2; BlueFace[2] = v3
        v4 = YellowFace[1]; YellowFace[1] = YellowFace[3]; YellowFace[3] = YellowFace[7]; YellowFace[7] = YellowFace[5]; YellowFace[5] = v4
        v5 = YellowFace[0]; YellowFace[0] = YellowFace[6]; YellowFace[6] = YellowFace[8]; YellowFace[8] = YellowFace[2]; YellowFace[2] = v5

    def r():
        v1 = RedFace[2]; v2 = RedFace[5]; v3 = RedFace[8]
        RedFace[2] = YellowFace[2]; RedFace[5] = YellowFace[5]; RedFace[8] = YellowFace[8]
        YellowFace[2] = OrangeFace[6]; YellowFace[5] = OrangeFace[3]; YellowFace[8] = OrangeFace[0]
        OrangeFace[0] = WhiteFace[8]; OrangeFace[3] = WhiteFace[5]; OrangeFace[6] = WhiteFace[2]
        WhiteFace[2] = v1; WhiteFace[5] = v2; WhiteFace[8] = v3
        v4 = GreenFace[1]; GreenFace[1] = GreenFace[5]; GreenFace[5] = GreenFace[7]; GreenFace[7] = GreenFace[3]; GreenFace[3] = v4
        v5 = GreenFace[0]; GreenFace[0] = GreenFace[2]; GreenFace[2] = GreenFace[8]; GreenFace[8] = GreenFace[6]; GreenFace[6] = v5

    def u():
        v1 = RedFace[0]; v2 = RedFace[1]; v3 = RedFace[2]
        RedFace[0] = BlueFace[0]; RedFace[1] = BlueFace[1]; RedFace[2] = BlueFace[2]
        BlueFace[0] = OrangeFace[0]; BlueFace[1] = OrangeFace[1]; BlueFace[2] = OrangeFace[2]
        OrangeFace[0] = GreenFace[0]; OrangeFace[1] = GreenFace[1]; OrangeFace[2] = GreenFace[2]
        GreenFace[0] = v1; GreenFace[1] = v2; GreenFace[2] = v3
        v4 = YellowFace[1]; YellowFace[1] = YellowFace[5]; YellowFace[5] = YellowFace[7]; YellowFace[7] = YellowFace[3]; YellowFace[3] = v4
        v5 = YellowFace[0]; YellowFace[0] = YellowFace[2]; YellowFace[2] = YellowFace[8]; YellowFace[8] = YellowFace[6]; YellowFace[6] = v5

    d = {"R": R, "U": U, "r": r, "u": u}
    for i in ans:
        d[i]()
    if all([
        all([i == "Red" for i in RedFace]),
        all([i == "Blue" for i in BlueFace]),
        all([i == "Green" for i in GreenFace]),
        all([i == "Orange" for i in OrangeFace]),
        all([i == "Yellow" for i in YellowFace]),
        all([i == "White" for i in WhiteFace]),
    ]):
        print(ans)

for res in result:
    res = ''.join(res)
    if any([i in res for i in ["Rr","rR","Uu","uU","RRR","rrr","UUU","uuu"]]):
        continue
    check(res)
```

## 参考答案
XYCTF{RuRURURuruRR}（脚本另有一解 `RuRURURururr`，见截图）

## 来源
- 作者：jht3 | https://jht3qaq.github.io/2024/04/26/XYCTF2024-Writeup/
