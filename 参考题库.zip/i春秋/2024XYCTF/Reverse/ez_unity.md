# ez unity

> 分类：Reverse

## 题目描述
Unity IL2CPP 逆向题。程序直接改了文件读取方式，无法 dump 原文件，使用 frida-il2cpp-bridge dump C# 结构，确定加密方法为 AES + base64。

## 考察知识点
- Frida / frida-il2cpp-bridge
- IL2CPP 结构 dump
- AES-CBC 解密与 base64

## 解法
1. 由于读取方式被修改，无法 dump 原文件，改用 frida-il2cpp-bridge dump C# 结构。
2. frida 使用：`frida -p 程序PID -l D:\ctf\frida-il2cpp-bridge-0.9.0\dist\index.js`，然后在控制台敲代码 dump C# 函数。
3. 根据 dump 结果找到 `Check` 类：

```csharp
// Assembly-CSharp
class Check : UnityEngine.MonoBehaviour
{
    System.Void Start(); // 0x0027d670
    System.Void Update(); // 0x0027d670
    System.Void OnClick(); // 0x0027d4e0
    System.Boolean CheckFlag(System.String input); // 0x0027d460
    static System.String AESEncrypt(System.String text, System.String key, System.String iv); // 0x0027d200
    static System.String AESDecrypt(System.String text, System.Byte[] key, System.Byte[] iv); // 0x0027d000
    System.Void .ctor(); // 0x0027d680
}
```

4. 动调找到加密后的 flag（AESEncrypt 最后一句话做的 base64）：

```
pNufkEIU9dHjKXYXWiFyrthHYFEfqJAWcPM/t8/zX1w=
```

5. AES 解密参数：

```
key: a216d5d34c2723f5
iv:  9f68268f755b1363
```

6. 解密得到 flag。

## 参考答案
XYCTF{IL2CPP_1s_intere5t1ng}

## 来源
- 作者：jht3 | https://jht3qaq.github.io/2024/04/26/XYCTF2024-Writeup/
