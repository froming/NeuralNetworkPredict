# Trustme

> 分类：Reverse

## 题目描述
Android 逆向题。程序在类加载时通过代理做了一层解密：从原 APK 尾部读取 4 字节大小，然后 xor 0xFF 解密出一个新的 APK（shell.apk），新 APK 内部又通过 SQL 查询数据库，创建数据库时再次使用 xor 0xFF 解密出 flag。

## 考察知识点
- Android 逆向 / APK 结构分析
- 类加载代理与动态解密
- xor 0xFF 简单加密还原
- SQLite 数据库

## 解法
观察 `Manifest` 发现类加载时注册了代理，跟入代理逻辑：

1. 代理创建了一个 `shell.apk`，并调用 `readDexFileFromApk` 和 `splitPayloadFromDex` 写入这个 apk。
2. `readDexFileFromApk` 从 apk 中定位 `classes.dex`。
3. `splitPayloadFromDex` 从文件尾读取 4 字节的 int 作为大小（此处为 4459705），然后调用 `decrypt`（xor 0xFF）函数写入对应大小的文件，得到一个新 apk。
4. 将新 apk 拖进 jadx，发现存在 SQL 查询数据库的逻辑，`create_sql` 创建 db 时又用 xor 0xFF 解密。
5. 打开解密后的 db 即可看到 flag。

关键解密思路：从尾部读长度 + 整体 xor 0xFF 还原。

## 参考答案
（见截图，原文未直接给出 flag 字符串）

## 来源
- 作者：jht3 | https://jht3qaq.github.io/2024/04/26/XYCTF2024-Writeup/
