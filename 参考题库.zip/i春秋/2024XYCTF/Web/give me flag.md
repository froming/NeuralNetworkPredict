# give me flag

> 分类：Web

## 题目描述
带时间戳的 MD5 哈希长度扩展攻击题。`md5($FLAG.$value.$time) === $md5`，需要利用已知的 `md5($FLAG)` 与 flag 长度（动态 flag 固定 43 位）进行哈希长度扩展攻击，配合时间戳暴力请求获取 flag。

## 考察知识点
- 哈希长度扩展攻击（Hash Length Extension）
- 动态 flag 长度爆破
- 时间戳处理

## 解法
源码：
```php
$FLAG_md5 = md5($FLAG);
if(!isset($_GET['md5']) || !isset($_GET['value'])) { highlight_file(__FILE__); die($FLAG_md5); }
$value = $_GET['value'];
$md5 = $_GET['md5'];
$time = time();
if(md5($FLAG.$value.$time)===$md5) { echo $FLAG; }
```

动态 flag 格式 `flagname{uuid.uuid4()}`，长度固定 43（7+36）。使用工具 [shellfeel/hash-ext-attack](https://github.com/shellfeel/hash-ext-attack)（免编译的 hashpump 替代）。

法一（直接手测，提前设置时间戳，用脚本持续请求）：
```python
import requests

url = 'http://127.0.0.1:31860/?md5=509dbe30c98c4ddb7817813e9a1fc3c6&value=%80%00%00%00%00%00%00%00%00%00%00%00%00X%01%00%00%00%00%00%00'

while True:
    res = requests.get(url=url)
    if "XYCTF" in res.text:
        print(res.text)
        break
```

法二（修改脚本手动加入时间戳）：
```python
import urllib, requests
from common.HashExtAttack import HashExtAttack

hash_ext_attack = HashExtAttack()
while 1:
    hash_ext_attack.test(43)
    value = urllib.parse.quote(hash_ext_attack.new_text[43:-10], safe='&=')
    md5 = hash_ext_attack.new_hash
    url = "http://gz.imxbt.cn:20508/"
    r = requests.get(url + f"?md5={md5}&value={value}")
    if 'yes' in r.text:
        print(r.text)
        break
```
其中 `test` 方法中手动加入时间戳：`self.run("", "原md5($FLAG)", str(int(time.time())), i)`。

## 参考答案
（未给出，见截图）

## 来源
- 作者：Z3r4y（uuzeray） | https://blog.csdn.net/uuzeray/article/details/138274291
- 作者：HvAng | https://hvang10.github.io/2024/04/27/XYCTF2024wp/index.html
- 作者：J1rrY | https://j1rry-learn.github.io/posts/2024-xyctf-webmisc-wp/
