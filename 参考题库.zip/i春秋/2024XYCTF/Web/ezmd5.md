# ezmd5

> 分类：Web

## 题目描述
一道 MD5 碰撞题，需要上传两张 MD5 强相等但内容不同的图片，然后比较两张图片拿到 flag。题目只允许上传 jpg 格式。

## 考察知识点
- MD5 碰撞（文件强相等）
- fastcoll / md5collgen 工具使用

## 解法
1. 使用 fastcoll 工具生成两张 MD5 相同的图片（需要自己先提供一张 jpg 作为前缀）：
   ```
   fastcoll_v1.0.0.5.exe -p 1.jpg -o 11.jpg 12.jpg
   ```
   也可用 GitHub 项目 [md5collgen](https://github.com/zhijieshi/md5collgen) 生成。
2. 将生成的两张图片（11.jpg、12.jpg）分别上传。
   - 注意：若提示只允许 jpg，重新生成即可。
3. 上传成功后点击「比较图片」，两张图片 MD5 相等，返回 flag。

## 参考答案
（未给出，见截图）

## 来源
- 作者：Z3r4y（uuzeray） | https://blog.csdn.net/uuzeray/article/details/138274291
- 作者：HvAng | https://hvang10.github.io/2024/04/27/XYCTF2024wp/index.html
- 作者：J1rrY | https://j1rry-learn.github.io/posts/2024-xyctf-webmisc-wp/
