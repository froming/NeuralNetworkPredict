# ezhttp

> 分类：Web

## 题目描述
一道基础的 HTTP 八股信息泄露 + 发包伪造请求头题目。访问站点后需要先通过 robots.txt 泄露的路径获取账号密码登录，再逐层伪造 HTTP 请求头拿到 flag。

## 考察知识点
- robots.txt / 敏感路径信息泄露
- HTTP 请求头伪造（Referer、User-Agent、X-Forwarded-For、Via、Cookie）

## 解法
1. 访问 `./robots.txt`，得到泄露的路径 `l0g1n.txt`。
2. 访问 `./l0g1n.txt`，拿到账号密码：
   ```
   username: XYCTF
   password: @JOILha!wuigqi123$
   ```
3. 登录后抓包，逐层伪造请求头（每个头通过一个提示判断）：
   - `Referer: yuanshen.com`
   - `User-Agent: XYCTF`
   - `Client-IP: 127.0.0.1`（或 `X-Forwarded-For: 127.0.0.1`）
   - `Via: ymzx.qq.com`
   - `Cookie: XYCTF`
4. 全部通过后返回 flag。

常用伪造 IP 的请求头备忘：
```
X-Forwarded-For:127.0.0.1
Client-ip:127.0.0.1
X-Client-IP:127.0.0.1
X-Remote-IP:127.0.0.1
X-Real-IP:127.0.0.1
X-Originating-IP:127.0.0.1
HTTP_CLIENT_IP:127.0.0.1
via:127.0.0.1
```

## 参考答案
（未给出，见截图）

## 来源
- 作者：Z3r4y（uuzeray） | https://blog.csdn.net/uuzeray/article/details/138274291
- 作者：HvAng | https://hvang10.github.io/2024/04/27/XYCTF2024wp/index.html
- 作者：J1rrY | https://j1rry-learn.github.io/posts/2024-xyctf-webmisc-wp/
