# εZ?¿м@Kε¿?

> 分类：Web

## 题目描述
Makefile 自动变量 + 报错带出的命令执行题。查看源码可访问 `./hint.php` 得到白名单，长度限制在 7 以内，未被过滤的只剩符号 `><@$()-` 等。需要利用 Makefile 自动变量 `$<`（第一个依赖，即 `/flag`）配合输入重定向 `<` 读文件，通过报错带出命令执行结果。

## 考察知识点
- Makefile 自动变量（`$@`、`$<`、`$^`、`$?`、`$*` 等）
- Makefile 中 `$$` 与 shell 变量 `$` 的关系
- 输入重定向 `<` 读文件
- 报错信息带出命令执行结果

## 解法
Makefile 自动变量含义：
- `$@`：目标文件名
- `$<`：第一个依赖文件名（本题中为 `/flag`）
- `$^`：所有依赖列表
- `$?`：比目标新的依赖列表
- `$*`：模式规则中 `%` 匹配的部分

靶机中 `$<` 就是 `/flag`。注意 makefile 中 `$$` 代表 shell 中的 `$`。`<` 用于输入重定向，`$(<file)` 可读取文件内容作为字符串。

通过报错可以带出命令执行结果的第一个空格前的字符串，用 `<` 把 `/flag` 的内容重定向进来：

最终 payload：
```
$$(<$<)
```
即 `$(</flag)`，读到的 flag 内容通过报错信息带出。

## 参考答案
（未给出，见截图）

## 来源
- 作者：Z3r4y（uuzeray） | https://blog.csdn.net/uuzeray/article/details/138274291
- 作者：HvAng | https://hvang10.github.io/2024/04/27/XYCTF2024wp/index.html
- 作者：J1rrY | https://j1rry-learn.github.io/posts/2024-xyctf-webmisc-wp/
