# zzl的护理小课堂

> 分类：Misc

## 题目描述
一个答题页面，需要拿到 flag。看似是 Web 题，实际是一道前端 JS 分析题。后端在分数 > 100 时会向 flag.php 请求 flag。

## 考察知识点
- JS 前端逻辑分析
- XMLHttpRequest

## 解法
阅读页面源码发现本地判断逻辑：当 score == 100 显示"杂鱼"，score < 100 显示 "noooooob!!"，只有 score > 100 才会请求 flag.php 返回 flag。

```javascript
if (xhr.readyState === 4 && xhr.status === 200) {
    var score = xhr.responseText;
    if (score == 100) {
        document.getElementById('scoreDisplay').innerText = "你的分数是: " + score + "/100 杂鱼,怎么才100分啊";
    } else if (score < 100) {
        document.getElementById('scoreDisplay').innerText = "你的分数是: " + score + "/100 noooooob!!";
    } else {
        var flagXhr = new XMLHttpRequest();
        flagXhr.open('GET', 'flag.php', true);
        flagXhr.onreadystatechange = function() {
            if (flagXhr.readyState === 4 && flagXhr.status === 200) {
                var flag = flagXhr.responseText;
                document.getElementById('scoreDisplay').innerText = "Flag: " + flag;
            }
        };
        flagXhr.send();
    }
}
xhr.send(formData);
```

直接在控制台执行以下代码请求 flag：

```javascript
var flagXhr = new XMLHttpRequest();
flagXhr.open('GET', 'flag.php', true);
flagXhr.onreadystatechange = function() {
    if (flagXhr.readyState === 4 && flagXhr.status === 200) {
        var flag = flagXhr.responseText;
        console.log(flag);
    }
};
flagXhr.send();
```

（也可用 Postman 模拟，控制台更省事）

## 参考答案
（未给出，通过 flag.php 返回）

## 来源
- 作者：jht3 | https://jht3qaq.github.io/2024/04/26/XYCTF2024-Writeup/
- 作者：J1rrY | https://j1rry-learn.github.io/posts/2024-xyctf-webmisc-wp/
