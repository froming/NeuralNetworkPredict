# Rock,Paper,Scissors!

> 分类：Misc

## 题目描述
与服务器进行多轮石头剪刀布游戏，需要全部获胜才能拿到 flag。题目未提供源码，需要分析服务器（假 AI）的出拳规律。

## 考察知识点
- 脚本编写（pwntools）
- 观察并总结随机数/AI 出拳规律

## 解法
两种思路：一是遵循一定数学规律，二是 Fuzz 出规律。将出拳编号：Rock=0、Paper=1、Scissors=2。

经手测发现假 AI 的出拳规律为 `0,0,1,1,2,2` 循环（即 `0112220011...`）。

jht3 的脚本（找规律后固定序列）：

```python
from pwn import *
from random import randint

m = [b"Rock", b"Paper", b"Scissors"]

ans = [0,0,1,1,2,2]*100
ans[1]=1
ans[3]=2

while True:
    try:
        sh = remote('heuctf.cn',11055, level="CRITICAL")
        for _ in range(100):
            sh.recvuntil(b' round\n> ')
            if len(ans) > _:
                sh.sendline(m[ans[_]])
                sh.recvline()
                if sh.recvline() != b"You win!\n":
                    raise Exception()
            else:
                r = randint(0,2)
                sh.sendline(m[r])
                sh.recvline()
                if sh.recvline() == b"You win!\n":
                    ans.append(r)
                    print(ans)
                else:
                    raise Exception()
        sh.interactive()
    except Exception:
        sh.close()
```

J1rrY 的脚本（半自动化 Fuzz + 固定序列）：

```python
from pwn import *
import time

host = '127.0.0.1'
port = 51531
conn = remote(host, port)
moves = [b'Rock', b'Paper', b'Scissors']
sequence = '011222001122001122001122001122001122001122001122001122001122001122001122001122001122001122001122001122001122001122001122001122001122001122001122001122001122001122001122001122001122001122001122001122001122001122001122001122001122001122001122001122001122001122001122001122001122001122001122001122001122001122001122001122001122001122001122001122001122001122001122001122001122001122001122001122'

for move in sequence:
    move_int = int(move)
    print(moves[move_int])
    conn.sendline(moves[move_int])
    time.sleep(1)
    response = conn.recv()
    print(response)
```

## 参考答案
（未给出，需与服务器交互后获取）

## 来源
- 作者：jht3 | https://jht3qaq.github.io/2024/04/26/XYCTF2024-Writeup/
- 作者：J1rrY | https://j1rry-learn.github.io/posts/2024-xyctf-webmisc-wp/
