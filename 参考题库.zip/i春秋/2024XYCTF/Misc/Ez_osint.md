# Ez_osint

> 分类：Misc

## 题目描述
OSINT 社工题，需要找到某个网站并定位到目标帖子。

## 考察知识点
- 搜索引擎 / 关键字搜索
- 网站 ID 遍历 / 爬虫

## 解法
搜索关键字"时光邮局"，找到网站 https://www.hi2future.com/ 。

发现该网站的帖子 ID 与事件呈线性分布，找两个时间接近的帖子，在其间爬取公开帖子（ID 从 478961 到 494500）：

```python
import requests
from time import sleep
for i in reversed(range(478961, 494500)):
    data = requests.get(f"https://www.hi2future.com/Mail/showitem/id/{i}", headers={
        "Referer": "https://www.hi2future.com/Mail/showitem/id/478961",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36",
    })
    data.encoding = 'utf-8'
    print(i, end="")
    if "这封并不是公开信" in data.text:
        print("不公开")
    else:
        print("公开")
    sleep(0.05)
```

最终找到目标帖子：https://www.hi2future.com/Mail/showitem/id/494468

（j1rry 的解法：直接搜索"时光邮局"，按时间顺序翻找即可。）

## 参考答案
（未给出，目标帖子里可见 flag）

## 来源
- 作者：jht3 | https://jht3qaq.github.io/2024/04/26/XYCTF2024-Writeup/
- 作者：J1rrY | https://j1rry-learn.github.io/posts/2024-xyctf-webmisc-wp/
