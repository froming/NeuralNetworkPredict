# EZ_Base1024*2

> 分类：Misc

## 题目描述
给出一串奇怪的 Unicode 字符密文，题目暗示是 Base1024*2，即 Base2048 编码。

## 考察知识点
- Base2048 编码

## 解法
题目暗示 base2048。密文形如：

```
מಥൎࢺଳɫअΥٻଯԢڥիɺ୦ࢸЭਘמۊիɎඥࡆڣߣಷܤҾয౽5
```

使用在线 Base2048 解码工具解码即可：

- https://nerdmosis.com/tools/encode-and-decode-base2048

## 参考答案
（见截图，Base2048 解码后得到 flag）

## 来源
- 作者：jht3 | https://jht3qaq.github.io/2024/04/26/XYCTF2024-Writeup/
- 作者：J1rrY | https://j1rry-learn.github.io/posts/2024-xyctf-webmisc-wp/
