# game

> 分类：Misc

## 题目描述
给出一张游戏截图，需要识别出游戏名称。属于以图搜图的社工题。

## 考察知识点
- 以图搜图
- 游戏识别

## 解法
以图搜图即可识别出游戏。jht3 表示自己看过该游戏，B 站视频号 BV1f64y1T71B。

识别出的游戏为 **Papers, Please**（《请出示文件》）。

## 参考答案
Papers, Please（游戏名称）

## 来源
- 作者：jht3 | https://jht3qaq.github.io/2024/04/26/XYCTF2024-Writeup/
- 作者：J1rrY | https://j1rry-learn.github.io/posts/2024-xyctf-webmisc-wp/
