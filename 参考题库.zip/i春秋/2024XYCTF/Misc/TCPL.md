# TCPL

> 分类：Misc

## 题目描述
下载得到一个无后缀的文件，010 查看为 ELF 文件，架构为 RISC-V，需要搭建环境运行。

## 考察知识点
- 文件格式识别（DIE / 010）
- RISC-V 交叉编译环境搭建

## 解法
文件拖入 Kali 运行报错，继续用 010 查看发现是 `linux-riscv64` 架构。

参考教程搭建 RISC-V 环境：
- https://www.francisz.cn/2021/10/03/riscv-arch-env/
- https://blog.csdn.net/yueyuanhuaqing/article/details/123993462 （基于 WSL 的 RISC-V GCC 交叉工具链）

搭建完成后运行文件，将输出中的 1 换成 0 即为 flag。

## 参考答案
（见截图，运行结果将 1 替换为 0）

## 来源
- 作者：jht3 | https://jht3qaq.github.io/2024/04/26/XYCTF2024-Writeup/
- 作者：J1rrY | https://j1rry-learn.github.io/posts/2024-xyctf-webmisc-wp/
