# ez_隐写

> 分类：Misc

## 题目描述
一个加密的 ZIP，内含图片，需要逐步破解进行隐写分析。

## 考察知识点
- ZIP 伪加密
- PNG CRC 校验修复
- JPG 盲水印

## 解法
打开附件发现压缩包有密码，实际是 ZIP 伪加密，修复伪加密后解压得到 hint.png。

hint.png 打不开，用 TweakPNG 检查发现 CRC 错误，需要修复 CRC（可用"风二西"等工具一键修复）。修复后打开图片得到密码 `20240401`，解压得到一张名为 `WATERMARK.jpg` 的图片（暗示盲水印）。

将该 JPG 放入"随波逐流"等工具分析，提取盲水印即可得到 flag。

（jht3 的解法：先 CRC 爆破，再使用 52pojie 上的图片隐写工具直接拖入查看。）

## 参考答案
（见截图）

## 来源
- 作者：jht3 | https://jht3qaq.github.io/2024/04/26/XYCTF2024-Writeup/
- 作者：J1rrY | https://j1rry-learn.github.io/posts/2024-xyctf-webmisc-wp/
