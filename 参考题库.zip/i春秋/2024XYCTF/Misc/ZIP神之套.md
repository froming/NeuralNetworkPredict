# ZIP神之套

> 分类：Misc

## 题目描述
附件含一个打不开的 exe 和层层嵌套的压缩包，需要爆破密码并进行明文攻击。

## 考察知识点
- ZIP 密码爆破
- ZIP 明文攻击（known-plaintext attack）

## 解法
在 cmd 中运行附件 `这玩意咋打不开呢.exe`，得到提示（中间为开赛日期），拼出密码 `xyctf20240401ftcyx`，解压得到 `套/flag` 与 `flag.zip`。

`套/flag` 中的内容与 `flag.zip` 内文件内容、文件名一致，可直接进行明文攻击（使用 ARCHPR）：

- 明文攻击得到 flag.zip 密码
- 解压后在 `flag.md` 中搜索得到 flag

（jht3 提示：john+hashcat 爆破不出，ARCHPR 秒出。）

## 参考答案
XYCTF{1A4B8-C9D2F3E-6A4B8C-9D2F3E7F}

## 来源
- 作者：jht3 | https://jht3qaq.github.io/2024/04/26/XYCTF2024-Writeup/
- 作者：J1rrY | https://j1rry-learn.github.io/posts/2024-xyctf-webmisc-wp/
