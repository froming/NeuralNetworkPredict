# Sign1n（签到）

> 分类：Crypto

## 题目描述

一道签到题。题目将 flag 进行如下变换：

1. 将 flag 转为整数，再转为二进制字符串（`bin(...)`，带 `0b` 前缀）；
2. `swap_bits`：去掉 `0b` 前缀后，将二进制串整体反转；
3. `custom_add`：对反转后的每一位，第 `i` 位执行 `(digit + i + 1) % 10`；
4. 输出最终的十进制数字串（即题目给的 `b`）。

只需要读懂代码，反向操作即可还原 flag。

## 考察知识点

- Python 进制转换（`long_to_bytes`、`int(..., 2)`）
- 字符串反转
- 逐位模运算逆向

## 解法

题目加密过程可概括为：`b = custom_add(swap_bits(bin(flag)[2:]))`，其中 `custom_add` 对每一位做 `(digit + i + 1) % 10`。

逆向步骤：

1. 对 `b` 的每一位做逆运算 `(digit - i - 1) % 10`；
2. 将得到的二进制字符串再次反转（`swap_bits` 是自逆操作）；
3. 前面补上被去掉的 `0`，然后 `int(bin_str, 2)` 转成整数，`long_to_bytes` 还原 flag。

关键脚本：

```python
from Crypto.Util.number import *

b = '12345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567891134567780113445678912234577900133457889122356678911344577991223566780113355788901245667901134456789122355788001334568991123467799023445678012235578800133457889113356679001344567991223557880012355788911235667991134457799122355788001245578891124566789023445788912234677801124456899013356679001245578801233467789112355779912234577990233556780113'

def custom_add(input_str):
    input_list = list(input_str)
    length = len(input_list)
    for i in range(length):
        input_list[i] = str((int(input_list[i]) - i - 1) % 10)
    result = ''.join(input_list)
    return result

def swap_bits(input_str):
    input_list = list(input_str[2:])
    length = len(input_list)
    for i in range(length // 2):
        temp = input_list[i]
        input_list[i] = input_list[length - 1 - i]
        input_list[length - 1 - i] = temp
    return ''.join(input_list)

dec_b = custom_add(b)
bin_str = swap_bits(dec_b)
flag = int('0' + bin_str, 2)
print(long_to_bytes(flag))
```

另一位选手 jht3 的等价解法（用 `+10000000` 保证取模前为正，逻辑一致）：

```python
s = '12345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456799123455779902334577801134557889112456678911344578890233457790013355689902335667990134457799122355689001335668891124566780112455679902334568900133566889113356679901245567990233457790013356688901235667800124556889023346678011335668891223467789023445679902334677801123557889122346779901245577991223566890113455689911234677891224556899023'
s = [int(i) for i in s]
s = [(s[i] + 10000000 - i - 1) % 10 for i in range(len(s))]
s = "".join([str(i) for i in s])

def swap_bits(input_str):
    input_list = list(input_str)
    length = len(input_list)
    for i in range(length // 2):
        temp = input_list[i]
        input_list[i] = input_list[length - 1 - i]
        input_list[length - 1 - i] = temp
    return ''.join(input_list)

print("0" + swap_bits(s))
```

## 参考答案

XYCTF{c4bf3896-5514-4351-89aa-0785c5431406}

（注：flag 动态生成，不同实例的 `b` 不同；jht3 解出的结果为 `flag{5ac4fd8c-bbb0-4da5-8df9-9516e4c497de}`，两处前缀写法略有差异，实际提交以平台为准。）

## 来源

- 作者：HvAng | https://hvang10.github.io/2024/04/27/XYCTF2024wp/index.html
- 作者：jht3 | https://jht3qaq.github.io/2024/04/26/XYCTF2024-Writeup/
