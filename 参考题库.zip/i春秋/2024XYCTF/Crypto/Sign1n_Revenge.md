# Sign1n_Revenge

> 分类：Crypto

## 题目描述

Sign1n 的加强版（复仇版）。与签到题 Sign1n 采用相同的加密逻辑，只是给出的数字串 `b` 不同（flag 动态生成）。加密过程依旧是：

1. flag 转整数再转二进制串；
2. 反转二进制串；
3. 逐位做 `(digit + i + 1) % 10`；
4. 输出十进制数字串 `b`。

## 考察知识点

- 同 Sign1n：进制转换、字符串反转、逐位模运算逆向

## 解法

与 Sign1n 完全相同，拿到新的 `b` 后，用同一个脚本再跑一遍即可。

逆向步骤：

1. `custom_add` 逆运算：每位 `(digit - i - 1) % 10`；
2. 反转二进制串；
3. 补上开头 `0`，转整数，`long_to_bytes` 还原 flag。

关键脚本（复用 Sign1n 脚本）：

```python
from Crypto.Util.number import *

b = '<题目给出的新数字串>'

def custom_add(input_str):
    input_list = list(input_str)
    length = len(input_list)
    for i in range(length):
        input_list[i] = str((int(input_list[i]) - i - 1) % 10)
    return ''.join(input_list)

def swap_bits(input_str):
    input_list = list(input_str[2:])
    length = len(input_list)
    for i in range(length // 2):
        temp = input_list[i]
        input_list[i] = input_list[length - 1 - i]
        input_list[length - 1 - i] = temp
    return ''.join(input_list)

dec_b = custom_add(b)
bin_str = swap_bits(dec_b)
flag = int('0' + bin_str, 2)
print(long_to_bytes(flag))
```

## 参考答案

（未给出）

（jht3 的 writeup 注明“内容同 Sign1n[签到]，同一个脚本再跑一遍就完事了”，未单独给出该题的 flag。）

## 来源

- 作者：HvAng | https://hvang10.github.io/2024/04/27/XYCTF2024wp/index.html
- 作者：jht3 | https://jht3qaq.github.io/2024/04/26/XYCTF2024-Writeup/
