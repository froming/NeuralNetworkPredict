# GameMaster

> 分类：Reverse

## 题目描述

.NET 程序（21 点游戏）。触发三个作弊码后对 `gamemessage` 文件进行 AES 解密并反序列化，提取出内嵌的 dll，再用 z3 求解三个环境变量得到 flag。

## 考察知识点

- .NET 逆向（dnSpy）
- AES-ECB 解密
- .NET 反序列化（BinaryFormatter）
- z3 位运算求解

## 解法

1. dnSpy 打开，发现三个作弊码：

```
MF3K: Bet -= 22, memory ^= 34, AchivePoint1 = Balance
EEPW: Balance += 175, AES 解密 memory (key="Brainstorming!!!"), AchivePoint2 = Balance
6VD6: Balance -= 27, BinaryFormatter.Deserialize(memory), AchivePoint3 = Balance
```

2. `gamemessage` 每字节异或 34，再用 key `Brainstorming!!!`（ASCII）AES-ECB 解密：

```python
from Crypto.Cipher import AES
data = bytearray(open('gamemessage','rb').read())
for i in range(len(data)): data[i] ^= 34
cipher = AES.new(b"Brainstorming!!!", AES.MODE_ECB)
open('gamemessage.de','wb').write(cipher.decrypt(data))
```

3. 解密后末尾含一个 dll，反编译看到 `Check1` 用 `array`（来自三个 AchivePoint）生成 `array2` 需等于 `first`，`ParseKey` 生成 key 循环异或 `array5`。
4. 用 z3 反解三个 64 位变量：

```python
x, y, z = BitVecs('x y z', 64)
first = [101,5,80,213,163,26,59,38,19,6,173,189,198,166,140,183,42,247,223,24,106,20,145,37,24,7,22,191,110,179,227,5,62,9,13,17,65,22,37,5]
k = [0 for i in range(40)]
num = -1
for i in range(320):
    x = ((x>>29^x>>28^x>>25^x>>23)&1)|x<<1
    y = ((y>>30^y>>27)&1)|y<<1
    z = ((z>>31^z>>30^z>>29^z>>28^z>>26^z>>24)&1)|z<<1
    if i % 8 == 0: num += 1
    k[num] = (k[num]<<1)|((z>>32&1&(x>>30&1))^(((z>>32&1)^1)&(y>>31&1)))
for i in range(40): solver.add(k[i]&0xff == first[i])
```

得到 `x=156324965, y=868387187, z=3131229747`。
5. ParseKey 生成 12 字节 key，循环异或 `mask` 得 flag。

## 参考答案

`flag{Y0u_@re_G3meM3s7er!}`

## 来源

- 作者：404Team | https://www.nynusec.com/archives/第六届强网杯-writeup
- 作者：or4nge | https://note.f5.pm/go-125939.html
- 作者：WHT战队 | https://cn-sec.com/archives/1217881.html
