# easyapk

> 分类：Reverse

## 题目描述

check 逻辑在 so 层，有大量垃圾指令混淆（用 ida 的 d810 插件去混淆），实际逻辑是 rot13 + TEA 加密。

## 考察知识点

- IDA d810 插件去混淆
- TEA 加密
- rot13

## 解法

1. 用 ida 的 d810 插件去混淆，进入 `sub_544`，最下面看到 TEA 加密。key 由 `time(0)` 生成，密文在 `unk_3E78`。
2. TEA 解密脚本（key = "0123456789abcdef"，32 轮，delta=0x9e3779b9）：

```c
void decrypt (uint32_t* v, uint32_t* k) {
    uint32_t v0=v[0], v1=v[1], sum=0xC6EF3720, i;
    uint32_t delta=0x9e3779b9;
    uint32_t k0=k[0], k1=k[1], k2=k[2], k3=k[3];
    for (i=0; i<32; i++) {
        v1 -= ((v0<<4) + k2) ^ (v0 + sum) ^ ((v0>>5) + k3);
        v0 -= ((v1<<4) + k0) ^ (v1 + sum) ^ ((v1>>5) + k1);
        sum -= delta;
    }
    v[0]=v0; v[1]=v1;
}
```

3. 解密得到 `synt{Vg_Vf_A0g_guNg_zHpu_unEqre}`，再做 rot13 得到 flag。

## 参考答案

`flag{It_Is_N0t_thAt_mUch_haRder}`

## 来源

- 作者：or4nge | https://note.f5.pm/go-125939.html
- 作者：WHT战队 | https://cn-sec.com/archives/1217881.html
