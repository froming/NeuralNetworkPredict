# game

> 分类：Reverse

## 题目描述

安卓题。附件 ba.ab 为安卓备份文件，用 abe.jar 解包得到 base.apk。分析 APK，hook 掉检测与加密函数，主动调用 decrypt 拿到 account，再请求 GetGlag.php 得到 flag。

## 考察知识点

- 安卓备份文件解包（abe.jar）
- Frida hook（root/frida 检测绕过）
- Android 逆向

## 解法

1. `ba.ab` 用 abe.jar 解包得到 `base.apk`。
2. 分析 `base.apk`，发现 `com.silence.scoreboard.http`，访问 `http://47.93.244.181/re/ScoreBoard.php` 得到用户和 admin 列表。admins 中只有 code=123125 的 best 为 9999 以上。
3. 通过 `AddFriend.php`（`POST code=123125`）得到 account。
4. 目标：主动调用 `com.silence.utils.OooOoo0.decryp()`，参数为 `"SWeH8ou9yuL8GLThYhY1QlDiWX880+uNZusmIll/Q4Q="`。
5. 需要绕过 root/supersu/frida 检测（magisk 过 root，hook `com.silence.utils.OoOO.OOOOOooo()` 和 `RootUtils.check()`；frida 检测在 native，用"先启动 app 再启动 server 并 `frida -F` 附加"绕过）。
6. hook `encrypt()` 并内部调用 `decrypt()`，得到 account 后请求 `GetGlag.php` 获取 flag。

## 参考答案

（flag 通过 hook decrypt 得到 account 后请求 GetGlag.php）

## 来源

- 作者：WHT战队 | https://cn-sec.com/archives/1217881.html
