# find_basic

> 分类：Reverse

## 题目描述

动调发现有多个函数带虚拟机结构，输入在 0x4942，加密部分在 0x750A9，由几百个类似代码块构成。用 idapython 动调提取机器码，还原清晰结构后列方程用 z3 求解 28 字符 flag。

## 考察知识点

- IDA 动态调试 + idapython 提取
- VM 结构分析
- z3 线性方程组求解

## 解法

1. 用 idapython 动调脚本提取执行过的指令（`step_into`/`step_over`），以 `jnz`/`jmp` 作为子模块标识进一步提取：

```python
ea = get_reg_value('eip')
end = ea + 0x1806
main_func = get_func_name(ea)
while True:
    ea = get_reg_value('eip')
    next_ea = next_head(ea)
    fp.write(hexlify(get_bytes(ea, next_ea-ea)).decode())
    fp.write('\t' + GetDisasm(ea) + '\n')
    if ea >= end: break
    if main_func == get_func_name(ea): step_into()
    else: step_over()
    wait_for_next_event(WFNE_SUSP, -1)
```

2. 提取机器码写入文件，补齐栈平衡和函数返回，用 ida 反编译得到清晰结构。
3. 根据"绝对值"提示列 31 个方程，z3 求解 28 个字符（约束每个字符在 0x20-0x7f 间，且 `flag{...}` 格式固定）。

```python
a1 = [BitVec('x%d' % i, 32) for i in range(28)]
# 31 个线性方程 con1..con31
s = Solver()
for i in range(28):
    s.add(a1[i] > 0x20); s.add(a1[i] < 0x7f)
s.add(a1[0]==ord('f')); s.add(a1[1]==ord('l')); s.add(a1[2]==ord('a'))
s.add(a1[3]==ord('g')); s.add(a1[4]==ord('{')); s.add(a1[27]==ord('}'))
# s.add(conN == 0) for each
```

4. 校验 md5 后得到 flag。

## 参考答案

（flag 通过 z3 解方程得到）

## 来源

- 作者：or4nge | https://note.f5.pm/go-125939.html
