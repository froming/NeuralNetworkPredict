# myjwt

> 分类：Crypto

## 题目描述

基于 ECDSA（SHA384withECDSAinP1363Format）的 JWT。Java 的 ECDSA 实现存在 CVE-2022-21449，未验证 r/s 是否为 0，提交全零签名可绕过验证，把 admin 改为 true 拿到 flag。

## 考察知识点

- JWT 结构
- ECDSA（P-384）
- CVE-2022-21449（Java ECDSA 全零签名绕过）

## 解法

1. 连接获取 token，格式 `header.payload.sig`，payload 解码为 `{"iss":"qwb","name":"xxx","admin":false,"exp":...}`。
2. 需要 `admin=true` 且 `exp` 未过期。修改 payload 为 `{"iss":"qwb","name":"xxx","admin":true,"exp":1759321328438}` 并重新 base64 url 编码。
3. ECDSA 采用 SHA384，签名 base64 长度 128，对应 96 个空字节。全零签名可 100% 通过 CVE-2022-21449 的验证。最终 token：

```
eyJ0eXAiOiJKV1QiLCJhbGciOiJteUVTIn0=.eyJpc3MiOiJxd2IiLCJuYW1lIjoiV2Fua2tvIFJlZSIsImFkbWluIjp0cnVlLCJleHAiOjE3NTkzMjEzMjg0Mzh9.AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
```

4. 提交即可获得 flag。

## 参考答案

`flag{cve-2022-21449_Secur1ty_0f_c0de_1mplementation}`

## 来源

- 作者：404Team | https://www.nynusec.com/archives/第六届强网杯-writeup
- 作者：or4nge | https://note.f5.pm/go-125939.html
- 作者：WHT战队 | https://cn-sec.com/archives/1217881.html
