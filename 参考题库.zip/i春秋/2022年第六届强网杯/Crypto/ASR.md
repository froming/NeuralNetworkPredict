# ASR

> 分类：Crypto

## 题目描述

RSA 题。`n = p² * q² * r² * s²`（四个 128 位素数平方），`e=3`，flag 经过 padding 后长度 >= 48。需开方 + 分解 + 处理 e 与 phi 不互素的情况。

## 考察知识点

- RSA（n 为素数平方乘积）
- 大数开方、yafu/factordb 分解
- e 与 phi 不互素的解密（AMM 开根 / 缩小模量）

## 解法

1. `n = (p*q*r*s)^2`，先开平方：

```python
nn = iroot(n, 2)[0]
```

2. yafu 分解 `nn` 得四个 128 位素数 p、q、r、s。其中 `gcd(q*(q-1), e)=3`、`gcd(s*(s-1), e)=3`，即有两个因子的 `p-1` 与 e 不互素。
3. 用两个正常的因子重构 `n' = (p*r)^2`，`phi = p*(p-1)*r*(r-1)`，此时 `gcd(phi, e)=1`，直接求逆解密：

```python
phi = (p*(p-1))*(r*(r-1))
d = invert(e, phi)
m = pow(c, d, p**2 * r**2)
print(long_to_bytes(m))
```

（另一种做法：用 AMM 对模 p 开 e 次根，再代入 `m = mp + k*p` 解模 N 的解）

## 参考答案

`flag{Fear_can_hold_you_prisoner_Hope_can_set_you_free}`

## 来源

- 作者：404Team | https://www.nynusec.com/archives/第六届强网杯-writeup
- 作者：or4nge | https://note.f5.pm/go-125939.html
- 作者：WHT战队 | https://cn-sec.com/archives/1217881.html
