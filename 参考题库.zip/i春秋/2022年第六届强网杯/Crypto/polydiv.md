# polydiv

> 分类：Crypto（强网先锋）

## 题目描述

远程交互 40 关，每关给三个多项式 `a(x)`、`r(x)`、`c(x)`，需在模 2 多项式环上求 `b(x)` 满足 `a(x)*b(x)+c(x) == r(x)`。

## 考察知识点

- 模 2 多项式环（GF(2) 多项式除法）
- 远程交互 + POW

## 解法

1. 先过 SHA256 POW，再循环 40 轮。
2. 模 2 多项式环中加法即异或，除法可用位运算实现（GF2_div）：

```python
def GF2_div(n1, n2):
    if n2 == 1:
        return n1
    len1 = len(bin(n1)); len2 = len(bin(n2))
    lensub = len1 - len2 + 1
    if lensub < 1: return hex(0)
    elif lensub == 1: return hex(1)
    else:
        div = 0
        while len1 >= len2:
            n1 ^= (n2 << (len1 - len2))
            div ^= (1 << (len1 - len2))
            len1 = len(bin(n1))
        return div
```

3. 计算 `b = (r - c) / a`（模 2 下减法即异或），调整格式（高位在左、低位在右）后提交，40 轮通过得到 flag。

## 参考答案

`flag{768782a0-e637-4982-9415-4b8f005e466b}`

## 来源

- 作者：404Team | https://www.nynusec.com/archives/第六届强网杯-writeup
- 作者：or4nge | https://note.f5.pm/go-125939.html
- 作者：WHT战队 | https://cn-sec.com/archives/1217881.html
