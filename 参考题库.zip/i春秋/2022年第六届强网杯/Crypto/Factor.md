# Factor

> 分类：Crypto

## 题目描述

三关 RSA 分解题。参考论文 https://eprint.iacr.org/2015/399.pdf，三种攻击对应三关，反序解出。第一二关用 Coppersmith（sage `small_roots()`），第三关用连分数。

## 考察知识点

- RSA 分解（特殊构造）
- Coppersmith 方法（sage `small_roots()`）
- 连分数（Wiener 相关攻击）

## 解法

1. 第一、二关用 Coppersmith 方法，sage 中构造多项式用 `small_roots()` 求根：

```python
R.<x> = PolynomialRing(Zmod(n3), implementation='NTL')
e3 = ...
z = ...
f = e3*x - z
f = f.monic()
print(f.small_roots(beta=0.7))
```

2. 第三关用连分数解决，写连分数展开求分数收敛子：

```python
def tCf(n, d):
    res = []
    while d:
        res.append(n // d)
        n, d = d, n % d
    return res

def cf(sub_res):
    n, d = 1, 0
    for i in sub_res[::-1]:
        d, n = n, i * n + d
    return d, n

def listFraction(x, y):
    res = tCf(x, y)
    return list(map(cf, (res[0:i] for i in range(1, len(res)))))
```

3. 依次分解三关的 n 得到 flag。

## 参考答案

（flag 通过三关分解得到）

## 来源

- 作者：or4nge | https://note.f5.pm/go-125939.html
