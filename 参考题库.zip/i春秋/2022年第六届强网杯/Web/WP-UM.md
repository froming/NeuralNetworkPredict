# WP-UM

> 分类：Web

## 题目描述

WordPress 插件 User Meta Lite 存在越权文件读取，通过 `um_show_uploaded_file` 接口逐位爆破管理员账号密码（存放于 `/username` 和 `/password` 目录），登录后台传马 getshell。

## 考察知识点

- WordPress 插件 User Meta Lite 越权（文件路径穿越读取）
- 后台传马 getshell

## 解法

1. 附件给了 docker 和账号密码（adminadmin / adminadminadmin），本地起环境，后台发现三个插件，其中 User Meta Lite 正在使用。
2. 该插件存在越权漏洞（wpscan），subscriber 提交 File Upload 字段时改 `filepath` 参数可读取任意文件，文件存在则响应含 `um_remove_file`：

```
POST /wp-admin/admin-ajax.php
field_name=test&filepath=/../../../../../../../../etc/passwd&field_id=um_field_4&form_key=Upload&action=um_show_uploaded_file&pf_nonce=xxx&is_ajax=true
```

3. 管理员账号密码按题目说明存放：账号 10 位在 `/username` 下、密码 15 位在 `/password` 下，每个文件名为"序号+字母"。写脚本逐位爆破：

```python
for i in range(1, 11):
    for s in strings:
        # filepath = '/../../../../../username/' + str(i) + s
        # 若响应含 umRemoveFile 则命中
```

4. 得到账号 `MaoGePaMao`、密码 `MaoGeYaoQiFeiLa`。
5. 管理员登录后台，修改插件上传限制，添加 php 后缀，传马 getshell，读取 flag。

## 参考答案

（flag 通过后台传马 getshell 读取）

## 来源

- 作者：404Team | https://www.nynusec.com/archives/第六届强网杯-writeup
