# easyweb

> 分类：Web

## 题目描述

任意文件读 + PHP_SESSION_UPLOAD_PROGRESS 强制开启 session + phar 反序列化 SSRF，内网 10.10.10.10 的 nginx php 存在 ssrf，直接 `file:///flag` 读取 flag。

## 考察知识点

- 任意文件读
- PHP_SESSION_UPLOAD_PROGRESS 强制 `session_start()`
- phar 反序列化 POP 链（`__wakeup`、`__toString`、`__get`、`__set`）
- SSRF / 内网探测（`/proc/1/net/arp`）

## 解法

1. `showfile.php?f=./demo/../class.php` 任意文件读，审计发现 `AdminShow` 的 `show()` 可 ssrf，但 `__wakeup` 会把 schema/source 重置，需用 `__get` 在 `__destruct` 后重新赋值。
2. session 未开启，用 `PHP_SESSION_UPLOAD_PROGRESS` 强制开启 `session_start()` 上传临时文件。
3. 构造 phar 反序列化 POP 链（GuestShow→Upload→AdminShow）触发 ssrf。
4. 任意文件读 `/proc/1/net/arp`，发现内网 `10.10.10.10`。
5. 用 `http://10.10.10.10/index.php?url=file:///flag` ssrf 过去读取 flag。

## 参考答案

（flag 通过内网 ssrf 读取 `/flag` 得到）

## 来源

- 作者：or4nge | https://note.f5.pm/go-125939.html
