# crash

> 分类：Web

## 题目描述

Flask + pickle 反序列化题。通过 pickle 覆盖 `admin.secret` 进入后台，后台为 nginx/lua-resty-balancer 负载均衡配置页，构造数据让页面超时返回 504 拿到 flag。

## 考察知识点

- Python pickle 反序列化（`R` 过滤绕过、unicode 绕过 `secret` 过滤）
- Flask session/cookie
- openresty lua-resty-balancer
- HTTP 504 超时

## 解法

1. `/balancer` 路由从 cookie `userdata` 反序列化 pickle。过滤条件：base64 解码后不能含 `R` 和 `secret`。
2. 用 `pickle` 的 `exec` 字符串拼接绕过关键字过滤，覆盖全局变量 `admin.secret`：

```python
opcode = b'''(cbuiltins
exec
S'exec("admin.sec"+"ret=\'123456\'")'
o.'''
```

base64 编码后放到 cookie 访问 `/balancer`。
3. 再访问 `login?username=admin&password=123456`，得到合法 `userdata`，再次访问 `/balancer` 进入后台。
4. 后台源码提示 `flag in 504 page` 和路径 `/826fd2f86129b050875e4a70cb059908a7ed`，下载得到 nginx 配置（openresty `lua-resty-balancer`）。
5. 配置中 `/gettestresult` 用 roundrobin 负载均衡，构造同一 IP 不同端口、权重任意，让请求超时返回 504，得到 flag。

## 参考答案

`flag{6792305a-563c-4dc3-9308-055aa07e3756}`

## 来源

- 作者：404Team | https://www.nynusec.com/archives/第六届强网杯-writeup
- 作者：WHT战队 | https://cn-sec.com/archives/1217881.html
