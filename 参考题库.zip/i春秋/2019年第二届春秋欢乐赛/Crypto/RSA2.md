# RSA2

> 分类：Crypto

## 题目描述

RSA 相关题目（writeup 以 PDF 形式存在，具体题目参数见 PDF）。

## 考察知识点

- RSA

## 解法

本题 writeup 以 PDF 形式提供（链接：https://paper.vulsee.com/ctf-pdf/i春秋第二届春秋欢乐赛 RSA2 writeup_bingge15的博客.pdf）。原 PDF 对应的 CSDN 原文：https://blog.csdn.net/hanjinrui15/article/details/102253455。

（注：PDF 内容为图片+加密文本，无法直接提取文字。解题思路见 CSDN 原文 hanjinrui15 的博客。）

## 参考答案

（flag 见 PDF / CSDN 原文截图）

## 来源

- 作者：bingge15 | https://paper.vulsee.com/ctf-pdf/i%E6%98%A5%E7%A7%8B%E7%AC%AC%E4%BA%8C%E5%B1%8A%E6%98%A5%E7%A7%8B%E6%AC%A2%E4%B9%90%E8%B5%9B%20RSA2%20writeup_bingge15%E7%9A%84%E5%8D%9A%E5%AE%A2.pdf
