# ReCreators

> 分类：Misc

## 题目描述

下回来一个无后缀文件，需要先判断文件类型（.vmdk 虚拟磁盘），提取其中的 mp4，从末尾的 16 进制字符串解密出 flag。

## 考察知识点

- 文件类型识别（.vmdk）
- 磁盘镜像提取（FTK Imager）
- 多层编码解码（Hex/Base32/Base64）

## 解法

1. **修复文件后缀**：010Editor 打开发现是 `.vmdk` 文件，加后缀后用 FTK Imager 打开，提取出 `misc.mp4`。

2. **提取 16 进制字符串**：010Editor 打开 mp4（Re:CREATORS 片头），靠近末尾处有一大串数字字符，推测是 16 进制。

3. **多层解密**，顺序如下：
   - HexDecode 两次
   - Base32Decode 三次
   - Base64Decode 两次
   - HexDecode 一次
   - Base32Decode 一次
   - Base64Decode 两次

## 参考答案

`flag{wh4t_a_w0nderfu1_d4y}`

## 来源

- 作者：Xhy | https://blog.xhyeax.com/2019/01/26/icq-2nd-happy-rec/
