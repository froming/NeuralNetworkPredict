# CrackMe

> 分类：Reverse

## 题目描述

Windows 逆向，含 TLS 回调反调试、CRC 校验、IDEA 算法加密。flag 分三段验证。

## 考察知识点

- TLS 回调
- CRC32 校验
- IDEA 算法

## 解法

1. 通过 TLS 回调、GetDlgItemTextA 获取输入。
2. 验证前 5 位为 `flag{`（异或 0xBB）。
3. 第 6-12 位（7 字符）做 CRC + 异或加密，逆向得到 `moshui_`。
4. 第 13-28 位（16 字节）用 IDEA 算法加密（密钥由 CRC 结果生成），逆向得到 `build_this_block`。
5. 第 29 位为 `}`。

拼接 flag：

```c
flag{moshui_build_this_block}
```

## 参考答案

`flag{moshui_build_this_block}`

## 来源

- 作者：Q7h2q9 | https://www.cnblogs.com/Q7h2q9/p/18817669
