# Lake

> 分类：Reverse

## 题目描述

Pascal 语言 PE64 文件。VM 虚拟机（加减乘除取余与或异或）+ 移位加密，两层加密。

## 考察知识点

- Pascal 逆向
- VM 虚拟机逆向
- 移位加密逆向

## 解法

1. 动调找到主逻辑（sub_100001B70）。
2. 第一层加密：VM 虚拟机，读取指令（操作码/操作对象/操作数），执行加减乘除取余与或异或。
3. 第二层加密：`sub_1000019B0` 做移位加密（每 4 字节一组重组）。
4. 逆向两步加密得到 flag：

```c
// 先逆移位
void decrypt_func(unsigned char *data, int len) {
    unsigned char temp[40];
    memcpy(temp, data, 40);
    for (int i = 0; i < 10; i++) {
        int base = 4 * i;
        unsigned char block[4];
        block[0] = ((temp[base+2] & 0x1F) << 5) | (temp[base+3] >> 3);
        block[1] = (temp[base] >> 3) | ((temp[base+3] & 0x07) << 5);
        block[2] = ((temp[base] & 0x07) << 5) | (temp[base+1] >> 3);
        block[3] = ((temp[base+1] & 0x07) << 5) | (temp[base+2] >> 3);
        for (int j = 0; j < 4; j++) data[base+j] = block[j];
    }
}
// 再逆 VM（加减乘除异或取反）
```

## 参考答案

`flag{L3@rn1ng_1n_0ld_sch00l_@nd_g3t_j0y}`

## 来源

- 作者：Q7h2q9 | https://www.cnblogs.com/Q7h2q9/p/18817669
- 作者：hanafuda_store | https://hanafudastore.github.io/2025/04/21/XYCTF%202025%E5%A4%8D%E7%8E%B0/index.html
