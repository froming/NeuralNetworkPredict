# EzObf

> 分类：Reverse

## 题目描述

VMP 混淆题。main 在 `.vmpt` 区段，指令被打散（push/pop 垃圾指令 + jmp rax）。核心是魔改 XXTEA（Delta 改为 0x61C88646，密钥随机生成，轮数 7）。

## 考察知识点

- VMP 去混淆
- XXTEA 算法（魔改 Delta）

## 解法

1. 用 IDA 脚本去混淆（nop 掉垃圾指令，恢复真实跳转）。混淆只是把指令打散了（pushfq/push 寄存器 + pop + jmp rax）。

2. 反编译后识别为 XXTEA，Delta 改为 `0x61C88646`，密钥靠 `srand(0xAABB)` + rand 生成，加密轮数固定 7。

3. 解密：

```c
#define DELTA 0x61C88646
#define MX (((z>>5^y<<2) + (y>>3^z<<4)) ^ ((sum^y) + (key[(p&3)^e] ^ z)))

void btea(uint32_t *v, int n, uint32_t const key[4]) {
    // 解密部分 rounds = 7
    n = -n;
    rounds = 7;
    sum = rounds * DELTA;
    // ...
}

int main() {
    uint32_t v[8] = {0xA9934E2F, 0x030B90FA, ...};
    uint32_t k[4] = {};
    srand(0xAABB);
    for (int j = 0; j < 4; ++j) k[j] = rand();
    btea(v, -8, k);
    printf("%.32s\n", v);
}
```

## 参考答案

`flag{th15_15_51mpLe_obf_R19Ht?}`

## 来源

- 作者：Astral Prisma | https://astralprisma.github.io/2025/04/08/xy_25/
- 作者：Q7h2q9 | https://www.cnblogs.com/Q7h2q9/p/18817669
