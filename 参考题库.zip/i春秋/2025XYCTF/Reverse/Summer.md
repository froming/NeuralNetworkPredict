# Summer

> 分类：Reverse

## 题目描述

Haskell 函数式编程逆向。惰性计算，密钥解密后对输入做 RC4 + 异或加密。

## 考察知识点

- Haskell 逆向
- 惰性计算
- RC4 加密

## 解法

1. 动调，断在 `ghczminternal_GHCziInternalziList_length_info`（检测长度的函数）看密文和密钥长度。
2. 密钥解密后对用户输入做 RC4 + 异或加密。
3. 逆向 RC4 得到 flag。

（惰性列表存储类似链表，头指针后跟存储的数；需下内存读写断点跟踪比较逻辑）

## 参考答案

（flag 通过 RC4 逆向得到，官方 WP 见 CSDN 小杉泽）

## 来源

- 作者：Q7h2q9 | https://www.cnblogs.com/Q7h2q9/p/18817669
