# Moon

> 分类：Reverse

## 题目描述

Python pyd 逆向。moon.pyd 提供 `xor_crypt(seed, data)` 和 `check_flag()`。

## 考察知识点

- Python C 扩展逆向
- XOR 加密（可逆）

## 解法

用 `help(moon)` 查看模块，发现 `SEED = 1131796`（即 0x114514）和 `TARGET_HEX`（密文）。异或可逆，直接黑盒调用 `xor_crypt` 传入密文得到明文：

```python
import moon
import binascii

target_bytes = binascii.unhexlify(moon.TARGET_HEX)
flag_bytes = moon.xor_crypt(moon.SEED, target_bytes)
print(flag_bytes)
```

## 参考答案

`flag{but_y0u_l00k3d_up_@t_th3_mOOn}`

## 来源

- 作者：Q7h2q9 | https://www.cnblogs.com/Q7h2q9/p/18817669
- 作者：hanafuda_store | https://hanafudastore.github.io/2025/04/21/XYCTF%202025%E5%A4%8D%E7%8E%B0/index.html
