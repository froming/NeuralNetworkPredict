# WARMUP

> 分类：Reverse

## 题目描述

VBScript 逆向。`Execute(chr(...) & chr(...) ...)` 拼接后执行，内含 RC4 加密验证。

## 考察知识点

- VBScript 逆向
- RC4 加密

## 解法

把 VBS 文件开头的 `Execute` 改为 `wscript.echo` 运行，输出源码。发现是 RC4 加密，key 为 `rc4key`，密文已知。

RC4 解密（C 或 Python）得到 flag：

```
flag{We1c0me_t0_XYCTF_2025_reverse_ch@lleng3_by_th3_w@y_p3cd0wn's_chall_is_r3@lly_gr3@t_&_fuN!}
```

计算该 flag 的 MD5 即为最终答案。

## 参考答案

`XYCTF{5f9f46c147645dd1e2c8044325d4f93c}`

## 来源

- 作者：Astral Prisma | https://astralprisma.github.io/2025/04/08/xy_25/
- 作者：Q7h2q9 | https://www.cnblogs.com/Q7h2q9/p/18817669
- 作者：hanafuda_store | https://hanafudastore.github.io/2025/04/21/XYCTF%202025%E5%A4%8D%E7%8E%B0/index.html
