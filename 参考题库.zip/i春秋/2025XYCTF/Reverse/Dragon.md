# Dragon

> 分类：Reverse

## 题目描述

LLVM 字节码（.bc）文件。魔改 CRC64 校验，每 2 字节爆破。

## 考察知识点

- LLVM IR 逆向
- CRC64 爆破

## 解法

1. 用 clang 编译 `.bc`（或 llvm-dis 反汇编），拖 IDA 分析。
2. 识别为魔改 CRC64 算法（多项式 `0x42F0E1EBA9EA3693`），每 2 字节与目标 CRC 值比较。
3. 爆破：

```python
def calculate_crc64_direct(data):
    crc = 0xFFFFFFFFFFFFFFFF
    for byte in data:
        crc ^= (byte << 56)
        crc &= 0xFFFFFFFFFFFFFFFF
        for _ in range(8):
            msb = crc & (1 << 63)
            crc = (crc << 1) & 0xFFFFFFFFFFFFFFFF
            if msb:
                crc ^= 0x42F0E1EBA9EA3693
    return crc ^ 0xFFFFFFFFFFFFFFFF

for target in enc:
    for c1 in range(32, 127):
        for c2 in range(32, 127):
            if calculate_crc64_direct([c1, c2]) == target:
                print(chr(c1) + chr(c2), end='')
```

## 参考答案

`flag{LLVM_1s_Fun_Ri9h7?}`

## 来源

- 作者：Q7h2q9 | https://www.cnblogs.com/Q7h2q9/p/18817669
- 作者：hanafuda_store | https://hanafudastore.github.io/2025/04/21/XYCTF%202025%E5%A4%8D%E7%8E%B0/index.html
