# reed

> 分类：Crypto

## 题目描述

仿射密码。flag 中间段（字母+数字）被 `c = (a * index + b) mod 19198111` 仿射加密，a、b 由 PRNG 生成（`1145140 <= a,b <= 19198100`）。

## 考察知识点

- 仿射密码
- PRNG 种子预测（极小 a、b 时）

## 解法

考虑 a、b 均为极小值的情况，此时 `a * index + b` 不足以被 mod。连接靶机获取数据，找到一组符合的数据：

```
[3628596, 3628596, 3437163, ...]
```

公差 d=63811（即 a），最小值 3118108。得到偏移量：

```
[8, 8, 5, 4, 8, 5, 56, 53, 38, 57, 58, 46, 47, 53, 48, 42, 53, 43, 43, 47, 58, 61, 48, 55, 57, 44, 47, 41, 43, 8, 0, 8, 0, 1, 8, 9]
```

按索引解密得 `iifeif41M56UV1WQ1RRV69W35SVPRiaiabij`，考虑 a 为负值，用 `61 - index` 计算：

```python
import string
table = string.ascii_letters + string.digits
# ...
for i in range(len(m)):
    print(table[61 - m[i]], end="")
```

## 参考答案

`XYCTF{114514fixedpointissodangerous1919810}`

## 来源

- 作者：Astral Prisma | https://astralprisma.github.io/2025/04/08/xy_25/
- 作者：Ramoor | https://ramoor.github.io/2025/04/16/XYCTF%202025%20Writeup/
