# Complex_signin

> 分类：Crypto

## 题目描述

复数 RSA。m 是复数，`c = m^3 mod n`，泄露 m 的高位（实部虚部各高 128 位），用 ChaCha20 加密 flag。

## 考察知识点

- 复数加密
- coppersmith（二元/结式消元）

## 解法

从实部虚部分别看：

```
m_re = mh_re + x
m_im = mh_im + y
C ≡ (m_re + m_im)^3 mod n
C_re ≡ (mh_re+x)^3 - 3(mh_re+x)(mh_im+y)^2
C_im ≡ -(mh_im+y)^3 + 3(mh_im+y)(mh_im+x)^2
```

用二元 coppersmith 或结式消元求 x、y：

```python
R.<x,y> = PolynomialRing(Zmod(n))
f1 = (mh[0] + x)^3 - 3*(mh[0] + x)*(mh[1] + y)^2 - C[0]
f2 = 3*(mh[1] + y)*(mh[0] + x)^2 - (mh[1] + y)^3 - C[1]

# 结式消元
h1 = f1.sylvester_matrix(f2, y).det()
h2 = f2.sylvester_matrix(f1, x).det()
x_roots = h1.univariate_polynomial().monic().small_roots(X=2**128, beta=0.4, epsilon=0.01)
y_roots = h2.univariate_polynomial().monic().small_roots(X=2**128, beta=0.4, epsilon=0.01)

m_re = mh[0] + int(x_roots[0])
m_im = mh[1] + int(y_roots[0])

ans = ChaCha20.new(key=hashlib.sha256(str(m_re + m_im).encode()).digest(), nonce=b'Pr3d1ctmyxjj').decrypt(enc)
```

## 参考答案

`XYCTF{Welcome_to_XYCTF_Now_let_us_together_play_Crypto_challenge}`

## 来源

- 作者：Ramoor | https://ramoor.github.io/2025/04/16/XYCTF%202025%20Writeup/
