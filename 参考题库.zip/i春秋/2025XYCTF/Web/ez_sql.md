# ez_sql

> 分类：Web

## 题目描述

登录框 SQL 注入。盲注出 key，登录后可命令执行（无回显）。

## 考察知识点

- SQL 盲注（异或绕过过滤、%09 绕过空格）
- 无回显命令执行（写文件）

## 解法

1. 登录框存在 SQL 盲注。过滤了 `or`（用异或 `^` 绕过）、空格（用 `%09`）、`union`、`and` 等。

2. 盲注出 `secret` 字段：

```python
sql = f"admin'^((select count({column}) from {table})={i})#".replace(' ','%09')
```

3. 登录后命令执行无回显，过滤空格，用 `$IFS$9` 绕过写文件：

```cmd
cat$IFS$9/f*>1.txt
```

## 参考答案

（flag 通过盲注 + 命令执行写文件后读取）

## 来源

- 作者：竹言笙熙 | https://blog.csdn.net/oyf3085227433/article/details/147075769
