# Now you see me 1

> 分类：Web

## 题目描述

Flask SSTI，但 ban 了大量字符和传统入口类（`_`、单双引号、`{{`、`}}`、`[`、`]`、`/`、`os`、`subprocess`、`g.` 等），且删除了 RCE 方法（os.popen/system、subprocess）。fenjing 打不了。flag 在 `/flag_h3r3`（一个 deepsound 隐写的 MP3）。

## 考察知识点

- Flask SSTI（request 对象）
- `request.endpoint` 构造任意字符
- importlib.reload 恢复被删函数
- audithook 绕过

## 解法

1. **闭合注释**：渲染语句是 `render_template_string('{#'+f'{name}'+'#}')`，需在开头加 `#}` 闭合注释。

2. **构造字符**：`request.endpoint` 返回路由函数名 `r3al_ins1de_th0ught`，可从中取 'd','a','t' 拼出 `data`。用 `request.data`（请求体）传入字符表，通过 `~` 拼接构造任意字符串。

3. **恢复 RCE**：用 `importlib.reload` 恢复被删除的 `os.popen`/`subprocess.Popen`（audithook 限制 exec/compile 次数，reload 恰好不超）。

4. 最终用继承链打 RCE 下载 `/flag_h3r3`。

核心 payload 结构（详见出题人 exp）：

```
Follow-your-heart-%23}{%for i in request.endpoint|slice(1)%}{%set dat=i.9~i.2~i.12~i.2%}{%for k in request|attr(dat)|string|slice(1)%}...{%endfor%}{%endfor%}
```

请求体：`_ .-0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ/`

下载到 `/flag_h3r3` 是 MP3，deepsound 隐写解出 flag。

## 参考答案

`flag{N0w_y0u_sEEEEEEEEEEEEEEE_m3!!!!!!}`

## 来源

- 作者：LamentXU（出题人） | https://www.cnblogs.com/LAMENTXU/articles/18730353
