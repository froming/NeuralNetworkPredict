# MADer也要当CTFer

> 分类：Misc

## 题目描述

视频题。视频字幕中隐藏十六进制内容，提取后是 AE（After Effects）文件，图层里藏着 flag。

## 考察知识点

- 视频字幕提取
- 十六进制转文件
- AE 工程分析

## 解法

1. 视频字幕是十六进制内容，用 potplayer 观察，用小丸工具箱（或 ffmpeg）提取 ass 字幕。
2. 脚本提取十六进制，转 ASCII 发现是 `RIFX` 文件头（AE 文件，后缀 .aep）。
3. 用 AE 打开（或缺插件，直接在 notepad 里找 leet 编码内容），图层里发现 flag。

## 参考答案

`flag{l_re@IIy_w@nn@_2_Ie@rn_AE}`

## 来源

- 作者：玫幽倩 | https://mei-you-qian.github.io/2025/10/28/XYCTF/
- 作者：竹言笙熙 | https://blog.csdn.net/oyf3085227433/article/details/147075769
