# sins

> 分类：Misc

## 题目描述

Python jail。输入只包含特定字符、长度 16 以内的字符串，通过 lambda + eval 构造。

## 考察知识点

- Python jail
- lambda 表达式

## 解法

eval 执行 lambda 函数（空字典 globals/locals），lambda 带参数 i，命名了一个函数。答案是 `f = lambda i:'1i--'[i%4::-2] *` 的构造（利用字符串切片技巧）。

## 参考答案

（flag 通过 lambda 表达式构造获得）

## 来源

- 作者：玫幽倩 | https://mei-you-qian.github.io/2025/10/28/XYCTF/
