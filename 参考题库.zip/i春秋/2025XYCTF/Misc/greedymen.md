# greedymen

> 分类：Misc

## 题目描述

源自经典数字游戏 taxman game（税务员游戏）。黑盒题，需通过贪心算法策略赢得游戏。

## 考察知识点

- 贪心算法
- taxman game 最优策略

## 解法

游戏规则：1/2/3 级有以 19/37/76 开头的计数器，每选择一个数字（其因子未被选过），选中的数归你，其所有因子归对手，计数器减 1。

贪心策略：每次选择"净收益最大"的数（数本身 - 其可用因子之和）：

```python
def choose_numbers_with_all_choices(level):
    max_number = {1: 50, 2: 100, 3: 200}[level]
    counter = {1: 19, 2: 37, 3: 76}[level]
    factors = {n: [i for i in range(1, n) if n % i == 0] for n in range(1, max_number+1)}
    chosen = set()
    while counter > 0:
        best_net = -float('inf'); best_num = None
        for n in range(1, max_number+1):
            if n in chosen: continue
            available = [f for f in factors[n] if f not in chosen]
            if not available: continue
            net = n - sum(available)
            if net > best_net:
                best_net = net; best_num = n
        chosen.add(best_num)
        for f in factors[best_num]: chosen.add(f)
        counter -= 1
    ...
```

## 参考答案

（flag 通过贪心算法赢得游戏获得）

## 来源

- 作者：LamentXU（出题人） | https://www.cnblogs.com/LAMENTXU/articles/18730353
- 作者：竹言笙熙 | https://blog.csdn.net/oyf3085227433/article/details/147075769
