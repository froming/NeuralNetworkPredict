# XGCTF

> 分类：Misc

## 题目描述

OSINT 题。找到 XGCTF（2024 西瓜杯）中 LamentXU 出的唯一题，找到对应原题（CISCN 华东华南 "pollute"），再到 dragonkeep 博客找 flag（博客源码里 base64 编码）。

## 考察知识点

- OSINT
- base64 解码

## 解法

1. 在 ctfshow 找 XGCTF wp，发现 web3 相关字符，确定 LamentXU 出的题是 CISCN 华东华南的 "pollute"。
2. 搜索找到 dragonkeep 博客（域名在 dragonkeep 基础上多个字母：`dragonkeeep.top`）。
3. 查看博客网页源代码（Ctrl+U），找到 base64 编码的 flag，解码得到 flag。

## 参考答案

`flag{1t_I3_t3E_s@Me_ChAl1eNge_aT_a1L_P1e@se_fOrg1ve_Me}`

## 来源

- 作者：Q7h2q9 | https://www.cnblogs.com/Q7h2q9/p/18817669
- 作者：玫幽倩 | https://mei-you-qian.github.io/2025/10/28/XYCTF/
- 作者：竹言笙熙 | https://blog.csdn.net/oyf3085227433/article/details/147075769
