# 免费的，ping 一下~

> 分类：Web（第三届广东省强网杯）

## 题目描述

ping 命令注入，需绕过空格、关键字过滤读取 flag。

## 考察知识点

- 命令注入
- 空格绕过（$IFS / ${IFS}）
- 关键字绕过（双引号）

## 解法

1. 可输入 ip 并 ping，存在命令注入（`;ls;` 成功）。
2. 命令带空格会被拦截，用 `${IFS}` 或 `$IFS$9` 代替空格。
3. `cat`/`head`/`tail` 等读取命令和 `flag` 关键字被拦截，用中间加双引号绕过：`c""at${IFS}/fl""ag`。
4. 提示 flag 不在第一行，用 `tail /flag -n +3` 读取，爆破发现 flag 在第 16 行。

## 参考答案

（flag 通过命令注入 + 绕过过滤读取 /flag 第16行）

## 来源

- 作者：TimeShatter | https://blog.csdn.net/qq_28205153/article/details/102899260
