# php

> 分类：Web（第三届广东省强网杯）

## 题目描述

eval 代码执行，但过滤了字母数字下划线等字符，需用特殊字符取反构造。

## 考察知识点

- 无字母数字 RCE
- 特殊字符取反构造字母（~取反）

## 解法

1. 源码获取 code 参数内容传入 eval 执行，但过滤了字母、数字、下划线等特殊字符。
2. 利用 `('phpinfo')();` 方式执行字符串，通过特殊字符取反构造字母（如 `~0xb8` 取反为字母 G）。
3. 生成 GetYourFlag 的取反十六进制值，每两个字符前加 % 构造 URL 编码。

payload：

```
/index.php?code=(~%b8%9a%8b%a6%90%8a%8d%b9%93%9e%98)()
```

## 参考答案

（flag 通过取反构造 GetYourFlag() 获取）

## 来源

- 作者：TimeShatter | https://blog.csdn.net/qq_28205153/article/details/102899260
