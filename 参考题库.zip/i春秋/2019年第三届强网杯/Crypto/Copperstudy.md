# Copperstudy

> 分类：Crypto（2019 第三届强网杯·全国赛）

## 题目描述

Coppersmith 攻击系列题目，共 6 关（Challenge1~6），分别考察 RSA 的不同攻击方法。

## 考察知识点

- Coppersmith 攻击（高位泄露、p 高位泄露、d 低位泄露）
- 广播攻击（Broadcast Attack）
- Related Message Attack
- Boneh-Durfee 攻击

## 解法

**Challenge1**：e=3，已知明文 m 的高位（72 位泄露），用 Coppersmith 求低位 x：

```python
PR.<x> = PolynomialRing(Zmod(n))
f = (x + m0)^e - c
x0 = f.small_roots(X=2^kbits, beta=1)[0]
```

**Challenge2**：已知 p 的高位（128 位），Coppersmith 求低位：

```python
PR.<x> = PolynomialRing(Zmod(n))
f = x + p4
x0 = f.small_roots(X=2^kbits, beta=0.4)[0]
```

**Challenge3**：已知 d 的低 512 位，用 `find_p` 恢复 p、d。

**Challenge4**：同一明文 m 用 3 个不同 n 加密（e=3），广播攻击，中国剩余定理 + 开三次方。

**Challenge5**：两个明文 m 和 m+1，Related Message Attack：

```python
def getmessage(a, b, c1, c2, n):
    b3 = gmpy2.powmod(b, 3, n)
    part1 = b * (c1 + 2*c2 - b3) % n
    part2 = a * (c1 - c2 + 2*b3) % n
    part2 = gmpy2.invert(part2, n)
    return part1 * part2 % n
```

**Challenge6**：d < N^0.292，Boneh-Durfee 攻击（改 boneh_durfee.sage 参数）。

最终 flag 通过 6 关后获得。

## 参考答案

`flag{21fd94b1604569b12ac238ad755b03262fa371c70f6775999b84d2dcfc05cddc}`

## 来源

- 作者：Soreat_u | https://blog.soreatu.com/posts/writeup-for-crypto-problems-in-qwb-2019/
