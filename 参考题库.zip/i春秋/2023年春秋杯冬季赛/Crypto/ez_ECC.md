# ez_ECC

> 分类：Crypto

## 题目描述

ECDSA 泄露大量数据题。构造了自定义的 Random_EC 随机数生成器（Dual EC PRNG 变种），循环 250 次给出 C、Hint（RSA 加密的 hint）、pub_key、P、Q、sign1、sign2、into_secret。

## 考察知识点

- Dual EC DRNG 漏洞（NSA 后门）
- ECDSA 随机数预测
- RSA 解密（leak = p+q 分解）
- 椭圆曲线 lift_x

## 解法

本题为难题，作者未做出（mark 为 \*），仅提供题目源码与 output。核心思路：

1. **Random_EC** 使用了类似 Dual EC DRNG 的随机数生成（`state = (state * P).x()`），P、Q 已给出，存在后门可预测随机数。
2. `RSA_reinforce` 中 `leak = p + q`，可解二次方程分解 n 得到 p、q，解密 hint。
3. `C = flag ^^ secret`，`into_secret = Key * lift_x(secret)`，通过预测 Random_key 还原 secret。
4. sign1/sign2 用相同 k（`sign2 = SIGN.sign(m2, sign1[2])`），可通过 ECDSA 相同 nonce 攻击还原私钥，进而预测后续随机数。

（作者未给出完整解题脚本，此题作为学习参考）

## 参考答案

（未给出，作者未解出）

## 来源

- 作者：mumuhhh | https://www.cnblogs.com/mumuhhh/p/17981128
