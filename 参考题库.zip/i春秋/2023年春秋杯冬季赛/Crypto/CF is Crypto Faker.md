# CF is Crypto Faker

> 分类：Crypto（签到）

## 题目描述

"学过 AI 的都知道，这题不是纯密码"。题目给定了 n、r、trained_phi、trained_e、两个密文，直接求 d 解 RSA 即可。

## 考察知识点

- RSA 基础
- 从输出中提取正确的 phi 和 e

## 解法

题目把 `trained_phi` 和 `trained_e`（训练后的"正常"参数）直接给出，其实 `trained_phi` 就是正确的 `phi0 = (p-1)*(q-1)`，`trained_e` 就是加密指数 e。直接求 d 解两个密文：

```python
import gmpy2
from Crypto.Util.number import *

n = 0x81c5f040bfaea676120cd62c36ba7afb303561504bbf8609afa3da60fb6202ca875b0bd2a06143ebcd16fa615557ff159d97909160d68e1938b3ecaf57709b3d2698476b6dd203811b6a2ec6a6e2a7e213ab719bcd3ab49bb864b10e9c78ea3f501c0e2213dfe431043bb6f0cc2e8d77bfb43869b843af1a99ae81b87811e101
r = 0x4f37fe985d13ffde9867fa0063f68dea79196408b1404eadf03ea59297d629c2183a4a6a6647b6c4c99dd43bae8c4fa4691a608d20170fd42b18aef7efb3ae01cd3
phi = 0x81c5f040bfaea676120cd62c36ba7afb303561504bbf8609afa3da60fb6202ca875b0bd2a06143ebcd16fa615557ff159d97909160d68e1938b3ecaf57709b3bb712fdcba325655f111918472d4353a66854ccda50b63a1047278c15a4b39cde898d054db87092958c7c05f8fa566dcd969b1ff4b7d1935c375a4af3bfc341b0
e = 0x2c22193ad9abcca2f67552fc76dd07b3ef883f3d755c95119cdf82bb6a07c970fd37e582bb49250d8efaa29b8a59c82059165c654206a9d7261f6b45a90dc69
c1 = 0x29289e3d9275147b885b5061637564cbee3e4d9f48e52694e594f020e49da9b24d9246b2437fb2221fa86ca1a277f3fdd7ab5cad4738a02b66d47703ef816844a84c6c209c8251e8961c9ba2c791649e022627f86932d9700c3b1dc086e8b2747d0a5604955387a935464d3866dd4100b2f3d57603c728761d1d8ef7fdbdcbee
c2 = 0x2b0059f88454e0e36269c809b5d5b6b28e5bab3c87b20f9e55635239331100a0a582241e7a385034698b61ebf24b519e868617ff67974cc907cc61be38755737f9a6dbeb7890ff55550b1af1ecf635112fcaaa8b07a3972b3c6728cbcf2a3973a4d7bd92affec7e065e0ae83cd36858e6d983785a3668a8b82709d78a69796af

d = gmpy2.invert(e, phi)
m1 = pow(c1, d, n)
m2 = pow(c2, d, n)
print(long_to_bytes(m1) + long_to_bytes(m2))
```

## 参考答案

`flag{With the method of machine learning, it is available for Crypto-er to develop the modern cryptography.Don't give up learning crypto.}`

## 来源

- 作者：mumuhhh | https://www.cnblogs.com/mumuhhh/p/17981128
- 作者：DexterJie | https://dexterjie.github.io/2024/01/27/赛题复现/2023春秋杯冬季赛/
