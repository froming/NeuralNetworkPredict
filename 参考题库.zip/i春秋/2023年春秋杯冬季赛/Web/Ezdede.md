# Ezdede

> 分类：Web

## 题目描述

DedeCMS（织梦）类题目，直接利用短标签读取 flag。

## 考察知识点

- 短标签（short open tag）写入/执行
- 文件读取

## 解法

直接传一个短标签 `<?=readfile('/flag')?>`，然后访问即可直接读取 flag。

## 参考答案

（flag 通过短标签 readfile 读取 `/flag`）

## 来源

- 作者：末 初 | https://blog.csdn.net/mochu7777777/article/details/135760457
