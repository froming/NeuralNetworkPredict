# book

> 分类：Pwn

## 题目描述

经典菜单堆题，`delete` 存在 UAF，`show` 与 `edit` 没有检查，且没有限制申请大小，可用 house of apple / house of cat 打。

## 考察知识点

- UAF（Use-After-Free）
- largebin attack
- house of apple / house of cat（IO 利用）
- tcache poisoning

## 解法

漏洞点：

```c
void delete() { free(*((void **)&heap + v0)); }        // UAF
int show()  { return puts(*((const char **)&heap + v1)); }
char *edit() { return fgets(*((char **)&heap + v1), chunk[v1], stdin); }
```

利用思路：
1. 通过 UAF 泄露 heap_base。
2. 分配 unsorted bin 块，free 后泄露 libc 地址。
3. house of cat 伪造 IO_FILE，构造 one_gadget 或 magicgadget。
4. 触发 `_IO_list_all`，执行 one_gadget 拿到 shell。

关键点：house of cat 需要构造 `_IO_write_base < _IO_write_ptr`、伪造 vtables、springboard 等。

```python
payload = house_of_cat(heap_base + 0x7d0, vtables, magicgadget, 0x10, heap_base + 0x1100)
edit(3, payload)
choice(5)
sl(b'cat flag')
```

（本地无概率问题，远程最后加个 `cat flag` 基本命中）

## 参考答案

（flag 通过 house of cat 打 one_gadget 后读取）

## 来源

- 作者：末 初 | https://blog.csdn.net/mochu7777777/article/details/135760457
