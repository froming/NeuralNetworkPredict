# nmanager

> 分类：Pwn

## 题目描述

菜单堆题，`modify` 没有范围限制（任意写），校验函数的 seed 可本地复现，leak libc 后 ogg 一把梭。

## 考察知识点

- 任意地址写
- libc 地址泄露
- one_gadget（ogg）
- 栈迁移（rbp 到 bss）

## 解法

1. 校验函数的 seed 用 `time(0)`，本地跟着跑一个即可，爆破出 password。
2. `modify` 函数没有范围限制，基本任意写，然后输出泄露 libc。
3. leak 出 libc 后 one_gadget 一把梭。没有直接能用的 ogg，把 rbp 弄到 bss 上即可。

核心思路：

```python
seed = libc.time(0)
libc.srand(seed)
value = int.to_bytes(ch[libc.rand() % 62], 1, 'little')
# ... 通过 modify 任意写泄露 libc_base
libc_base = u64(ru(b'\x7f')[-6:].ljust(0x8, b'\x00')) - 0x29d90
ogg = libc_base + onegadget[0]
# 将 rbp 弄到 bss，写 ogg
```

## 参考答案

（flag 通过 one_gadget 拿到 shell 后读取）

## 来源

- 作者：末 初 | https://blog.csdn.net/mochu7777777/article/details/135760457
