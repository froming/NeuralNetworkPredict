# RSA_revenge

> 分类：Crypto

## 题目描述
本题考查费马小定理、欧拉定理和爆破。

## 考察知识点
- 费马小定理
- 欧拉定理
- 爆破

## 解法
（官方 WriteUp 未给出详细解题过程，仅说明考察费马小定理、欧拉定理和爆破。一般思路为利用费马小定理/欧拉定理约简指数，再对部分小规模未知量进行爆破，最终恢复明文。）

## 参考答案
（未给出）

## 来源
- 作者：NewStar CTF 2025 官方 WriteUp | https://newstar.wiki/wp/2025/week2/crypto/rsa-revenge.html
