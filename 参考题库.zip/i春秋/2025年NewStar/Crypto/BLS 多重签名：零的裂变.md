# BLS 多重签名：零的裂变

> 分类：Crypto

## 题目描述
BLS（Boneh-Lynn-Shacham）多重签名系统中的零公钥攻击。题目要求提供的三个公钥聚合结果等于服务器公钥，利用 BLS 线性特性构造两个私钥之和为 0（模 order）的密钥对绕过检查。

## 考察知识点
- BLS 签名基本概念与线性特性
- 多重签名聚合验证
- 零公钥攻击（未检测零公钥）

## 解法

### BLS 基础知识
- 私钥 `sk` 为随机数，公钥 `pk = sk × G`，签名 `σ = sk × H(m)`。
- BLS 线性特性：公钥可叠加 `pk1 + pk2 = (sk1 + sk2) × G`，签名可叠加 `σ1 + σ2 = (sk1 + sk2) × H(m)`。
- 多重签名验证：`e(聚合公钥, H(m)) = e(G, 聚合签名)`。

### 漏洞分析
题目检查：

```python
agg_pk = bls._AggregatePKs(pks_bytes)
if agg_pk != self.pk_server:
    return False, "Aggregate PK must equal server PK"
```

利用线性特性，若 `sk1 + sk2 = 0 (mod order)`，则 `pk1 + pk2 = 0 × G = 0`，于是 `pk1 + pk2 + pk_server = pk_server`，绕过聚合公钥检查。

### 解题步骤
1. 生成攻击密钥对：`x1 = 1337`，`pk1 = SkToPk(x1)`；`x2 = order - x1`，`pk2 = SkToPk(x2)`。
2. 分别用两个私钥对 `"POP"` 签名注册两个公钥。
3. 请求服务器对 `"get_flag"` 签名。
4. 提交三个公钥与服务器签名获取 FLAG。

完整 EXP：

```python
#!/usr/bin/env python3
from pwn import *
import json
from py_ecc.bls import G2ProofOfPossession as bls

# BLS12-381 曲线参数
order = 52435875175126190479447740508185965837690552500527637822603658699938581184513

def solve(host='127.0.0.1', port=9999):
    io = remote(host, port)
    try:
        # 1. 获取服务器信息
        io.sendline(json.dumps({'type': 'get_info'}).encode())
        response = json.loads(io.recvline().decode())
        server_pk_hex = response['message']['server_pk']

        # 2. 生成攻击密钥对
        x1 = 1337
        pk1 = bls.SkToPk(x1)
        pk1_hex = pk1.hex()
        x2 = order - x1
        pk2 = bls.SkToPk(x2)
        pk2_hex = pk2.hex()

        # 3. 注册公钥
        pop1 = bls.Sign(x1, b"POP").hex()
        io.sendline(json.dumps({'type': 'register', 'pk': pk1_hex, 'pop': pop1}).encode())
        response = json.loads(io.recvline().decode())

        pop2 = bls.Sign(x2, b"POP").hex()
        io.sendline(json.dumps({'type': 'register', 'pk': pk2_hex, 'pop': pop2}).encode())
        response = json.loads(io.recvline().decode())

        # 4. 获取服务器签名
        io.sendline(json.dumps({'type': 'sign', 'msg': 'get_flag'}).encode())
        response = json.loads(io.recvline().decode())
        server_sig_hex = response['message']

        # 5. 构造攻击获取 FLAG
        pks_list = [pk1_hex, pk2_hex, server_pk_hex]
        io.sendline(json.dumps({'type': 'get_flag', 'pks': pks_list, 'sig': server_sig_hex}).encode())
        response = json.loads(io.recvline().decode())

        if response['success']:
            print("FLAG:", response['message'])
    finally:
        io.close()

if __name__ == '__main__':
    context.log_level = 'info'
    solve()
```

## 参考答案
（未给出）

## 来源
- 作者：NewStar CTF 2025 官方 WriteUp | https://newstar.wiki/wp/2025/week5/crypto/bls-multisig-zero.html
