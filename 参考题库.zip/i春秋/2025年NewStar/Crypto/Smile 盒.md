# Smile 盒

> 分类：Crypto

## 题目描述
2 轮 CipherFour 分组密码的差分攻击。可无限次输入明文获取密文，猜中 `key2`（16 bit）即可得到 FLAG。已知 S 盒与 P 置换过程，可逆 S 盒与 P 置换，寻找高概率差分进行攻击。

## 考察知识点
- 差分密码分析（差分攻击）
- S 盒差分分布表（DDT）
- 高概率差分路径构造

## 解法

加密过程：16 比特明文与轮密钥 `key0` 异或，分为 4 块 4 比特，过 4-4 S 盒，进行 P 置换（比特拉线），再与 `key1` 异或，过 S 盒，与 `key2` 异或输出。差分定义为 `Δx = x1 ⊕ x2`。

关键点：
- 与轮密钥异或不影响差分：`(m1⊕k1)⊕(m2⊕k1) = m1⊕m2`
- P 置换是线性的，不影响差分
- 只有 S 盒影响差分

攻击关注最后一步：`c = S(p) ^ key2`，拆为 4 个独立 4 bit：`c_i = S(p_i) ^ key2_i`。用逆 S 盒恢复 `p_i = S_(c_i ^ key2_i)`。对 `key2_i` 的每个猜测 `k`，计算明文对的差分 `dp`，若等于高概率差分则投票。

构造差分分布表：

```python
def DDT(S):
    n = len(S)
    ddt = [[0] * n for _ in range(n)]
    for di in range(n):
        for m1 in range(n):
            do = S[m1] ^ S[m1 ^ di]
            ddt[di][do] += 1
    return ddt
```

找到高概率差分：`0xb -> 0xc: 8/16`、`0xf -> 0x3: 8/16`。搓出路径 `0x00b0 -> 0x00c0 -> 0x2000/0x0200`，差分 `0x2` 过 S 盒有 5 种可能输出差分 L，选取密文时先筛选。

参考脚本：

```python
from pwn import remote
from tqdm import tqdm

HOST, PORT = "", 9999
io1 = remote(HOST, PORT, timeout=10)

def enc(io, input):
    io.sendline(input.encode())
    output = io.recvline().decode()[-7:]
    return int(output, 16)

S = (13, 11, 6, 5, 2, 7, 3, 4, 9, 0, 10, 1, 12, 15, 8, 14)
S_ = {x: i for i, x in enumerate(S)}  # 逆 S 盒

def recover(dm, dc, index, tries, io):
    key = [0] * 16
    for m1 in tqdm(range(tries)):
        m2 = m1 ^ dm
        c1 = enc(io, hex(m1))
        c2 = enc(io, hex(m2))
        t = 4 * (3 - index)
        c1_ = (c1 >> t) & 0xF
        c2_ = (c2 >> t) & 0xF
        if c1_ ^ c2_ in dc:
            for k in range(16):
                cc1 = S_[c1_ ^ k]
                cc2 = S_[c2_ ^ k]
                dcc = cc1 ^ cc2
                if dcc == 0x2:
                    key[k] += 1
    print(key)
    maxv = max(key)
    return {v: i for i, v in enumerate(key)}[maxv]

dm1 = 0x00b0
dm2 = 0x00f0
dc0 = [0x1, 0x3, 0x4, 0xb, 0xe]

key0 = recover(dm1, dc0, 0, 2**11, io1)
key1 = recover(dm1, dc0, 1, 2**10, io1)
key2 = recover(dm2, dc0, 2, 2**10, io1)
key3 = recover(dm2, dc0, 3, 2**10, io1)

key_ = (key0 << 12) | (key1 << 8) | (key2 << 4) | key3
print(hex(key_))

io1.sendline("k".encode())
print(io1.recvline().decode())
io1.sendline(hex(key_).encode())
print(io1.recvline().decode())
io1.close()
```

## 参考答案
（未给出）

## 来源
- 作者：NewStar CTF 2025 官方 WriteUp | https://newstar.wiki/wp/2025/week5/crypto/smile-box.html
