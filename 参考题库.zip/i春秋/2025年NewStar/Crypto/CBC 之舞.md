# CBC 之舞

> 分类：Crypto

## 题目描述
基于 AES-CBC 模式的加密题。已知 `IV1`、`IV2`、`m1`、`c1`、`c2`，其中 `c1` 是 `c2` 的四个块经过置换（permutation）后的结果，需利用 CBC 解密公式还原 `m2`。

## 考察知识点
- AES-CBC 模式解密原理（`P_i = Decrypt(C_i) XOR C_{i-1}`）
- 密文块置换关系还原
- 异或运算

## 解法
观察可得 `perm = [3, 0, 2, 1]`（`c1[0]=c2[3], c1[1]=c2[0], c1[2]=c2[2], c1[3]=c2[1]`）。利用 CBC 解密公式，通过 `m1` 与 `c1`/`c2` 建立关系还原四个 `m2` 块：

```python
m20 = xor(xor(m1[3], c1[2]), IV2)
m21 = xor(xor(IV1, m1[0]), c2[0])
m22 = xor(xor(c1[1], m1[2]), c2[2])
m23 = xor(xor(c1[0], m1[1]), c2[1])
```

完整 EXP：
```python
from Crypto.Util.number import long_to_bytes
from pwn import xor

IV1 = 0x1e5d251ea78ef68a1282079fd028c747
IV2 = 0x18777ae4c1a29f4c5db8ba6c5dfe72f1
m1  = 0xf560fd28ed5c5ce7d952eb44b47007e702f42dbb54540dfc78467f48933dbb01ebcf520fd3d23a211d3b4e8c06261966cb178525c25b8058ff792e0f251d3d15
c1  = 0xcaf7bc1223c17f848aec854a87b8958d4c518f7287663bfae0b6a5a1e0f0eb95b50c9ea6789a7d77fda5f50d1b8a2183b40cab693ebacf32a9b59faf3b0084ff
c2  = 0xb40cab693ebacf32a9b59faf3b0084ffcaf7bc1223c17f848aec854a87b8958db50c9ea6789a7d77fda5f50d1b8a21834c518f7287663bfae0b6a5a1e0f0eb95

IV1 = long_to_bytes(IV1); IV2 = long_to_bytes(IV2)
m1 = long_to_bytes(m1); c1 = long_to_bytes(c1); c2 = long_to_bytes(c2)

m20 = xor(xor(m1[-16:],  c1[-32:-16]), IV2)
m21 = xor(xor(IV1, m1[:16]), c2[:16])
m22 = xor(xor(c1[16:32], m1[-32:-16]), c2[16:32])
m23 = xor(xor(c1[:16],  m1[16:32]), c2[-32:-16])
print(m20, m21, m22, m23)
```

## 参考答案
（未给出）

## 来源
- 作者：NewStar CTF 2025 官方 WriteUp | https://newstar.wiki/wp/2025/week3/crypto/cbc-dance.html
