# DLP

> 分类：Crypto

## 题目描述
这是 week2 DLP_1 的升级版，使用到了几个 SageMath 中的函数，其他基础知识在 DLP_1 和 week1 的题目中已有涉及。

## 考察知识点
- 离散对数（DLP）
- 因数分解 + 原根 primitive_root
- 中国剩余定理 crt 合并同余

## 解法
解题脚本如下：

```python
from Crypto.Util.number import long_to_bytes
N =
y =
fac = factor(N)
primes = []
for p, e in fac:
    for _ in range(e):
        primes.append(Integer(p))

residues = []
moduli = []

for idx, p in enumerate(primes, start=1):
    p = Integer(p)
    # 找一个原根 g
    g = primitive_root(p)   # Sage 内置函数
    yi = Integer(y % p)
    d = discrete_log(Mod(yi, p), Mod(g, p))
    residues.append(Integer(d))
    moduli.append(Integer(p - 1))

# 使用中国剩余定理合并所有同余
x_recovered = crt(residues, moduli)
print("Recovered integer x (mod product of moduli) =", x_recovered)

# 4) 把整数转回 bytes -> str
flag_bytes = long_to_bytes(int(x_recovered))
print(flag_bytes)
```

## 参考答案
（未给出）

## 来源
- 作者：NewStar CTF 2025 官方 WriteUp | https://newstar.wiki/wp/2025/extras/crypto/dlp.html
