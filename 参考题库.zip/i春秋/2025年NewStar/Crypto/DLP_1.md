# DLP_1

> 分类：Crypto

## 题目描述
本题考查离散对数问题（Discrete Logarithm Problem）。

## 考察知识点
- 离散对数问题（DLP）

## 解法
（官方 WriteUp 未给出详细解题过程，仅说明考察离散对数问题。一般思路为使用 SageMath 的 `discrete_log` 求解给定群中的离散对数，恢复密钥/明文。）

## 参考答案
（未给出）

## 来源
- 作者：NewStar CTF 2025 官方 WriteUp | https://newstar.wiki/wp/2025/week2/crypto/dlp-1.html
