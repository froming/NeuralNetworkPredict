# 初识 RSA

> 分类：Crypto

## 题目描述
本题考查对 RSA 的简单理解。

## 考察知识点
- RSA 基本原理

## 解法
（官方 writeup 仅给出题目简介，未提供具体解题步骤。）

## 参考答案
（未给出）

## 来源
- 作者：NewStar CTF 2025 官方 WriteUp | https://newstar.wiki/wp/2025/week1/crypto/rsa-intro.html
