# Poly

> 分类：Crypto

## 题目描述
题目将 FLAG 分为两半，分别作为 `m1`、`m2`，计算 `c1 = (m1^19 + m1^18 + 4*m1^17) % p`、`c2 = (5*m2^19 + m2^18 + 4*m2^17) % p`、`s = (m1^7 * m2^2 + m2) % p`，输出 `(p, c1, c2, s)`。利用 Gröbner 基求解。

## 考察知识点
- Gröbner 基（Groebner basis）
- 多元多项式方程组求解

## 解法

题目脚本：

```python
import uuid
p = random_prime(2**256)
f = f"FLAG{{{uuid.uuid4()}}}"
x1 = f[:len(f)//2]
x2 = f[len(f)//2:]
m1 = b2l(x1.encode())
m2 = b2l(x2.encode())
c1 = (m1^19 + m1^18 + 4*m1^17) % p
c2 = (5*m2^19 + m2^18 + 4*m2^17) % p
s = (m1^7 * m2^2 + m2) % p
print((p, c1, c2, s))
```

解题脚本：

```python
def l2b(n: int, length: int = None) -> bytes:
    # 略

def b2l(b: bytes) -> int:
    # 略

R = PolynomialRing(Zmod(p), 'x, y')
x, y = R.gens()
I = Ideal([x^19 + x^18 + 4*x^17 - c1,
           5*y^19 + y^18 + 4*y^17 - c2,
           x^7*y^2 + y - s])
for g in I.groebner_basis():
    print(g)
    a = Zmod(p)(-g.univariate_polynomial()(0))
    print(l2b(int(a)))
```

Gröbner 基方法可从多项式理想的一组生成元计算出另一组性质良好的生成元，用来简化运算，求得多项式公因式/单变量根，从而还原 `m1`、`m2` 并拼出 FLAG。

## 参考答案
（未给出）

## 来源
- 作者：NewStar CTF 2025 官方 WriteUp | https://newstar.wiki/wp/2025/week5/crypto/poly.html
