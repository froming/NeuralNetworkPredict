# SageMath 使用指南

> 分类：Crypto

## 题目描述
安装 sagemath 后运行程序即可。题目文件引用了许多群，并计算它们的阶，然后相乘得到一个大数作为 `key`。

## 考察知识点
- SageMath 使用
- 群的阶计算

## 解法
安装 [sagemath](https://www.sagemath.org/)，直接运行题目程序，它会计算引用的群的阶并相乘得到 key，进而完成解密。

## 参考答案
（未给出）

## 来源
- 作者：NewStar CTF 2025 官方 WriteUp | https://newstar.wiki/wp/2025/week1/crypto/sagemath-guide.html
