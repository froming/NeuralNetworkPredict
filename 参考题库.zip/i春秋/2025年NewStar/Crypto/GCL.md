# GCL

> 分类：Crypto

## 题目描述
LCG 相关分析题。FLAG 转数字得到 `m`，素数 p、两随机数 a,b，序列满足 `s_n = a·s_{n-1}^{-1} + b (mod p)`。`gift` 给出连续 10 项 s，需要求出下一项作为 key 解密 `c = m^key`。

## 考察知识点
- 模逆递推序列（LCG 变体）
- GCD 求模数 p
- 交叉相乘消元

## 解法
先求出 p。由 `s_i = a·s_{i-1}^{-1} + b (mod p)`，两边乘 `s_{i-1}` 消掉模逆，再写一项消掉 a、交叉相乘消掉 b，得到：

```
s_i(s_{i+1} - s_{i-1})(s_{i+1} - s_i) - s_{i+1}(s_{i+2} - s_i)(s_i - s_{i-1}) = 0 (mod p)
```

对相邻项求 GCD 可求出 p（也可能是倍数），之后可再求出 b、a，进而得到下一项 key，解密 `m = c^(key^-1)`。

## 参考答案
（未给出）

## 来源
- 作者：NewStar CTF 2025 官方 WriteUp | https://newstar.wiki/wp/2025/week3/crypto/gcl.html
