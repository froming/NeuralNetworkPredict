# 应急响应：把你 mikumiku 掉（1）

> 分类：Misc

## 题目描述
应急响应系列（1）。查看 tomcat 版本信息为 `9.0.98`，搜索对应 CVE，结合日志确定使用的漏洞编号。

## 考察知识点
- 应急响应 / 日志分析
- Tomcat 版本信息搜集
- CVE 漏洞识别（CVE-2025-24813）

## 解法

1. 查看 tomcat 版本信息，得到版本号 `9.0.98`。
2. 搜索 `tomcat 9.0.98 cve`，得到历史漏洞编号 `CVE-2025-24813`。
3. 结合日志分析异常登录事件：

```
cat localhost_access_log.2025-10-17.txt
```

4. 定位 RDP 登录 IP，确定使用的 CVE 为 **CVE-2025-24813**。

## 参考答案
CVE-2025-24813

## 来源
- 作者：NewStar CTF 2025 官方 WriteUp | https://newstar.wiki/wp/2025/week5/misc/mikumiku-1.html
