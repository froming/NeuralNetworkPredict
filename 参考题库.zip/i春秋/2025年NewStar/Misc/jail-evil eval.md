# jail-evil eval

> 分类：Misc

## 题目描述
（官方 WriteUp 未提供详细内容）

## 考察知识点
- （未给出）

## 解法
（官方 WriteUp 未提供详细解法）

## 参考答案
（未给出）

## 来源
- 作者：NewStar CTF 2025 官方 WriteUp | https://newstar.wiki/wp/2025/week3/misc/jail-evil-eval.html
