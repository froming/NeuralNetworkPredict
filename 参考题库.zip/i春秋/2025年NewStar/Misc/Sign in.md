# Sign in

> 分类：Misc

## 题目描述
签到题。

## 考察知识点
- 签到

## 解法
（官方 writeup 未提供具体内容。）

## 参考答案
（未给出）

## 来源
- 作者：NewStar CTF 2025 官方 WriteUp | https://newstar.wiki/wp/2025/week1/misc/sign-in.html
