# OSINT：威胁情报

> 分类：Misc

## 题目描述
本题考查开源情报收集与分析能力。题目给了一个恶意情报的 hash 值，需借助公开威胁情报中心找到恶意文件的 APT 组织名称、通信 C2 服务器域名、恶意文件编译时间（年-月-日）。

## 考察知识点
- OSINT 开源情报收集
- 威胁情报平台使用（奇安信威胁情报中心、VirusTotal）

## 解法
使用 [奇安信威胁情报中心](https://ti.qianxin.com/) 和 [VirusTotal](https://www.virustotal.com/gui/home/search)。

### APT 组织名称
- 奇安信：首页可直接得到攻击组织名称。
- VirusTotal：Family labels 显示多个标签，可在社区中进一步确认 apt 家族名称。

### 通信 C2 服务器域名
- 奇安信：点击「样本分析详情」，在「网络行为」栏得到域名。
- VirusTotal：`BEHAVIOR` → `Activity Summary` → `Memory Pattern Domains` 中确定域名。

### 恶意文件编译时间
- 奇安信：「基本信息」→「Exiftool 文件元数据」→ `TimeStamp`。
- VirusTotal：`DETAILS` → `History` → `Create Time`。

## 参考答案
（未给出，需在线情报平台实际查询）

## 来源
- 作者：NewStar CTF 2025 官方 WriteUp | https://newstar.wiki/wp/2025/week2/misc/osint-threat-intel.html
