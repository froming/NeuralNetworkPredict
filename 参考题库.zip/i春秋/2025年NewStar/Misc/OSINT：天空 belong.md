# OSINT：天空 belong

> 分类：Misc

## 题目描述
本题考查 OSINT 部分的图片寻址类问题。附件为一张图片，机翼上可见飞机注册号 `B-7198`。

## 考察知识点
- OSINT（开源情报）
- 图片 EXIF 信息分析
- flightaware 航班查询

## 解法
1. 解压附件得到图片，机翼上可见标号 `B-7198`。
2. 查看 EXIF 信息：拍摄时间 `2025/08/17 15:03:47`，制造商 `Xiaomi`。
3. 在 [flightaware](https://www.flightaware.com/) 中搜索注册号 `B-7198`，查找对应时间的历史航班。
4. 得到航班号 `UQ3574`。
5. 在航线图中调整到拍摄时间，发现经过的省会城市有且只有武汉市。

## 参考答案
flag{UQ3574_武汉市_Xiaomi}

## 来源
- 作者：NewStar CTF 2025 官方 WriteUp | https://newstar.wiki/wp/2025/week1/misc/osint-sky-belong.html
