# 内存取证：Windows 篇

> 分类：Misc

## 题目描述
内存取证入门题，主要目的是熟悉常用工具（Volatility 2）、基础命令。FLAG 由多个问题的答案用下划线连接组成：恶意进程的外联 ip:port、恶意进程所在文件夹名称、用户主机登录密码、电脑主机名称（涉及字母的部分统一小写）。

## 考察知识点
- Volatility 2 内存取证
- imageinfo / netscan / filescan / hashdump / hivelist / printkey
- Hashcat 爆破 NTLM

## 解法
1. 识别系统版本：
```
python2 vol.py -f hellohacker.raw imageinfo
```
（Profile 用第一个候选 `Win7SP1x64`）

2. 恶意进程外联 ip:port（关注 `ESTABLISHED`、非本地外联地址）：
```
python2 vol.py -f hellohacker.raw --profile=Win7SP1x64 netscan
```
锁定 `125.216.248.74:11451`（进程名 `svchost.exe`，PID 2864）。

3. 恶意进程所在文件夹名称：
```
python2 vol.py -f hellohacker.raw --profile=Win7SP1x64 filescan | grep "svchost"
```
`svchost.exe` 出现在 `Temp` 路径中，文件夹名称为 `temp`。

4. 用户主机登录密码：
```
python2 vol.py -f hellohacker.raw --profile=Win7SP1x64 hashdump
```
取恶意用户 `JustAGuestAwA` 的 NTLM hash `3008c87294511142799dca1191e69a0f`，用 Hashcat 爆破：
```
hashcat.exe -a 3 -m 1000 3008c87294511142799dca1191e69a0f
```
密码为 `admin123`。

5. 电脑主机名称：
```
python2 vol.py -f hellohacker.raw --profile=Win7SP1x64 hivelist
python2 vol.py -f hellohacker.raw --profile=Win7SP1x64 -o 0xfffff8a000024010 printkey -K "ControlSet001\Control\ComputerName\ComputerName"
```
得到 `ARISAMIK`，全小写为 `arisamik`。

## 参考答案
flag{125.216.248.74:11451_temp_admin123_arisamik}

## 来源
- 作者：NewStar CTF 2025 官方 WriteUp | https://newstar.wiki/wp/2025/week3/misc/mem-forensics-win.html
