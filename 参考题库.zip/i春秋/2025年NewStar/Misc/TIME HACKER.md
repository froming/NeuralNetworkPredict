# TIME HACKER

> 分类：Misc

## 题目描述
侧信道攻击、时间戳隐写与 EXIF 信息读取。压缩包文件尾部存在冗余 Base64 提示，`password_checker.exe`（VMProtect 壳）校验密码时存在时间侧信道，逐位爆破密码。解压后的图片通过修改时间戳与 EXIF 顺序隐藏 FLAG。

## 考察知识点
- 文件尾部冗余数据（Base64）
- 时间侧信道攻击
- 时间戳隐写
- EXIF 信息读取（piexif）

## 解法

1. 压缩包拖入 010 Editor，文件尾部存在冗余 Base64 数据，解码得到提示：`I heard you can hack the time in different dimensions?`

2. `password_checker.exe` 用于校验压缩包密码，加了 VMProtect 壳无法直接逆向。FLAG.zip 尾部冗余数据解码得到提示：`The password is ten digits`。直接爆破需 7 天，不可行。

3. 「hack the time」指向侧信道时间攻击。输入密码后程序会延迟一段时间再输出结果，校验逻辑类似：

```python
a = input()
def checker(a):
    if len(a) != len(secret):
        return False
    for i in range(len(a)):
        if a[i] != secret[i]:
            # 一些耗时操作
            return False
    return True
```

按响应时间逐位爆破密码：

```python
import time
import subprocess

def crack_password():
    password = ""
    exe_path = "exe_path"
    for i in range(10):
        times = {}
        for c in "0123456789":
            test = password + c + '0' * (9 - i)
            total_time = 0
            for _ in range(3):
                start = time.time()
                subprocess.run([exe_path], input=test.encode(), capture_output=True)
                total_time += time.time() - start
            times[c] = total_time / 3
        best_char = max(times, key=times.get)
        password += best_char
    return password

if __name__ == "__main__":
    print(crack_password())
```

得到密码 `2145768093`。

4. 解压后的图片，修改时间戳异常（隐藏信息）。打印 `st_mtime` 与密码差值：

```python
import os
import time

for i in range(1, 37):
    mTime = os.stat(f".../{i}.png").st_mtime
    print(chr(int(mTime) - 2145768093), end="")
```

已能看出 FLAG 字符但顺序不正确，需从 EXIF 读取文件顺序。最终脚本：

```python
import piexif
from PIL import Image
import os

def exif_read(file_path):
    img = Image.open(file_path)
    exif_dict = piexif.load(img.info["exif"])
    return exif_dict["Exif"][36867][-2:]

shunxu = []
for i in range(1, 37):
    shunxu.append(int(exif_read(f"pngpath/{i}.png")))

FLAG = [""] * 50
for i in range(1, 37):
    mTime = os.stat(f"pngpath/{i}.png").st_mtime
    FLAG[shunxu[i-1]] = chr(int(mTime) - 2145768093)

print("".join(FLAG))
```

## 参考答案
FLAG{Y0u_4re_tHe_ReaL_TIME_H@cker!!}

## 来源
- 作者：NewStar CTF 2025 官方 WriteUp | https://newstar.wiki/wp/2025/week5/misc/time-hacker.html
