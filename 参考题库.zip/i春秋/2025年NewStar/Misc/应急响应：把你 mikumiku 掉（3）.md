# 应急响应：把你 mikumiku 掉（3）

> 分类：Misc

## 题目描述
应急响应系列（3）。进入 `/home/mikuu`，发现恶意程序 `mikumikud` 和被加密的 `flag.miku`。用 IDA 分析恶意程序，还原 AES 的 key 和 IV，编写解密脚本还原 FLAG。

## 考察知识点
- 恶意程序逆向（IDA）
- AES-CBC 加密分析
- key/IV 提取（注意小端序）

## 解法

1. 使用 FTP 将文件传到本地，用 IDA 打开 `mikumikud` 分析，可看出是 AES 加密程序。
2. `AES_set_encrypt_key(v13, 128LL, v10)` 中 `v13` 数组为 key（注意小端序低字节在前），key 为：

```
12 34 56 78 9A BC DE F0 11 22 33 44 55 66 77 88
```

3. IV 来自 `ptr` 和 `v12` 变量：

```c
unsigned __int64 ptr; // [rsp+930h] [rbp-50h]
__int64 v12; // [rsp+938h] [rbp-48h]
ptr = 0xEF40511401811919LL;
v12 = 0x1032547698BADCFELL;
```

4. 加密过程中 IV 被写入文件开头：

```c
fwrite(&ptr, 1uLL, 0x10uLL, s);  // 写入 16 字节：ptr(8 字节) + v12(8 字节)
```

5. 解密脚本：

```python
from Crypto.Cipher import AES

key = bytes.fromhex('123456789ABCDEF01122334455667788')
with open('flag.miku', 'rb') as f:
    iv = f.read(16)
    ciphertext = f.read()

cipher = AES.new(key, AES.MODE_CBC, iv)
plaintext = cipher.decrypt(ciphertext)
print(plaintext)
```

## 参考答案
（未给出）

## 来源
- 作者：NewStar CTF 2025 官方 WriteUp | https://newstar.wiki/wp/2025/week5/misc/mikumiku-3.html
