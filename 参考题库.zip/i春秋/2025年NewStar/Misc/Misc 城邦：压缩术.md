# Misc 城邦：压缩术

> 分类：Misc

## 题目描述
本题考查压缩包暴力破解、伪加密、明文攻击等压缩包相关知识点。题目描述：`请挑战者们通过6位密码门开始挑战吧！(要想使用压缩术，请先念咒语"abcd...xyz0123...789")`。

## 考察知识点
- 压缩包暴力破解（ARCHPR）
- ZIP 文件结构
- 伪加密（General purpose bit flag 修改）
- 压缩包明文攻击（bkcrack）

## 解法
**第一关**：暴力破解 6 位密码（数字+小写字母），使用 ARCHPR 得到密码 `ns2025`。解压得到 `tips.txt` 和 `bkcrack.zip`。

**第二关**：伪加密。`tips.txt` 提到「下一扇门明明没有密码」，说明第二关为伪加密。根据 ZIP 文件结构，`General purpose bit flag` 最低位为 1 表示文件被加密，将该标志位 `09 00` 改为 `00 00` 关闭加密标志即可解压，得到 `key.txt` 和 `flag.zip`。

**第三关**：明文攻击。`flag.zip` 内同样有 `key.txt`，将 `key.txt` 以相同方式压缩，CRC32 校验值一致即可进行明文攻击。使用 bkcrack：

```
bkcrack -C 加密压缩包 -c 提取的密文部分 -p 提取的明文部分
```

然后用 key 删除密码，生成不加密的 `flag2.zip`，打开即可得到 FLAG。

## 参考答案
（未给出）

## 来源
- 作者：NewStar CTF 2025 官方 WriteUp | https://newstar.wiki/wp/2025/week1/misc/compression-magic.html
