# 区块链：INTbug

> 分类：Misc

## 题目描述
智能合约整数溢出漏洞。在 `usePoints()` 函数的 `unchecked` 代码块中，`totalPoints` 与 `userSpentPoints[msg.sender]` 的减法存在整数溢出，使 `userSpentPoints[msg.sender] > 1000` 触发解锁。

## 考察知识点
- Solidity 整数溢出（unchecked 块）
- 智能合约审计与交互

## 解法

漏洞代码：

```solidity
unchecked {
    totalPoints -= points;
    userSpentPoints[msg.sender] -= points;
}
```

初始状态：每个用户调用 `addPoints()` 或 `usePoints()` 时，若 `userSpentPoints[msg.sender]` 为 0，会被设置为 1000。触发解锁的条件：

```solidity
if (userSpentPoints[msg.sender] > 1000) {
    unlocked[msg.sender] = true;
}
```

由于 `unchecked` 块中减法不检查溢出，只要使用的点数大于 1000（导致 `userSpentPoints` 下溢为极大值）即可触发解锁。操作：在 `addPoints` 中输入大于 1000 的数，执行 `addPoints` 后再执行大于 1000 的 `usePoints`，随后点击 `getFlag` 即可得到 FLAG。

## 参考答案
（未给出）

## 来源
- 作者：NewStar CTF 2025 官方 WriteUp | https://newstar.wiki/wp/2025/week5/misc/intbug-chain.html
