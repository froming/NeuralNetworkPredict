# Misc 城邦：NewKeyboard

> 分类：Misc

## 题目描述
本题考查 USB 流量及映射脚本编写。

## 考察知识点
- USB 流量分析
- 键盘按键映射脚本编写

## 解法
（官方 WriteUp 未给出详细解题过程，仅说明考察 USB 流量分析及按键映射。一般思路为提取 USB 键盘数据包中的 HID 键码，按标准键盘映射表还原按键内容。）

## 参考答案
（未给出）

## 来源
- 作者：NewStar CTF 2025 官方 WriteUp | https://newstar.wiki/wp/2025/week2/misc/newkeyboard.html
