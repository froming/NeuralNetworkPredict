# EZ_fence

> 分类：Misc

## 题目描述
本题考查 Base64 编码、栅栏加密。附件是一张图片，题干提示 rar，图片内藏了一个压缩包。

## 考察知识点
- 文件隐写（rar 文件头搜索）
- 栅栏加密（栏数为 4）
- 换表 Base64
- 图片高度修改

## 解法
1. 用 winhex 打开图片，搜索 rar 文件头 `52 61 72 21 1A 07 01`，将文件头后剩余部分复制另存得到压缩包（或直接改图片后缀）。
2. 图片内容是一串字符串，题目提示 fence 和数字 4，使用栏数为 4 的栅栏解密：

```python
encrypted_str = "rdh9zfwzSgoVA7GWtLPQJK=vwuZvjhvPyyvjnMWoSotB"
rails = 4
# rail_fence_decrypt 见官方 writeup 完整代码
```
运行得到 `rSvMwgdouWZVhAvoj79GhSvWztPoyLfPytvQwJjBnKz=`，是换表 Base64 编码。

3. 题干提示图片破损，需修改图片高度，得到换表 Base64 的自定义字符表 `8426513709qazwsxedcrfvtgbyhnujmikoplQWSAERFDTYHGUIKJOPLMNBVCXZ-_`。

4. 自定义 Base64 解密：

```python
import base64
encrypted_str = "rSvMwgdouWZVhAvoj79GhSvWztPoyLfPytvQwJjBnKz="
custom_table = "8426513709qazwsxedcrfvtgbyhnujmikoplQWSAERFDTYHGUIKJOPLMNBVCXZ-_"
# custom_base64_decode 见官方 writeup 完整代码
```

得到压缩包密码 `New5tar_zjuatrojee1mage5eed77yo#`，输入后得到 flag。

## 参考答案
flag{y0u_kn0w_ez_fence_tuzh0ng}

## 来源
- 作者：NewStar CTF 2025 官方 WriteUp | https://newstar.wiki/wp/2025/week1/misc/ez-fence.html
