# 应急响应：把你 mikumiku 掉（2）

> 分类：Misc

## 题目描述
应急响应系列（2）。结合上一题日志得知木马 `mikuu.jsp`，分析出木马连接密码 `miiikuuu`。查看 `/etc/shadow` 发现用户 `mikuu`，使用 yescrypt 密码，通过爆破得到密码 `miiiku`。

## 考察知识点
- webshell（JSP 木马）分析
- `/etc/shadow` 密码哈希分析（yescrypt）
- yescrypt 密码爆破

## 解法

1. 结合上一题日志得知木马为 `mikuu.jsp`，分析后得出木马连接密码为 `miiikuuu`。
2. 查看 `/etc/shadow`，发现名为 `mikuu` 的用户，其密码哈希为 `yescrypt` 类型。
3. yescrypt 密码无法使用 hashcat，john 效率太低，使用 [yescrypt_crack](https://github.com/cyclone-github/yescrypt_crack/releases/tag/v0.2.0) 项目。
4. 配置 go 环境、装依赖、`go build`。根据 tips 生成由 miku 四个字符构成的密码本，爆破：

```bash
./yescrypt_crack.exe -h hash.txt -w ezdict.txt -t 16 -s 10
```

爆破得到密码 `miiiku`。

## 参考答案
miiiku

## 来源
- 作者：NewStar CTF 2025 官方 WriteUp | https://newstar.wiki/wp/2025/week5/misc/mikumiku-2.html
