# ez_forensics

> 分类：Misc（取证）

## 题目描述

内存取证 + 磁盘镜像取证。使用 Lovelymem 挂载镜像，恢复 7z 文件，爆破 MobaXterm 配置中的密码。

## 考察知识点

- 内存取证（Lovelymem / Volatility）
- 磁盘镜像恢复（R-Studio）
- hashdump 密码提取
- MobaXterm 配置密码恢复
- ROT13 + ROT47 编码

## 解法

1. 使用 Lovelymem 工具挂载内存镜像，翻到一个 hint.txt，提示 `60 = ( ) + ( )`，和羊城杯一样，是 rot13 + rot47 组合。
2. 解码得到提示：7z 密码是从 hashdump 中得到的。
3. 7z 文件是空的（损坏），使用 R-Studio 挂载镜像，恢复 f14g.7z 文件。
4. 密码使用 hashdump 命令查到 `Flu0r1n3` 用户的密码（Mimikatz 得到密码 `strawberries`），cmd5 查到明文。
5. 解压得到一个提示和一个 ini 配置文件。提示是 ssh 连接，ini 文件是 MobaXterm 的配置文件。
6. 使用项目 [how-does-MobaXterm-encrypt-password](https://github.com/HyperSine/how-does-MobaXterm-encrypt-password) 恢复密码：

```shell
python MobaXtermCipher.py dec -p flag_is_here DLulatnJIPtEF/EMGfysL2F58R4dfQIbQhzwuNqL
```

7. 把 `flag_is_here` 当作主密码显示 root 用户密码，把大括号里的内容 base64 解密得到 flag。

## 参考答案

`flag{you_are_a_g00d_guy}`

## 来源

- 作者：Liebert77 | https://blog.csdn.net/2301_80185313/article/details/145268362
