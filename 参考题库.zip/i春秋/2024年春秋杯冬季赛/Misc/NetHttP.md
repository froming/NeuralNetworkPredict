# NetHttP

> 分类：Misc（流量分析）

## 题目描述

流量分析题。流量中是 SSTI 命令执行攻击，通过盲注逐步获取 RSA 私钥加密的密文，最后用 SECRET_KEY 解密私钥并解密 flag。

## 考察知识点

- SSTI 命令执行流量分析
- 盲注流量提取（tshark）
- RSA 私钥解密（加密私钥 + SECRET_KEY 密码）

## 解法

1. 过滤 http 协议，一眼看出是 SSTI 命令执行的攻击。
2. 流 1 给出 SSTI 漏洞的源码和 SECRET_KEY：

```python
app.config['SECRET_KEY'] = 'gdkfksy05lx0nv8dl'
```

3. 流 13 中得到一个加密的私钥（`-----BEGIN ENCRYPTED PRIVATE KEY-----`），用 SECRET_KEY 作为密码解密私钥。
4. 剩下的流量是盲注，命令形式：

```shell
if [ $(cat /app/secret/mw/m5|base64 -w 0| awk NR==1 | cut -c 1) == 'U' ]; then echo "rce";fi
```

根据回显是 `Welcome rce` 判断字符，逐个提取出 base64 编码的密文：

```
UzBJM2lXaHZzektiT00vT2FsS1RBMGZwbTVPNWNoVlZuWUd5S2Q1blY0ZXJBelJiVjZWNnc4Yi9VaU9mUUVjM0lqaDAwaEZqWUZVMUhheE51YjlHbmxQUy9sY2FtNW1BVGtmMnNKUzZKZ3BKbzZBU2hWUnhXRFlLS3JvamVVZUJaajVNRVBJOC80REdHR3VIRnhteDJieEFhaGREZTFjR25qVFpHV09OcE5JPQ==
```

提取方法：tshark 提取 name 参数值，正则匹配 base64 内容。

5. 删除尾部 `RmFrZSBGTGFnCm5vIGhlcmUK`（"Fake Flag no here"），对剩余 base64 解码得到 RSA 密文，用解密后的私钥解密得到 flag。

解密私钥的 Python 脚本核心：

```python
from cryptography.hazmat.primitives import serialization
password = b"gdkfksy05lx0nv8dl"
private_key = serialization.load_pem_private_key(encrypted_pem, password=password)
```

## 参考答案

`flag{343907d2-35a3-4bfe-a5e1-5d6615157851}`

## 来源

- 作者：Liebert77 | https://blog.csdn.net/2301_80185313/article/details/145268362
- 作者：frank1q22 | https://xz.aliyun.com/news/17083
