# find me

> 分类：Misc

## 题目描述

我的世界（Minecraft）存档取证题。将附件导入 Minecraft save 文件夹，在游戏中找到 key，解压 flag.rar。

## 考察知识点

- Minecraft 存档分析
- 压缩包密码爆破 / 提取
- 随波逐流隐写

## 解法

1. 下载附件导入到 Minecraft save 文件夹中，启动游戏。
2. 在游戏世界中探寻，找到一个 key：`cwqeafvfwqead`。
3. 猜测是 flag.rar 的密码，解压得到 1.txt。
4. 随波逐流一把梭得到 flag。

## 参考答案

`flag{535e0a20-189e-4049-ab30-dec60bac91b8}`

## 来源

- 作者：frank1q22 | https://xz.aliyun.com/news/17083
