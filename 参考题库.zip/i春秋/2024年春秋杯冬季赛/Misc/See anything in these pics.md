# See anything in these pics?

> 分类：Misc

## 题目描述

图片隐写 + 压缩包，根据图片名字提示是 Aztec 码。

## 考察知识点

- Aztec 码识别
- 文件隐藏（foremost/随波逐流）
- 图片宽高修复

## 解法

1. 根据图片名字提示 Aztec，识别 Aztec 码（在线网站 https://products.aspose.app/barcode/zh-hans/recognize ）得到解压密码 `5FIVE`。
2. 解压后一张 jpg 图片，查看文件尾发现有个 png 文件。
3. 用 foremost 分离，然后修复图片宽高即可得到 flag。

## 参考答案

`flag{opium_00pium}`

## 来源

- 作者：Liebert77 | https://blog.csdn.net/2301_80185313/article/details/145268362
- 作者：frank1q22 | https://xz.aliyun.com/news/17083
- 作者：H轨迹H | https://www.cnblogs.com/GuijiH6/p/18680901
