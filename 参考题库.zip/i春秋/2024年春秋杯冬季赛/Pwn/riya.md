# riya

> 分类：Pwn

## 题目描述

简单的 pwn 题，IDA 分析后 main 函数中有两个参数，输入 `n` 调用 sub_D74() 直接执行 /bin/sh。

## 考察知识点

- 逆向分析（IDA）
- 简单 getshell

## 解法

1. 下载附件，丢进 IDA 分析 main 函数。
2. 发现有参数判断，输入 `n` 会调用函数 `sub_D74()`。
3. `sub_D74()` 直接执行 `/bin/sh` 返回 shell。
4. 连接 nc，输入 `n` 即可 getshell，执行命令得到 flag。

## 参考答案

`flag{eab82f15-bde8-47cb-8c3c-71ec727dd8e0}`

## 来源

- 作者：frank1q22 | https://xz.aliyun.com/news/17083
