# funny_rsa

> 分类：Crypto

## 题目描述

题目给了四个运算结果（funny1~funny4），需要推导 n、p、q 并解 RSA。

## 考察知识点

- RSA 因数分解（韦达定理）
- 最大公约数求 n
- 随机偏移爆破

## 解法

题目源码关键：

```python
# funny1 = p+q - p*q + random.randint(-1025, +1025)
# funny2 = bytes_to_long(m) * bytes_to_long(hint)
# funny3 = bytes_to_long(m) * n * bytes_to_long(hint) - 1025
# funny4 = pow(bytes_to_long(hint), 65537, n)
```

**第一步：求 n**

```python
import gmpy2
n = (funny3 + 1025) // gmpy2.gcd(funny3 + 1025, funny2)
```

（funny3+1025 和 funny2 的最大公约数即 m*hint，相除得 n）

**第二步：求 p、q**

```
funny1 = p+q - p*q + r = p+q - n + r   （r ∈ [-1025, 1025]）
所以 p+q = funny1 + n - r
p*q = n
```

对 r 遍历 -1025~1025，解二次方程 `x^2 - (p+q)x + p*q = 0` 得到 p、q：

```python
import math
from Crypto.Util.number import inverse

found = False
for offset in range(-1025, 1026):
    p_plus_q = funny1 + n - offset
    discriminant = p_plus_q**2 - 4 * n
    if discriminant < 0:
        continue
    sqrt_discriminant = math.isqrt(discriminant)
    p = (p_plus_q + sqrt_discriminant) // 2
    q = (p_plus_q - sqrt_discriminant) // 2
    if p * q == n:
        found = True
        break
```

**第三步：解 RSA**

```python
phi_n = (p - 1) * (q - 1)
e = 65537
d = inverse(e, phi_n)
hint_long = pow(funny4, d, n)
m_long = funny2 // hint_long
print(long_to_bytes(m_long))
```

得到的是一个假 flag，hint 说"玄机就在数字里面"：

```
b'Of course, So good, and enjoy the funny number, it is true flag'
b'fake:flag{5044833682931814367881036090727702841234957943094051805420875375031047763007750978962055801191968383860156687597666360268370292861}'
```

**第四步：长整数转字符**

```python
from Crypto.Util.number import long_to_bytes
flag = 5044833682931814367881036090727702841234957943094051805420875375031047763007750978962055801191968383860156687597666360268370292861
print(long_to_bytes(flag))
```

## 参考答案

`flag{aB3-CdE7_FgH9-iJkLmNoPqRsT-UvWxYz1234567890}`

## 来源

- 作者：Liebert77 | https://blog.csdn.net/2301_80185313/article/details/145268362
- 作者：H轨迹H | https://www.cnblogs.com/GuijiH6/p/18680901
