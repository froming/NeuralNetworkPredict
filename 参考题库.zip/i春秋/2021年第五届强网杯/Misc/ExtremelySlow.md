# ExtremelySlow

> 分类：Misc

## 题目描述

流量包中全是 TCP/HTTP 流量，206 分段传输，每个包传 1byte，合并后得到 pyc 文件（Python 3.10 magic number），反编译分析 RC4 解密。

## 考察知识点

- 流量分析（206 分段传输提取）
- pyc 反编译（magic number 修复、dis）
- RC4 解密

## 解法

1. 流量包每个包传 1byte（206 分段），写脚本提取每个 byte，按 index 合并得到二进制文件：

```bash
tshark -r ExtremelySlow.pcapng -T fields -e data -Y "http.response.line == \"content-range: bytes $idx-$idx/1987\x0d\x0a\""
```

2. 得到的是 pyc 文件，magic number 对应 Python 3.10.0b2（用 docker 拉 `python:3.10.0b2` 镜像）。
3. uncompyle6 不支持 3.10，用 `dis` 模块反汇编分析：

```python
import marshal, dis
with open('decode.pyc','rb') as f:
    f.read(16)
    code_obj = marshal.load(f)
dis.dis(code_obj)
```

4. 分析出是 RC4 + xor 加密，逆向解密得到 flag。

## 参考答案

（flag 通过 RC4 逆向解密得到）

## 来源

- 作者：backlion | https://www.cnblogs.com/backlion/p/15724551.html
