# BlueTeaming

> 分类：Misc

## 题目描述

内存取证。恶意程序执行了 Powershell 脚本，找出包含脚本内容的注册表键。

## 考察知识点

- 内存取证（volatility）
- 注册表取证

## 解法

1. 用 volatility 导出内存中的 register hive：

```bash
volatility -f memory.dmp --profile Win7SP1x64 hivelist
volatility -f memory.dmp --profile Win7SP1x64 dumpregistry -D .
```

2. 题目与 powershell 恶意程序相关，优先考虑 SOFTWARE 字符串，用 WRR.exe 检查注册表，全局搜索恶意软件字段（-IEX、encode、decompress、new-object 等）。
3. 找到恶意软件存放的注册表位置。

## 参考答案

`HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\Communication`

## 来源

- 作者：backlion | https://www.cnblogs.com/backlion/p/15724551.html
