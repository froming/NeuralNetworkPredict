# CipherMan

> 分类：Misc

## 题目描述

内存取证。攻击者加密了特定卷，需解密卷（BitLocker）。

## 考察知识点

- 内存取证（volatility filescan/dumpfiles）
- BitLocker 恢复密钥
- DiskGenius 解密

## 解法

1. 用 volatility 分析内存，filescan 找 txt 文件，dumpfiles 导出：

```bash
volatility -f memory imageinfo
volatility -f memory --profile=Win7SP1x86_23418 filescan | grep 'txt'
volatility -f memory --profile=Win7SP1x86_23418 dumpfiles -Q 0x000000007e02af80 -D ./
```

2. 导出的 txt 是 BitLocker 恢复密钥：

```
恢复密钥 ID: 168F1291-82C1-4BF2-B634-9CCCEC63E9ED
BitLocker 恢复密钥: 221628-533357-667392-449185-516428-718443-190674-375100
```

3. 用 DiskGenius 解密卷，得到 flag（内容即"Wow, you have a great ability..."）。

## 参考答案

（flag 为解密卷中的文本内容，见截图）

## 来源

- 作者：backlion | https://www.cnblogs.com/backlion/p/15724551.html
