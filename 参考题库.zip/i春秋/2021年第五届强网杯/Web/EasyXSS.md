# EasyXSS

> 分类：Web

## 题目描述

XS-Leaks（侧信道）题。通过 XSS 逐位爆破 flag（UUID 格式）。

## 考察知识点

- XSS
- XS-Leaks（侧信道爆破）

## 解法

1. `/flag` 路由逐字符比较 flag 与输入，相同返回 200，不同返回 500。
2. `/about?theme=` 存在 XSS（空格可用 `%09` 绕过）。
3. flag 是 UUID 格式，按格式逐位爆破，通过返回状态判断字符是否正确。
4. 在 VPS 上跑脚本，分 success/error 两个路由，让 bot 访问 `/flag` 路由，成功后调用 Ajax 请求 VPS 的 success 路由，失败请求 error 路由，通过参数返回当前爆破的 flag。

核心 exp 思路（flask 服务 + 逐位爆破），最终从 VPS 访问记录得到 flag。

## 参考答案

（flag 通过 XS-Leaks 逐位爆破 UUID 得到）

## 来源

- 作者：backlion | https://www.cnblogs.com/backlion/p/15724551.html
