# Hard_Penetration

> 分类：Web

## 题目描述

Shiro 反序列化 + 内存马 + TP3.1.3 CMS 文件包含，内网渗透。

## 考察知识点

- Shiro 反序列化（shiro_attack）
- 内存马注入（冰蝎）
- ThinkPHP 3.1.3 文件包含
- 内网穿透

## 解法

1. 抓包发现 rememberMe 参数，Xray 确认 Shiro 反序列化漏洞。
2. shiro_attack 工具写冰蝎内存马，冰蝎连接。
3. 当前用户 ctf 权限不足，`ps` 发现 Apache 服务，读取 ports 配置得到端口。
4. 冰蝎端口映射出内网服务，发现是 CMS（BaoCms），Github 下载源码审计发现包含模板但硬加了 .html 后缀。
5. 利用文件包含漏洞构造 shell，蚁剑连接获得 flag。

## 参考答案

（flag 通过 TP3.1.3 文件包含 getshell 后读取）

## 来源

- 作者：TheTh1nk3r | https://theth1nk3r.github.io/2021/06/15/%E7%AC%AC%E4%BA%94%E5%B1%8A%E5%BC%BA%E7%BD%91%E6%9D%AFWEB%20Writeup/
- 作者：backlion | https://www.cnblogs.com/backlion/p/15724551.html
