# EasyWeb

> 分类：Web

## 题目描述

SQL 注入获取密码 + 文件上传 getshell + JBoss 提权（内网渗透）。

## 考察知识点

- SQL 注入
- 文件上传（.htaccess 绕过过滤）
- 内网穿透（冰蝎代理）
- JBoss 未授权访问（JexBoss）

## 解法

1. 扫端口发现 36842 开放，是登录页面，用户名处存在 SQL 注入，sqlmap 一把梭获取账号密码。
2. 登录后台，扫目录发现文件上传路由。
3. 上传 php 木马被拦截（后缀+内容过滤），用 `.htaccess` 的 `php5-script` 绕过 `application` 过滤，上传木马，蚁剑连接。
4. 发现 flag 文件权限不足，用 `netstat -apn` 发现 8006 端口为 JBoss 服务。
5. 冰蝎做内网穿透（HTTP 隧道），把 8006 映射到本地 2222 端口。
6. 用 JexBoss 脚本一把梭，获得 root 权限 shell，读取 flag。

## 参考答案

（flag 通过 JBoss 提权后读取）

## 来源

- 作者：TheTh1nk3r | https://theth1nk3r.github.io/2021/06/15/%E7%AC%AC%E4%BA%94%E5%B1%8A%E5%BC%BA%E7%BD%91%E6%9D%AFWEB%20Writeup/
- 作者：backlion | https://www.cnblogs.com/backlion/p/15724551.html
