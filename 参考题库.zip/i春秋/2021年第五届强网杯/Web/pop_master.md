# pop_master

> 分类：Web

## 题目描述

PHP 反序列化，类数量巨大（1万个），需编写自动化脚本构造 POP 链实现 RCE。

## 考察知识点

- PHP 反序列化 POP 链（自动化构造）
- PHP AST（抽象语法树）解析

## 解法

1. 该题类数量巨大（1W 个），编写自动化脚本构造 pop 链。
2. 第一步将 class.php.txt 转化成 AST 保存为 json：

```php
<?php
ini_set("memory_limit","-1");
echo(json_encode(ast\parse_file("class.php", $version=70)));
```

3. 构造 `A->B->C->...->包含 EVAL()` 的调用链。注意几个坑：调用途中参数污染、传参被清空、传参被修改。
4. 编写 AST 解析脚本随机抽取构造链，检验是否正常执行，反复抽取得到可用链。
5. 最终生成序列化文本，`argv=system('cat /flag')` 触发 RCE。

## 参考答案

（flag 通过自动化构造 POP 链 RCE 读取）

## 来源

- 作者：backlion | https://www.cnblogs.com/backlion/p/15724551.html
