# WhereIsUWebShell

> 分类：Web

## 题目描述

PHP 反序列化（Cookie）+ LFI + 临时文件 getshell + SUID 提权。

## 考察知识点

- PHP 反序列化（Cookie，去掉大括号报错绕过 Exception）
- LFI（php://filter/string.strip_tags 触发 SegmentFault 保留临时文件）
- SUID 提权

## 解法

1. 入口 Cookie 存在反序列化，构造 `myclass` + `Hello` 类（`__destruct` 里 `file_get_contents($this->qwb)`），去掉最后大括号利用反序列化报错绕过 Exception。

```
O:7:"myclass":1:{s:1:"h";O:5:"Hello":1:{s:3:"qwb";s:36:"e2a7106f1cc8bb1e1318df70aa0a3540.php";}
```

2. 读取 `e2a7106f1cc8bb1e1318df70aa0a3540.php`，存在文件包含（`include($file)`）+ `scandir('/tmp')`。

3. 利用 `php://filter/string.strip_tags` 触发 SegmentFault 保留上传的临时文件，图片里放木马，上传过程中留下 webshell。

4. 利用 shell 发现 `/usr/bin` 下有 SUID 程序（root 权限），执行读取 flag（在 `/l1b` 下嵌套目录中）。

## 参考答案

`flag{b101e657-a46a-4791-abcb-5be544fc12bd}`

## 来源

- 作者：backlion | https://www.cnblogs.com/backlion/p/15724551.html
