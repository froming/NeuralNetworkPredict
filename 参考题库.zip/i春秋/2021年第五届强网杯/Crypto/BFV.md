# BFV（决赛 crypto）

> 分类：Crypto

## 题目描述

2021 第五届强网杯决赛 crypto 题。BFV 全同态加密的 CCA 攻击，需要泄露 admin 的 id 来获取 flag。

## 考察知识点

- 全同态加密（BFV/FPSI）
- CCA 攻击
- padding Oracle（密钥恢复）

## 解法

1. 题目是 BFV 全同态加密的 CCA 攻击。私钥不是标准 0/1 序列，而是 [-7,7] 范围的离散高斯采样。
2. Oracle 只能判断某位是否为 0，通过改变 `t1[i] = n*M` 的 n 值观察返回数据，发现 padding 规律。
3. 按顺序 `n = [8,7,6,5,4,3,2,1,0,-1,-2,-3,-4,-5,-4]`，`t1 = n*M`，对密钥做 padding Oracle 恢复私钥。
4. 恢复私钥后解密 admin 的 id，添加 admin 为 friend，发送 "give me the flag" 获取 flag。

完整 exp 见原博客（含 pwn 交互 + sage 数学计算）。

## 参考答案

`flag{CCA_attack_BFV_123698745}`

## 来源

- 作者：ljahum | https://blog.csdn.net/a_touhouer/article/details/118756480
