# Train

> 分类：Crypto

## 题目描述

哈希碰撞题。需给出两个字符串，通过 `TrainHash` 后哈希相同且最后 50 位相同。

## 考察知识点

- 格基规约（LLL）解哈希碰撞
- 自定义哈希算法分析

## 解法

`TrainHash` 核心：

```python
def TrainHash(msg):
    n = n0
    msg = map(ord, msg)
    for i in msg:
        n = g * (n+i)
        n = n & (1<<383)
    return n - 0xf5e33dabb114514
```

要使两个字符串哈希相同，构造 n+1 维矩阵做 LLL 格基规约，得到差值向量 z，对 base 字符串加减 z 得到另一个字符串。构造较长的内容使最后 50 字符较长（后面差值都是 0）。

核心代码（LLL 构造）：

```python
N = 250
K = 2**200
modd = 2**384
Mat = Matrix(ZZ, N + 1, N + 2)
for i in range(N+1):
    ge = ZZ(pow(g, N - i, modd))
    Mat[i, i] = 1
    Mat[i, N + 1] = ZZ(ge * K)
Mat[i, N + 1] = ZZ(K * modd)
ml = Mat.LLL()[0]
# change = [ml[i] for i in range(len(ml))]
```

（注：原题 wp 中也有"题目多半出错了，通过第一步 sha256 校验后直接随便输入两个一样的字符串就能得到 flag"的解法）

## 参考答案

（flag 通过 LLL 构造哈希碰撞后得到）

## 来源

- 作者：V3geD4g | https://blog.csdn.net/xczzhf/article/details/124652308
- 作者：CN-SEC | https://cn-sec.com/archives/1216844.html
