# notKnapsack

> 分类：Crypto

## 题目描述

背包问题（Knapsack）变种。r 为取值于 [2, q-2] 的随机数组，通过 t 次方将离散对数问题转化为小阶子群上的线性同余方程。

## 考察知识点

- 离散对数问题降阶
- 子群上的线性同余方程
- 矩阵求解

## 解法

等式两边都 t 次方，使离散对数问题简单（order 很小），然后两边取对数得到线性同余方程，共 n 组。

分解 q-1 得到 `q-1 = 2*331*318379648755152766403789525387446488411`，取 `t = (q-1)/331` 转换到阶为 331 的子群。

预先算出对应的对数，快速求解：

```python
dlp_dct = {sub_gen^i: F(i) for i in range(order)}
A = Matrix(F, m, n)
v = vector(F, m)
for i in range(m):
    for j in range(n):
        A[i, j] = dlp_dct[power_mod(cipher[i][0][j], t, q)]
    v[i] = dlp_dct[power_mod(cipher[i][1], t, q)]
x = A.solve_right(v)
```

## 参考答案

（flag 通过子群降阶 + 线性方程求解得到）

## 来源

- 作者：CN-SEC | https://cn-sec.com/archives/1216844.html
