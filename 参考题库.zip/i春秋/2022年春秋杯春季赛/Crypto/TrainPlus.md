# TrainPlus

> 分类：Crypto

## 题目描述

自定义 MD5 变体（MD00PLUS），给出的 padding 部分与标准 MD5 不同，考察哈希长度扩展攻击。

## 考察知识点

- 哈希长度扩展攻击（MD5 变体）
- MD00PLUS 算法分析

## 解法

题目给了一个 16 字节随机字符串（GreatThing），用自己的 MD00PLUS 对 sec 哈希。需给出消息和 `sec + 消息` 使能预测哈希值。

MD00PLUS 与标准 MD5 的区别在 padding 部分（`ascii_list.append(1)` 而不是 `0`）。了解哈希长度扩展攻击的很快能发现：只要构造合适的 padding 即可预测 `Md00Plus(sec + msg)`。

关键思路：

```python
def Md00Plus(message: bytes):
    h0 = 0x114514ab
    h1 = 0x1919810a
    h2 = 0xa0189191
    h3 = 0xba415411
    # ... 与 MD5 相同，但 padding 用 1 填充
    ascii_list.append(128)
    while (len(ascii_list) * 8 + 64) % 512 != 0:
        ascii_list.append(1)
    # ...

def md5ex(hash, message):
    # 从已知 hash 继续，实现长度扩展
    # msg_length = len(ascii_list) * 8 + 512（注意偏移）
```

长度扩展攻击 exp 核心：

```python
H = md5ex(Md00.decode(), GreatThing)[0].encode()
for i in range(1, 26):
    Pad = Md00Plus(i*b'a')[1][i:]
    MSG = bytes(Pad) + GreatThing
    s = hex(bytes_to_long(MSG))[2:].encode() + b',' + hex(bytes_to_long(H))[2:].encode()
    io.sendline(s)
```

## 参考答案

（flag 通过 MD00PLUS 哈希长度扩展攻击得到）

## 来源

- 作者：CN-SEC | https://cn-sec.com/archives/1216844.html
