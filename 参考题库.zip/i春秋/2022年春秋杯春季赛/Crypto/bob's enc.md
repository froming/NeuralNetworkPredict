# bob's enc

> 分类：Crypto

## 题目描述

矩阵乘法加密（模 prime），第二段密文加入噪声，需用 CVP（最近向量问题）恢复明文。

## 考察知识点

- 矩阵乘法加密
- CVP 问题（Babai 最近平面算法）

## 解法

题目用随机矩阵 key 做 `key * msg` 加密。第一段无噪声，直接矩阵求逆：

```python
R = IntegerModRing(prime)
M = Matrix(R, ma)
cc0 = vector(R, res0)
ingredients = M.solve_right(cc0)
m1 = ''.join(chr(ingredients[i]) for i in range(len(ingredients)))
```

第二段加入噪声 `noise = [random.randint(0,6) for i in range(row)]`，用 Babai 最近平面算法解 CVP：

```python
from sage.modules.free_module_integer import IntegerLattice

def Babai_closest_vector(M, G, target):
    small = target
    for _ in xrange(5):
        for i in reversed(range(M.nrows())):
            c = ((small * G[i]) / (G[i] * G[i])).round()
            small -= M[i] * c
    return target - small

A1 = matrix.identity(21)
Ap = matrix.identity(row) * prime
B = block_matrix([[Ap], [W]])
lattice = IntegerLattice(B, lll_reduce=True)
gram = lattice.reduced_basis.gram_schmidt()[0]
re = Babai_closest_vector(lattice.reduced_basis, gram, target)
ingredients = M.solve_right(re)
m2 = ''.join(chr(ingredients[i]) for i in range(len(ingredients)))
```

## 参考答案

（flag 分两段：第一段矩阵求逆，第二段 CVP 求解，拼接）

## 来源

- 作者：CN-SEC | https://cn-sec.com/archives/1216844.html
