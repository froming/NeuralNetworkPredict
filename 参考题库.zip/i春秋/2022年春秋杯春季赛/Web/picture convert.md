# picture convert

> 分类：Web

## 题目描述

Flask 应用，`exiftool-12.23` 存在 CVE-2021-22204（exif 命令注入），且 `convert` 路由中 `type` 参数可控导致代码注入。

## 考察知识点

- CVE-2021-22204（exiftool 命令注入）
- 命令注入（type 参数可控）

## 解法

源码关键：

```python
Black_list = [b"metadata", b"$", b"qx", b'tmp', b'&#']

@app.route('/info', methods=['GET'])
def info():
    json_data = {"info": os.popen("su - exif -c '/app/exiftool-12.23/exiftool /app/static/images/tmpimg'").read()}
    return json.dumps(json_data)

@app.route('/convert', methods=['GET'])
def convert():
    os.system(f"su - conv -c 'cd /app/static/images/ && convert tmpimg {session['filename']}'")
```

1. **CVE-2021-22204**：exiftool 12.23 存在命令注入，用 [CVE-2021-22204 exp](https://github.com/trganda/CVE-2021-22204) 生成恶意图片（djvu 文件），上传后访问 `/info` 触发 exiftool 命令执行，获得 flag1。

2. **convert 命令注入**：`type = request.form.get("type", "jpg")` 可控，最终作为 `session["filename"]` 拼接到 `os.system` 中。通过 post 数据注入恶意 type，拿到恶意文件名的 session，访问 `/convert` 触发命令注入反弹 shell 获得 flag2。

## 参考答案

（flag1 通过 CVE-2021-22204，flag2 通过 convert 命令注入，两段 flag 拼接）

## 来源

- 作者：se1zer | https://www.cnblogs.com/seizer/p/17036300.html
- 作者：V3geD4g | https://blog.csdn.net/xczzhf/article/details/124652308
- 作者：h0cksr | https://cloud.tencent.com/developer/article/2287454
