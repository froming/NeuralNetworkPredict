# picture_convert_plus

> 分类：Web

## 题目描述

picture convert 的加强版，加入了 `type` 白名单。但通过第一个 CVE getshell 后直接 env 就能拿到 flag（flag 在环境变量里）。

## 考察知识点

- CVE-2021-22204
- 环境变量中的 flag

## 解法

在上一个题（picture convert）基础上加入 `type` 白名单，无法直接用 convert 命令注入。但通过 CVE-2021-22204（exiftool）getshell 后直接执行 `env`，发现 flag 就在环境变量里。

或者直接查找所有文件，发现 `/etc/profile.d/pouchenv.sh` 中存在 flag。

## 参考答案

（flag 在环境变量 `/etc/profile.d/pouchenv.sh` 中）

## 来源

- 作者：se1zer | https://www.cnblogs.com/seizer/p/17036300.html
