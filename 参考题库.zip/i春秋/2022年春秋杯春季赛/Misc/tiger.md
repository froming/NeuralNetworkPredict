# tiger

> 分类：Misc

## 题目描述

套娃题。ROT47 → 需要密码的 LSB 隐写（cloacked-pixel）→ 明文攻击 → 二维码 → 零宽字符 → 维吉尼亚密码。

## 考察知识点

- ROT47
- LSB 隐写（cloacked-pixel，带密码）
- 明文攻击（zip）
- 二维码识别
- 零宽字符隐写
- 维吉尼亚密码

## 解法

1. `png-key.txt` 内容 ROT47 解密得到 `28a217fe`（LSB 密码）。
2. 用 cloacked-pixel 工具带密码解密 LSB：

```shell
python lsb.py extract key.png-stego.png 1.txt 28a217fe
```

获得解压密码 `71zr9H6jnXRHn64WBxMbCzz16saCZWiw`。

3. 解压出两个压缩包，其中共同存在 `information.txt`，构成明文攻击，攻击出 flag.zip 的密码 `Nh6i@=`。
4. 解压出一个名为 flag 的文件，查看文件头发现是 png，加后缀打开是二维码，扫码得到 `flag is not here`，但中间有零宽字符。
5. 用 [零宽字符解密](https://yuanfux.github.io/zero-width-web/) 解出：

```
Ƀwl wvn n xhkm SBWav krttqbu gfq gja jhheu up yljycxjpu, vvtx R jzeh pydv usd zp lalhmk, ic brtkac ya whep{866q3755-t358-5119-txnr-juw666e8099m}, uroa okv!
```

6. 维吉尼亚密码爆破（https://www.guballa.de/vigenere-solver）：

```
You are a good CTFer because you can solve my challenge, next I will give you my secret, my secret is flag{866d3755-c358-5119-abeb-bda666a8099d}, have fun!
```

## 参考答案

`flag{866d3755-c358-5119-abeb-bda666a8099d}`

## 来源

- 作者：se1zer | https://www.cnblogs.com/seizer/p/17036300.html
- 作者：WXjzc | https://www.cnblogs.com/WXjzc/p/16259961.html
- 作者：V3geD4g | https://blog.csdn.net/xczzhf/article/details/124652308
- 作者：shu天 | https://cn-sec.com/archives/1416716.html
