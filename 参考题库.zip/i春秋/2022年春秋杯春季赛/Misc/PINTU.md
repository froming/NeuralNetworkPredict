# PINTU

> 分类：Misc

## 题目描述

拼图题。14400 张 BMP 图片，bmp 保留字节（第 6、8 字节）记录了拼图的横纵坐标。

## 考察知识点

- BMP 文件格式（保留字节）
- 图片拼接

## 解法

BMP 文件的第 6 字节（reserved1）和第 8 字节（reserved2）是保留字段，被用来记录拼图坐标。x、y 最大值都是 119，最终尺寸 (120*32) x (120*18) = 3840x2160。

```python
from PIL import Image

flag = Image.new('RGB', (3840, 2160))
for i in range(0, 14400):
    f = open(f'img/{i}.bmp', 'rb').read()
    x = f[6]
    y = f[8]
    raw = Image.open(f'img/{i}.bmp')
    flag.paste(raw, (x*32, y*18))

flag.save('flag.bmp')
```

## 参考答案

`flag{Bmp_index_PinTu}`

## 来源

- 作者：WXjzc | https://www.cnblogs.com/WXjzc/p/16259961.html
- 作者：V3geD4g | https://blog.csdn.net/xczzhf/article/details/124652308
- 作者：shu天 | https://cn-sec.com/archives/1416716.html
