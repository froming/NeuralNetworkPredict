# RecoverMe

> 分类：Misc（磁盘取证 + 流量分析）

## 题目描述

VeraCrypt 加密容器爆破 + 磁盘恢复 + ICMP 流量分析（zip 头藏在 ICMP 包长度里，密码藏在 IP 变化里）。

## 考察知识点

- VeraCrypt 容器爆破（passware）
- 磁盘恢复（winhex）
- ICMP 隐蔽信道
- 二进制/ASCII 转换

## 解法

1. 题目给了一个 veracrypt 加密的磁盘文件 + 密码本，用 passware 爆破出密码 `aaaAAA111`。
2. 用 veracrypt 挂载，发现明面上三个文件（其中提示 fake）。用 winhex 打开挂载盘恢复出 `secret.pcapng`。
3. 流量全是 ICMP，每个包的 data 长度不一样，前四个长度 80 75 3 4 → `50 4b 03 04`（PK），即 zip。用 tshark 提取：

```shell
tshark -r secret.pcapng -T fields -e data.len -Y "icmp.type == 8" > out.txt
```

4. 把十进制转 hex 写入文件得到 zip，但需要密码。观察 ping 包目的 ip 最后一位在 38 和 39 之间变化，38→0、39→1，提取二进制：

```python
tshark -r secret.pcapng -T fields -e ip.dst -Y "icmp.type == 8" > ip.txt
# 38 -> 0, 39 -> 1
```

得到 `0111000001100001...` 转 ASCII 即密码 `passwordh3r3`。

5. 解压得到 flag。

## 参考答案

`flag{efaaf34db0bad8e1888e8f671f3cb7ab}`

## 来源

- 作者：WXjzc | https://www.cnblogs.com/WXjzc/p/16259961.html
- 作者：V3geD4g | https://blog.csdn.net/xczzhf/article/details/124652308
- 作者：shu天 | https://cn-sec.com/archives/1416716.html
