# Capture Radiate Chart

> 分类：Misc

## 题目描述

PNG 图片有大量 IDAT 块，每个 IDAT 块的 CRC 值藏了 RAR 文件头数据。提取 RAR 后解压出 PDF，PDF 里藏了 PNG 的 IDAT 块（去头尾），补全后得到 flag。

## 考察知识点

- CRC 隐写
- PNG IDAT 块分析
- PDF 流对象提取
- PNG 文件头/IDAT 块构造

## 解法

1. 用 TweakPNG 查看图片，发现每个 IDAT 块的 CRC 值最后两位正好是 RAR 文件头（52 61 72 21 → Rar!）。
2. 写脚本提取每个 IDAT 块的 CRC 最后一个字节：

```python
data = open('alien.png','rb').read()
flag = ''
pos = data.index(b'IDAT')
data = data[pos+5:]
while 1:
    try:
        pos = data.index(b'IDAT')
        flag += str(hex(data[pos-5])[2:].zfill(2))
        data = data[pos+5:]
    except:
        f1 = open('out.rar','w')
        f1.write(flag)
        exit(1)
```

3. hex 转 rar，解压出一个看起来空白的 PDF。
4. 分析 PDF 结构，有一个 `78 9C` 开头的 stream 数据段（FlateDecode 压缩的图片），提取 Stream 和 Endstream 之间部分。
5. 根据对象属性（`/Height 1403`、`/Width 992`、`/Length 12538`）构造 PNG 文件头和 IDAT 块，补全后得到 flag（或直接用 fitz 库提取图片）。

## 参考答案

`flag{Create_Remarkable_Ctf}`

## 来源

- 作者：WXjzc | https://www.cnblogs.com/WXjzc/p/16259961.html
- 作者：V3geD4g | https://blog.csdn.net/xczzhf/article/details/124652308
- 作者：shu天 | https://cn-sec.com/archives/1416716.html
