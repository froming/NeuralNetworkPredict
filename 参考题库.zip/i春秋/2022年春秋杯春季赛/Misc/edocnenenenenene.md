# edocnenenenenene

> 分类：Misc

## 题目描述

多层编码题。文件翻转 → 6 层编码 → QRCode → BinHex → gzip → emoji-aes → 与佛论禅 → OID/SUS PDU → 短信 PDU 解码。

## 考察知识点

- 文件翻转
- 多层编码识别（QRCode、BinHex、gzip）
- emoji-aes 加密
- 与佛论禅
- OID / SUS PDU / 短信 PDU 解码

## 解法

1. 识别文件头，参考文件名提示将文件翻转，共 6 层编码。
2. 识别 QRCode 得到纯文本（一段奇怪的字符串）。
3. 识别 BinHex 编码，解码后识别 gzip 压缩格式，取出 comment 中的 `CHUNQIUCUP`。
4. 解压缩得到 emoji 及偏移量提示，结合 `CHUNQIUCUP` 用 emoji-aes（https://aghorler.github.io/emoji-aes/）解密，得到一段佛经。
5. 补全"佛又曰"头，用与佛论禅（https://tools.takuron.top/talk-with-buddha/）解密，得到 OID。
6. OID 解码得到十六进制，识别 SUS PDU，用 sms pdu decoder（https://www.diafaan.com/sms-tutorials/gsm-modem-tutorial/online-sms-pdu-decoder/）解码。

## 参考答案

`flag{adaf9c0b-5281-416c-983d-e06148cd016f}`

## 来源

- 作者：CN-SEC | https://cn-sec.com/archives/1216844.html
