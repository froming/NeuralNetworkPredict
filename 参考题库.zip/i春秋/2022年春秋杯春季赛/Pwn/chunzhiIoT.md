# chunzhiIoT

> 分类：Pwn

## 题目描述

模拟 HttpServer 的堆菜单题，libc-2.33，free 存在 UAF，需通过 tcache 基址异或绕过保护。

## 考察知识点

- UAF
- tcache poisoning（2.33 异或保护）
- 堆地址/libc 泄露

## 解法

程序模拟 HttpServer，POST 参数格式：`add: 1&index&size&content`、`edit: 2&index&content`、`show: 3&index`、`free: 4&index`。free 存在 UAF。

利用思路：
1. 利用 2.33 的 tcache 基址和 UAF 泄露 heapbase。
2. 连续释放大于 0x80 的 chunk 填满 tcache，使多余 chunk 进入 unsortedbin，利用 UAF 泄露 libc。
3. 利用 UAF 修改 Tcachebin 单链表表头 chunk 的 fd 为 `__free_hook`（需异或）。
4. 多次申请获得 `__free_hook` 控制权，改为 system。
5. 释放一个 fd 处存 "/bin/sh\x00" 的 chunk 触发 getshell。

关键点：2.33 的 tcache fd 加密是 `fd ^ (chunk_addr >> 12)`，异或对象是 tcachebin 头部 chunk 地址。

```python
# 释放的 chunk 地址右移 12bit 后与目标地址异或
payload = p64(((heapbase + 0x600) >> 12) ^ free_hook)
edit(6, payload)
add(10, 0x80, b"/bin/sh\x00")
add(11, 0x80, p64(system))
free(10)  # trigger
```

## 参考答案

（flag 通过 UAF + tcache poisoning 劫持 free_hook 为 system 后 getshell 读取）

## 来源

- 作者：sh0ve1 | https://sh0ve1.github.io/2022/05/16/2022%E6%98%A5%E7%A7%8B%E6%9D%AF%E7%BD%91%E7%BB%9C%E5%AE%89%E5%85%A8%E8%81%94%E8%B5%9B-%E6%98%A5%E5%AD%A3%E8%B5%9BPwn%E9%A2%98/
