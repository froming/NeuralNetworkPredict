# Sakura

> 分类：Reverse

## 题目描述

数独类逆向题。一个大函数，用 IDA 标函数名后 grep 出调用顺序，再用 z3 求解。

## 考察知识点

- IDA 逆向
- z3 约束求解

## 解法

程序是一个大函数，栈上有变量按顺序填入。用 IDA 标函数名，grep 出 `rp(` 调用顺序，然后 z3 求解（每个变量 16 位，约束为 0-9 且不重复，和为指定值）。

```python
import z3
x = [z3.BitVec(i, 16) for i in range(400)]
s = z3.Solver()

l = open('haha','r').read().split(')\n')
for token in l:
    if 'rp(' not in token: break
    pos = token.index('rp(')
    cparameter = int(token[pos-1:pos], 10)
    pos = token.index('&v') + 1
    oparameter = int(token[pos+1:token.index(';')-1], 10)
    pos = token.index('!= ')
    final = int(token[pos+3:], 10)
    flag = 0
    sum = 0
    for i in range(cparameter):
        p = d[oparameter+i*2]*20 + d[oparameter+i*2+1]
        s.add(x[p] > 0)
        s.add(x[p] <= 9)
        s.add((flag >> x[p]) & 1 != 1)
        flag |= 1 << x[p]
        sum += x[p]
    s.add(sum == final)

print(s.check())
```

解出后把 None 替换为 0 拼接得到答案。

## 参考答案

`0000000000000000000000000092000041000091017037819200638046830296180081071098370000890920000936091500000810120008216028430000310120000498093103700293410003792062019283701207128017200001900000092000091000000000000000000000000014065000271049000041835792008964127501250130730910053037076072086008600026000094805120005300036000570180860005200051048049053808506900850178632940073615284000310740000003501230`

## 来源

- 作者：Azure | https://azure.kdays.cn/2017/11/08/HITCON2017-writeup/
