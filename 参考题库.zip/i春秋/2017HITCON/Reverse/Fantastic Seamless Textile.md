# Fantastic Seamless Textile（天衣無縫）

> 分类：Reverse

## 题目描述

逆向题，涉及特殊的文件格式/解析，参考 radare2 的 PR。

## 考察知识点

- 逆向（radare2）
- 特殊格式解析

## 解法

本题 writeup 仅给出参考链接，未给出详细解法：

- https://gist.github.com/pzread/2ae0bb3aa5fe0dc69fcf3257c41db944
- https://github.com/radare/radare2/pull/8796

## 参考答案

（未给出，参考 radare2 PR）

## 来源

- 作者：Azure | https://azure.kdays.cn/2017/11/08/HITCON2017-writeup/
