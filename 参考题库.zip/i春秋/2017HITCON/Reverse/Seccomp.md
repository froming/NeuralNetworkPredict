# Seccomp

> 分类：Reverse

## 题目描述

BPF 逆向题。程序用 seccomp BPF 实现了 IDEA 加密，需要识别加密算法并逆向解密。

## 考察知识点

- seccomp BPF 逆向
- IDEA 算法识别与解密

## 解法

1. 用工具导出 BPF 汇编，观察发现有几种 pattern（乘法模 0x10001、加法、异或、交换），写脚本解析出算法结构。

2. 识别出是 IDEA 算法（输入 4 个 word，输出 4 个 word，8 轮）。

3. 用 IDEA 解密脚本（CryptoPlus 库），每组密文用对应 key 解密：

```python
from CryptoPlus.Cipher import IDEA
a = []
d = 'bda9a256044419b0'.decode('hex')
key = "galf_ekaf_a_ma_I"
cipher = IDEA.new(key, IDEA.MODE_ECB)
a.append(cipher.decrypt(d)[::-1])
# ... 共 5 组
print("hitcon{%s}" % "".join(a))
```

（每组 key 不同，从 BPF 中解析出来，如 `galf_ekaf_a_ma_I`、`ver_yr7_n0_emoC_` 等）

## 参考答案

`hitcon{w0w_y0u_are_Master-0F-secc0mp///>_w_<///`

## 来源

- 作者：Azure | https://azure.kdays.cn/2017/11/08/HITCON2017-writeup/
