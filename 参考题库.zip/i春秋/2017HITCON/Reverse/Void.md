# Void（家徒四壁 Everlasting Imaginative Void）

> 分类：Reverse

## 题目描述

ELF 逆向题。程序通过 `.rela.dyn` 重定向 `_fini_array[1]` 到特定代码，实现自修改 AES 解密验证。

## 考察知识点

- ELF 重定向（R_X86_64_RELATIVE）
- AES-NI 指令集（aesenc / aesenclast）
- 自修改代码

## 解法

1. 根据 `.rela.dyn`，`0x200DD8`（即 `_fini_array[1]`）被重定向到 `0x935`，退出时执行。

2. `sub_935` 调用 `sub_284`，该函数先判断输入第 16 个字符是否为 `!`（`pop rdi` 得到返回地址 `0x93A`，`[rdi+200715h]` 即 `0x20104f`，对应输入第 16 字符）。

3. 若为 `!`，执行 `0x93A` 处代码：将 `0x...4000`-`0x...5000` 权限改为 RWX（自修改），然后从 `0x486e` 开始，输入存入 xmm1，与初始向量（`0x798` 处 16 字节）异或后，用 `aesenc`/`aesenclast` 指令做 AES 加密（密钥 `0x7a8` 起 10 个 16 字节）。

4. 加密结果与 `0x2846fb67171be9b047cf6d49120447e7` 匹配即显示 Good。

解密脚本参考 https://github.com/5unKn0wn/ctfs/blob/master/2017/hitcon/void.py （`oneRoundDecrypt` 对应 aesenc，`finalRoundDecrypt` 对应 aesenclast）。

## 参考答案

（flag 通过 AES 解密得到）

## 来源

- 作者：RhythmMark | https://rhythmmark.github.io/VOID/
- 作者：Azure | https://azure.kdays.cn/2017/11/08/HITCON2017-writeup/
