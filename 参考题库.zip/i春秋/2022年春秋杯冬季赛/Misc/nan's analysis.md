# nan's analysis

> 分类：Misc（流量分析 + 取证）

## 题目描述

流量分析题。通过分析 FTP 流量找到 root 密码，结合零宽隐写、PHP 混淆解密、AES 解密，最终登录 root 拿 flag。

## 考察知识点

- FTP/HTTP 流量分析
- 零宽字符隐写
- PHP 混淆解密
- AES 解密

## 解法

1. wireshark 打开流量包，检索 `password` 找到一个包，分析 FTP 流量得到：`keyisChunqiuGame00504`。

2. 翻找流量包发现有 `shell.php` 文件（后门）。在终端读这个文件，是零宽隐写，用 [零宽字符解密网站](https://yuanfux.github.io/zero-width-web/) 解密。

3. 解密得到压缩密码提示：`压缩密码格式'abac'*4，abac为纯数字形如1213，此密码与root密码有关`。前面找到密码 `ChunqiuGame00504`，猜测是 `0504*4`：

```
0504050405040504
```

4. 找到文件上传的地方，打开发现上传的后门被加密了（eval 时执行解密）。把 `eval` 改成 `echo` 把结果打印出来，跑一遍得到加密的 root 密码密文：

```
/8MARVmEAnfKntdp2/HP0w==
```

5. 在 `/var/www/html/install` 中执行 `cat .index.php` 得到被混淆的 PHP 代码，用 [PHP 解混淆](https://www.toolnb.com/tools/phpcarbylamine.html) 解密，得到 AES 加密的 root 密码。

6. 结合 PASS key `keyisChunqiuGame00504`，用 [AES 解密](https://www.mklab.cn/utils/aes) 解出 root 密码。

7. 登录 root 拿到 flag。

## 参考答案

（flag 通过登录 root 后读取）

## 来源

- 作者：J_0k3r | https://j-0k3r.github.io/2023/02/09/2022%E5%B9%B4%E6%98%A5%E7%A7%8B%E6%9D%AF%E7%BD%91%E7%BB%9C%E5%AE%89%E5%85%A8%E8%81%94%E8%B5%9B%20%E5%86%AC%E5%AD%A3%E8%B5%9B-wp/
- 作者：Shark-one | https://blog.csdn.net/xccwxy/article/details/128664878
- 作者：S1gMa | https://www.cnblogs.com/S1gMa/p/17007231.html
