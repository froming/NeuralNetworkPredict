# ezphp

> 分类：Web

## 题目描述

PHP 代码，`$num` 需要满足 `is_string`、长度小于 5、不含 `111` 和 `0`，且 `eval("return 111===${num};")` 返回 true。

## 考察知识点

- PHP 字符串与弱类型比较（`===` 绕过）
- 运算符构造（乘法、位运算）

## 解法

源码：

```php
<?php
highlight_file(__FILE__);
$num = $_GET['num'];
if (is_string($num) && strlen($num) < 5 && strpos($num,'111') === false && strpos($num,'0') === false && eval("return 111===${num};")) {
    readfile('/flag');
}
?>
```

关键在 `eval("return 111===${num};")`，即 `${num} = $num`。字符串不允许有 `111` 和 `0`，又要它等于 111。

**解法一（乘法）**：`37*3=111`，长度 4，无 111 和 0：

```
?num=37*3
```

**解法二（位运算）**：利用高版本 PHP 特性 `return (111===1) or 1`：

```
?num=1|1
```

## 参考答案

（flag 通过 readfile('/flag') 读取）

## 来源

- 作者：J_0k3r | https://j-0k3r.github.io/2023/02/09/2022%E5%B9%B4%E6%98%A5%E7%A7%8B%E6%9D%AF%E7%BD%91%E7%BB%9C%E5%AE%89%E5%85%A8%E8%81%94%E8%B5%9B%20%E5%86%AC%E5%AD%A3%E8%B5%9B-wp/
- 作者：S1gMa | https://www.cnblogs.com/S1gMa/p/17007231.html
