# easy_python（baby_python）

> 分类：Reverse

## 题目描述

Python 字节码逆向题。给定一个 42 元素的数组，经 `(x >> 5) | (x << 3) & 255` 运算还原字符。

## 考察知识点

- Python 字节码逆向
- 位运算还原

## 解法

题目是 Python 字节码，关键逻辑是循环 42 次，对 flag 数组每个元素做 `((flag[i] >> 5) | (flag[i] << 3)) & 255` 运算。

还原脚本：

```python
data = [204, 141, 44, 236, 111, 140, 140, 76, 44, 172, 7, 7, 39, 165, 70, 7,
        39, 166, 165, 134, 134, 140, 204, 165, 7, 39, 230, 140, 165, 70, 44,
        172, 102, 6, 140, 204, 230, 230, 76, 198, 38, 175]
flag = [chr((x << 3 | x >> 5) & 0xff) for x in data]
print(''.join(flag))
```

字节码关键命令：
- `BINARY_RSHIFT` = `>>`，`BINARY_LSHIFT` = `<<`，`BINARY_OR` = `|`，`BINARY_AND` = `&`

## 参考答案

（flag 通过位运算还原得到）

## 来源

- 作者：sanyic | https://www.cnblogs.com/sanyic/p/17000809.html
- 作者：S1gMa | https://www.cnblogs.com/S1gMa/p/17007231.html
- 作者：Shark-one | https://blog.csdn.net/xccwxy/article/details/128664878
