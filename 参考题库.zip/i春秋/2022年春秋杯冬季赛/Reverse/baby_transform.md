# baby_transform

> 分类：Reverse

## 题目描述

快速傅里叶变换（FFT）逆向题。读取 flag 文件 → 傅里叶变换 → 输出到 enc 文件，需 IFFT 解密。

## 考察知识点

- 快速傅里叶变换（FFT）
- numpy 逆变换（ifft）

## 解法

分析 `Fourier_transform` 函数，识别为快速傅里叶变换（FFT）。用 numpy 的 `ifft` 逆变换解密 `flag.enc`：

```python
import numpy as np
import struct

with open('./flag.enc', 'rb') as f:
    d_str = f.read()
d_len = len(d_str) // 8
data = struct.unpack(d_len * 'd', d_str)

flag = np.ndarray([], dtype=np.complex128)
for i in range(0, len(data), 2):
    flag = np.append(flag, complex(data[i+1], data[i]))
flag = np.delete(flag, 0)

a = np.fft.ifft(flag)
print(''.join([chr(round(x)) for x in a.real]))
```

## 参考答案

（flag 通过 ifft 逆变换得到）

## 来源

- 作者：sanyic | https://www.cnblogs.com/sanyic/p/17000809.html
- 作者：Shark-one | https://blog.csdn.net/xccwxy/article/details/128664878
