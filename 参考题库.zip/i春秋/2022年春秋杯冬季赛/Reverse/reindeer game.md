# reindeer game

> 分类：Reverse

## 题目描述

驯鹿吃姜饼的游戏，pyinstaller 打包的 Python 程序。要求吃 30 个姜饼人通关拿 flag。

## 考察知识点

- PyInstaller 拆包（pyinstxtractor）
- pyc 反编译（uncompyle6）
- gzip 解压

## 解法

1. 题目是 pyinstaller 打包的 Python 游戏（驯鹿吃姜饼）。

2. 用 pyinstxtractor.py 拆包：

```shell
python3 pyinstxtractor.py reindeer.exe
```

3. 拆包后找到 `reindeer` 文件（实际是 pyc，加上 `.pyc` 后缀），用 uncompyle6 反编译：

```shell
uncompyle6 -o reindeer.py reindeer.pyc
```

4. 分析逻辑，发现 flag 藏在 `getczekolada()` 函数中（在 astar.py 里），是一个 gzip 压缩数据，直接解压：

```python
import gzip
data = b'\x1f\x8b\x08\x00\xd6\x03\xa0c\x02\xffK\xcbIL\xaf\xb60J4JLN2\xd3\xb5\xb400\xd65\xb14\x06\xb2\x8cR\x92t\xd3\x0cM\x8c\rS,\r\x92\xcdR\x0ck\x01\xc7Y,\xef*\x00\x00\x00'
print(gzip.decompress(data))
```

5. 也可以直接修改游戏的 `TO_WIN` 数值（姜饼数量）快速通关。

补充：作者说有彩蛋，同时按下 `0`、`1`、`2` 数字键（非小键盘）触发。

## 参考答案

`flag{82a2acb6-9803-4936-92db-f1431d90c6d1}`

## 来源

- 作者：OrangeStarOne | https://orangestarone.github.io/2022/12/21/2022%E5%B9%B4%E6%98%A5%E7%A7%8B%E6%9D%AF%E5%86%AC%E5%AD%A3%E8%B5%9B-reindeer-game/index.html
- 作者：Shark-one | https://blog.csdn.net/xccwxy/article/details/128664878
