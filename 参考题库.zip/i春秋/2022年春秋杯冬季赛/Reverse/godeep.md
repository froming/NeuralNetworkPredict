# godeep

> 分类：Reverse

## 题目描述

Go 编写的逆向程序，`main_convert` 将输入转换成按字节存放 bits 的数组，根据 bit 数组判断调用哪个函数，最终走到打印 right 的函数。

## 考察知识点

- Go 程序逆向
- IDA 交叉引用分析
- 路径回溯（控制流还原）

## 解法

Go 程序，`main_convert` 将输入转换成按字节存放 bits 的数组。转换后进入一系列函数，根据 bit 数组判断调用哪个函数。

通过字符串交叉引用找到打印 right 的函数，然后不断选择函数调用类型的交叉引用获取路径，卡一下两个函数的位置获取判断条件。

用 IDA Python 脚本自动化回溯路径：

```python
import idc
import idaapi

endaddr = idc.get_name_ea_simple("End")
addr = idc.get_name_ea_simple("Win")
flag = ''

while True:
    if addr == endaddr:
        break
    for xref in XrefsTo(addr, 0):
        if XrefTypeName(xref.type) == "Code_Near_Call":
            cmpaddr = xref.frm
            addr = idaapi.get_func(xref.frm).start_ea
    if idc.GetDisasm(cmpaddr+0xE) == idc.GetDisasm(0x9CAA5E):
        flag = flag + '0'
    else:
        flag = flag + '1'
print(flag[::-1])
```

（注意 `idc.get_name_ea_simple` 需自己重命名函数符号）

## 参考答案

（flag 通过 IDA 脚本回溯控制流得到）

## 来源

- 作者：sanyic | https://www.cnblogs.com/sanyic/p/17000809.html
