# trie

> 分类：Pwn（强网先锋）

## 题目描述

路由表（trie 树）写入程序。添加路由时 trie 树节点索引值大小有误，可越界访问到 secret 变量，通过 view 功能逐段读取 flag。

## 考察知识点

- trie 树算法
- 越界读取

## 解法

1. trie 为二叉树，IP 地址二进制值最低位为根节点，最左边为叶子节点，节点内存有 index 值。
2. 构造 0.0.0.0 和 255.255.255.255 使最后一个叶子节点 index 为 0x40，view 读 255.255.255.255 即可读到 flag 前 4 位。
3. 再添加 128.0.0.0 增加一个叶子节点（0x41），读下一段，以此类推读出整个 flag。

```python
leak_addr_list = [b'255.255.255.255', b'128.0.0.0', b'192.0.0.0', b'224.0.0.0', b'240.0.0.0', b'248.0.0.0', b'252.0.0.0', b'254.0.0.0', b'255.0.0.0', b'255.128.0.0', b'255.192.0.0']
for leak_addr in leak_addr_list:
    # 每次重连，add(0.0.0.0) + add(255.255.255.255) + add(leak_addr)，然后 view 读
```

## 参考答案

`flag{H0w_t0_B3c0m3_a5_str0ng_@s_y0u_guys}`

## 来源

- 作者：星盟安全团队 | https://blog.xmcve.com/2023/12/18/强网杯2023-Writeup/
- 作者：m1ao | https://xz.aliyun.com/news/12701
- https://cn-sec.com/archives/2314955.html
