# chatting

> 分类：Pwn

## 题目描述

向不存在的用户发送消息时，会先申请堆块再检测用户不存在并释放，多次操作导致 double free。填满 tcache 后在 fast bin 上 double free，打 free_hook 为 system。

## 考察知识点

- double free
- tcache / fast bin
- free_hook -> system

## 解法

1. 多次向不存在用户发消息触发 double free。
2. 先填满 tcache bin，再在 fast bin 上 double free。
3. 打 free_hook 为 system，最终 getshell。

```python
# 填满 tcache，然后在 fast bin 上 double free
# 改 free_hook 为 system，触发 free('/bin/sh') 拿 shell
```

## 参考答案

（flag 通过 getshell 读取）

## 来源

- 作者：星盟安全团队 | https://blog.xmcve.com/2023/12/18/强网杯2023-Writeup/
