# warmup23

> 分类：Pwn

## 题目描述

菜单题，add 处存在 off_by_null 漏洞。通过 large bin + fastbin 构造 fake chunk 实现 unlink，泄露 environ + IO_FILE 得到栈地址，修改 add 返回地址构造 orw。

## 考察知识点

- off_by_null
- large bin attack / fastbin
- unlink
- environ + IO_FILE 泄露栈地址
- orw（open/read/write）

## 解法

1. 构造 `0x461` 的 fake chunk 绕过 unlink 检测（1/16 成功率，需爆破）。
2. 通过 large bin 与 fastbin 的配合泄露 libc（`libc.address = leak - 0x219ce0`）。
3. 用 `environ` 和 `_IO_2_1_stdout_` 配合 FSOP 泄露栈地址。
4. 修改 add 函数返回地址，构造 orw 链读 `/flag`。

```python
add(0xb440)  # fake chunk 倒数第二字节为 0x00，需爆破
# ... 大量 large bin / fastbin 操作
fake_size = 0x461
add(0x470, b'a' * 0x450 + p64(0) + p16(fake_size))
# 泄露 libc、heap_base、stack，最后写 orw 链
```

## 参考答案

（flag 通过 orw 读取 /flag）

## 来源

- https://cn-sec.com/archives/2314955.html
