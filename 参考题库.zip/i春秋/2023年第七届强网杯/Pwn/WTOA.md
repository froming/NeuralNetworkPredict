# WTOA

> 分类：Pwn

## 题目描述

WASM 堆管理题。edit 函数留有后门（length == 0x345231 时触发），通过修改 node 结构体使其指向 flag 地址（虚拟地址 0x501b40），再用 show 输出。

## 考察知识点

- WASM 逆向
- 结构体后门利用

## 解法

1. 逆向确定主逻辑 0x2150，各功能地址为虚拟地址（需偏移）。flag 虚拟地址在 0x501b40。
2. edit 函数中 `if (v12 == 0x345231)` 后门：把 node 结构体字段互换，可任意写内容。
3. 利用后门把 node 结构体 `data` 指向 flag 地址：

```python
add(b'AB')
add(b'CD')
edit(0, 0, 0x345231, flat({0x20:0x501b40, 0x28:0x100}, filler=b'\0', length=0x30))
show(1, 0, 0x100)
```

## 参考答案

（flag 通过后门修改结构体指向后 show 输出）

## 来源

- 作者：星盟安全团队 | https://blog.xmcve.com/2023/12/18/强网杯2023-Writeup/
