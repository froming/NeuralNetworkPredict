# hello spring

> 分类：Web（强网先锋）

## 题目描述

Spring Boot + Pebble 模板渲染。模板上传接口写文件（文件名按 GMT 时间生成），再通过 Pebble SSTI 触发 LFI/RCE 反弹 shell。

## 考察知识点

- Spring Boot / Pebble 模板注入（SSTI）
- ClassPathXmlApplicationContext LFI（拆开过滤绕过）
- 文件名爆破（GMT 时间差 8 小时）

## 解法

1. 审计 `/uploadFile`：`myFilter` 过滤后把 content 写入 `/tmp/file_yyyyMMdd_HHmmss.pebble`；`/` 路由 `?x=` 渲染模板。
2. 服务器是 GMT 时间（比 UTC+8 慢 8 小时），上传后爆破时间得到文件名。
3. 构造 Pebble payload，用 `ClassPathXmlApplicationContext`（拆开 `"org.springframework.context."+"support.ClassPathXmlApplicationContext"` 绕过过滤）读取恶意 XML 文件实现 RCE。
4. 反弹 shell 读取 flag（另一解：`SpelExpressionParser` 执行 `ProcessBuilder`）。

## 参考答案

（flag 通过 SSTI RCE 反弹 shell 读取）

## 来源

- 作者：星盟安全团队 | https://blog.xmcve.com/2023/12/18/强网杯2023-Writeup/
- 作者：山石网科安全技术研究院 | https://cn-sec.com/archives/2316376.html
