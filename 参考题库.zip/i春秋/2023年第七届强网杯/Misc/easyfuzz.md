# easyfuzz

> 分类：Misc

## 题目描述

Fuzz 测试题。输入字符串，服务端返回 code coverage（01 串），通过逐位 fuzz 找出能覆盖所有分支的 key。

## 考察知识点

- Fuzz 测试（代码覆盖率）
- 逐位爆破

## 解法

1. 输入任意字符串，返回 `Here is your code coverage: 000000000`，目标是让所有位都为 1。
2. 逐位 fuzz：每多覆盖一个分支，1 的位数就多一位，据此确定每一位字符。

```python
from pwn import *
import string
conn = remote("101.200.122.251", 12177)
key = "?????????"
word_list = string.printable
for i in range(len(key)):
    for word in word_list:
        key = key[:i] + word + key[i + 1:]
        conn.sendline(key.encode())
        recv = conn.recv().decode()
        result = re.search(r'Here is your code coverage: (\d*)', recv).group(1)
        if result[i] == '1':
            print('key:', key)
            break
```

3. 得到 key 为 `00qwbGood`。

## 参考答案

`qwb{YouKnowHowToFuzz!}`

## 来源

- 作者：IHK-1 | https://ihk-one.github.io/posts/2023-qiangwang-cup/
- 作者：m1ao | https://xz.aliyun.com/news/12701
- 作者：天格战队 | https://blog.csdn.net/zzz6583zz/article/details/141131947
- https://cn-sec.com/archives/2314955.html
