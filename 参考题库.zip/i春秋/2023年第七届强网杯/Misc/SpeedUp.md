# SpeedUp

> 分类：Misc（强网先锋）

## 题目描述

计算 `f((2^27)!)`，其中 `f(x)` 为 x 的十进制各位数字之和，然后对结果做 sha256 得 flag。

## 考察知识点

- 大数阶乘各位数字之和（OEIS A244060）
- sha256

## 解法

1. 题目即求 `(2^27)!` 各位数字之和。该值过大无法直接计算，但在 OEIS A244060 有记录。
2. 第 27 项（n=27，即 2^27）对应的值为 `4495662081`。
3. 做 sha256：

```python
import hashlib
fx = 4495662081
flag = hashlib.sha256(str(fx).encode()).hexdigest()
print('flag{%s}' % flag)
```

## 参考答案

`flag{bbdee5c548fddfc76617c562952a3a3b03d423985c095521a8661d248fad3797}`

## 来源

- 作者：m1ao | https://xz.aliyun.com/news/12701
- 作者：天格战队 | https://blog.csdn.net/zzz6583zz/article/details/141131947
- https://cn-sec.com/archives/2314955.html
