# Pyjail ! It's myFILTER !!!

> 分类：Misc

## 题目描述

Python pyjail 沙盒绕过。黑名单屏蔽了大量关键字和函数，但 flag 被放在了环境变量里。

## 考察知识点

- Python pyjail 沙盒绕过
- 环境变量泄露（/proc/self/environ）

## 解法

1. 题目把 `os.system`、`subprocess.Popen` 等替换为 `blacklist_fun_callback`，并黑名单过滤关键字。
2. 由于出题人把 flag 放在环境变量里，直接读取：

```
{print(open("/proc/self/environ").read())}
```

或读取 `/proc/1/environ`。多尝试几次（有一定成功率）。

## 参考答案

（flag 位于环境变量中，读取 /proc/self/environ 得到）

## 来源

- 作者：m1ao | https://xz.aliyun.com/news/12701
- 作者：天格战队 | https://blog.csdn.net/zzz6583zz/article/details/141131947
- 作者：星盟安全团队 | https://blog.xmcve.com/2023/12/18/强网杯2023-Writeup/
- https://cn-sec.com/archives/2314955.html
