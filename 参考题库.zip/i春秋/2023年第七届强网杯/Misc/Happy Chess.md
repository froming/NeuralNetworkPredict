# Happy Chess

> 分类：Misc

## 题目描述

下棋游戏题。通过特定输入序列触发 success，循环 10 次拿 flag。

## 考察知识点

- 游戏逻辑 / 交互

## 解法

1. 测试发现输入 `1 1`、`2 2`、...、`9 9` 再输入 `exit` 会出现 success。
2. 用脚本循环 10 次即可：

```python
from pwn import *
p = remote('47.104.199.71', 10075)
sla(b'> ', token)
for j in range(10):
    for i in range(9):
        sla(b'> ', str(i + 1) + ' ' + str(i + 1))
    sla(b'> ', b'exit')
```

## 参考答案

（flag 通过循环触发 success 得到）

## 来源

- 作者：星盟安全团队 | https://blog.xmcve.com/2023/12/18/强网杯2023-Writeup/
