# 找到PNG了吗

> 分类：Misc（强网先锋）

## 题目描述

内存取证。volatility 分析 linux 镜像，找到 RC4 加密脚本和密钥，dump 出加密的 PNG 区块并解密。

## 考察知识点

- 内存取证（volatility2）
- RC4 加密
- PNG 文件头

## 解法

1. 制作 profile，volatility2 分析 ubuntu20.04 镜像，`--dump-dir` 全量导出。
2. 搜索关键词 "please give" 找到处理 have_your_fun.jocker 的 socket 交互脚本，确认是 RC4 加密，密钥为 `do_not_care` + `where_is_the_key`。
3. RC4 流加密针对 PNG，用 cyberchef 对 PNG 头 `89 50 4E 47` 加密得到密文头，在镜像中搜索该特征，dump 出加密区块。
4. 用 RC4 密钥解密还原 PNG，得到 flag。

## 参考答案

`flag{It's_So_Hard_To_Find_A_Picture}`

## 来源

- 作者：星盟安全团队 | https://blog.xmcve.com/2023/12/18/强网杯2023-Writeup/
- 作者：IHK-1 | https://ihk-one.github.io/posts/2023-qiangwang-cup/
