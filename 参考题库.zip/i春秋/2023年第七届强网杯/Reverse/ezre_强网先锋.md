# ezre（强网先锋）

> 分类：Reverse（强网先锋）

## 题目描述

平坦化控制流的 ELF 程序。算法为多张变异 base64 表 + 异或运算，用 debloat 去混淆后逆推解密。

## 考察知识点

- 平坦化去混淆（deflat）
- 变异 base64 表
- z3 / 异或逆推

## 解法

1. 用 deflat 去除平坦混淆，整理 main 逻辑：先 base64 encode，循环 4 次（每次 srand + swap 生成新表，奇偶次分别 encode/decode），再异或。
2. `dword_4062C0` 判断是否调试：调试则 reverse 表并 `(5*(x+3))^0x15`，非调试则表异或 `0x27`。
3. 用 C 拿 srand 生成的 4 张表，传入 python 逆向：逆异或（z3 或手动），逆 base64。

```python
table = list(tables[-1])
for i in range(64):
    table[i] ^= 0x27
table = table[6:27]
# 逆 xor_cnt 和 base64，最终 flag
flag = base64.b64decode(dst.translate(bytes.maketrans(table, basetable)))
```

## 参考答案

`flag{3ea590ccwxehg715264fzxnzepqz}`

## 来源

- 作者：山石网科安全技术研究院 | https://cn-sec.com/archives/2316376.html
- 作者：天格战队 | https://blog.csdn.net/zzz6583zz/article/details/141131947
- 作者：m1ao | https://xz.aliyun.com/news/12701
- 作者：星盟安全团队 | https://blog.xmcve.com/2023/12/18/强网杯2023-Writeup/
