# ezre

> 分类：Reverse

## 题目描述

ELF 64 位程序，存在 OLLVM 平坦流和 ptrace 反调试。init_array 中开启子进程调用真实校验函数，算法为 SM4 加密（特征码 0xA3B1BAC6）。

## 考察知识点

- OLLVM 平坦流去混淆
- ptrace 反调试
- SM4 加密识别与解密

## 解法

1. main 调用的 `sub_3170` 是假 flag，真实逻辑在 init_array 的 `sub_5150`，其开启子进程 `sub_39F0` 并用 ptrace 反调试。
2. 关键函数 `sub_3580` 中 `sub_2220` 是加密函数，发现 SM4 特征码 `0xA3B1BAC6`（FK 常数）和 Sbox。
3. 密钥为 `01 23 45 67 89 AB CD EF 01 23 45 67 89 AB CD EF`，密文：

```
06 75 19 47 16 63 88 7C 8B 66 55 FF 3F 7D 0D 4A
F5 D2 4E 38 3F E9 C2 DE DB 7C 7F 6F 74 B1 1F 3C
```

4. SM4 解密得到 `666c6167...`（`fl...` 前缀），即 flag。

## 参考答案

`flag{h3kk0_w0rld_sur3_3n0ugh}`

## 来源

- 作者：天格战队 | https://blog.csdn.net/zzz6583zz/article/details/141131947
- 作者：m1ao | https://xz.aliyun.com/news/12701
- https://cn-sec.com/archives/2314955.html
