# babyre

> 分类：Reverse（强网先锋）

## 题目描述

魔改 TEA 加密 + TLS callback 反调试。TLS callback 中根据 BeingDebugged 修改密文（xor index）和密钥（循环左移），需绕过反调试后动调拿数据解密。

## 考察知识点

- TLS callback 反调试
- 魔改 TEA 解密

## 解法

1. 有两个 TlsCallback（字符串 "SomeThing Go Wrong" 交叉引用），检测到调试时修改密文和密钥：密文 xor index，密钥循环左移。
2. 密文：

```
0xE0, 0xF3, 0x21, 0x96, 0x97, 0xC7, 0xDE, 0x89, 0x9B, 0xCA, 0x62, 0x8D, 0xB0, 0x5D, 0xFC, 0xD2,
0x89, 0x55, 0x1C, 0x42, 0x50, 0xA8, 0x76, 0x9B, 0xEA, 0xB2, 0xC6, 0x2F, 0x7C, 0xCF, 0x11, 0xDE
```

3. 魔改 TEA：delta = 0x88408067（或 -0x77BF7F99），4 轮 × 33 次，key = "bomb"。
4. 先对密文 xor index，密钥循环左移一位，再解密：

```c
unsigned char key[] = { 0x31, 0xB7, 0xB6, 0x31 };
// for i: enc[i] ^= i
// for i: key[i] = (key[i] >> 7) | (key[i] << 1)
// decipher(33, enc + 2*i, enc + 2*i + 1)
```

## 参考答案

`flag{W31com3_2_Th3_QwbS7_4nd_H4v3_Fun}`

## 来源

- 作者：山石网科安全技术研究院 | https://cn-sec.com/archives/2316376.html
- 作者：m1ao | https://xz.aliyun.com/news/12701
- https://cn-sec.com/archives/2314955.html
