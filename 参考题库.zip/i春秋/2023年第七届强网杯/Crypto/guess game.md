# guess game

> 分类：Crypto

## 题目描述

猜比特游戏，80 次猜中 56 次以上即可得 flag。单次概率分布为二项分布，直接全猜 0 用生日攻击反复交互即可。

## 考察知识点

- 二项分布 / 概率
- 生日攻击

## 解法

1. 连接后发送 token，选模式 2，连续 80 次都猜 0，统计 "Right" 次数。
2. 单次全猜 0 命中 56 次以上的概率约万分之一，反复重连（生日攻击）即可。

```python
from pwn import *
while True:
    r = remote("47.97.69.130", 22333)
    r.sendline(b"icq4504836a0c0b14a1083d18bfb932f")
    r.sendline(b"2")
    count = 0
    for i in range(80):
        r.recvuntil(b">")
        r.sendline(b"0")
        temp = r.recvline()
        if b"Right" in temp:
            count += 1
    print(count)
    if count > 56:
        print(r.recvline())
        exit()
    r.close()
```

## 参考答案

`flag{be050d3fe312654d40d4ebb60d667c22}`

## 来源

- 作者：m1ao | https://xz.aliyun.com/news/12701
