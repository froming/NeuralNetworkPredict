# PangBai 过家家（1）

> 分类：Web

## 题目描述
本题已开源，详见：https://github.com/cnily03-hive/PangBai-HTTP

一个多关卡 Web 挑战，综合考查 HTTP 报文的各种特性。

## 考察知识点
- HTTP 请求方法（GET/POST/PATCH）
- 请求头（Location、User-Agent、Host、X-Real-IP、X-Forwarded-For、Referer）
- 查询参数（Query）、Content-Type 与 multipart/form-data
- Cookie 与关卡状态
- JWT 签名与伪造

## 解法

### 序章
过完开头的剧情，自动跳转到第一关。如果没有跳转或跳转出现问题，可以手动访问路径 `/start`。

### 第一关
提示「Header」。打开浏览器开发者工具，在「网络」选项卡中找到网页的初始请求，查看响应标头，有一个 Location 字段。访问这个路径，进入下一关。

### 第二关
提示了「Query」和 `ask=miao`，因此访问路径 `/?ask=miao` 即可进入下一关。

### 第三关
提示：用另一种方法（Method）打声招呼（`say=hello`）。用 POST 请求发一个 `say=hello` 的查询即可。

```http
POST /?ask=miao HTTP/1.1
Host: 8.147.132.32:36002
Content-Type: application/x-www-form-urlencoded
Content-Length: 9
Cookie: token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJsZXZlbCI6M30.hc4vKSnI5KZxNFjD27qrms3z6TL6LRnF1qSk_t3ohOI

say=hello
```

### 第四关
提示「Agent」和 `Papa`，考查 `User-Agent` Header，需携带版本号发送 POST 请求。随后需要将 `say` 字段改成「玛卡巴卡阿卡哇卡米卡玛卡呣」（中文需转义）。

```http
POST /?ask=miao HTTP/1.1
Host: 8.147.132.32:36002
Content-Type: application/x-www-form-urlencoded
User-Agent: Papa/1.0
Content-Length: 9
Cookie: token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJsZXZlbCI6NH0.MDhNM30leuBXKpPLgqDnzmK3Zf2sAGdx8VtGcMf21kU

say=%E7%8E%9B%E5%8D%A1%E5%B7%B4%E5%8D%A1%E9%98%BF%E5%8D%A1%E5%93%87%E5%8D%A1%E7%B1%B3%E5%8D%A1%E7%8E%9B%E5%8D%A1%E5%91%A3
```

### 第五关
要求使用 PATCH 方法发送一个 ZIP 文件（`name="file"; filename="*.zip"`），使用 `Content-Type: multipart/form-data` 发包，boundary 用 `abc`。

```http
PATCH /?ask=miao HTTP/1.1
Host: 8.147.132.32:36002
User-Agent: Papa/1.0
Content-Type: multipart/form-data; boundary=abc
Cookie: token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJsZXZlbCI6NX0.xKi0JkzaQ0wwYyC3ebBpjuypRYvrYFICU5LSRLnWq_0
Content-Length: 168

--abc
Content-Disposition: form-data; name="file"; filename="1.zip"

123
--abc
Content-Disposition: form-data; name="say"

玛卡巴卡阿卡哇卡米卡玛卡呣
--abc--
```

### 第六关
提示 `localhost`，意在表明需要让服务器认为这是来自本地的请求。可通过设置 `Host`、`X-Real-IP`、`X-Forwarded-For`、`Referer` 等标头欺骗服务器。

```http
GET /?ask=miao HTTP/1.1
Host: localhost
Referer: http://localhost
Cookie: token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJsZXZlbCI6Nn0.SlKAeN5yYDF9YaHrUMifhYSrilyjPwd2_Yrywq9ff1Y
```

随后提示提到 JWT 和密钥 `Pe2K7kxo8NMIkaeN`。JWT 并不加密，只做签名。将当前 Cookie 粘贴到 [JWT.IO](https://jwt.io)，修改 payload 中的 `level` 为 `0`（彩蛋：Level 0 的「上条当麻」击败了「一方通行」），粘贴签名密钥后复制左侧 Encoded 内容，应用到 Cookie，再次刷新即可到达最终页面。

### 第〇关·终章
点击提示中的「从梦中醒来」，过完片尾小彩蛋即获得 Flag 内容。

## 参考答案
（未给出，需完成全部关卡后获得）

## 来源
- 作者：NewStar CTF 2024 官方 WriteUp | https://newstar.wiki/wp/2024/week1/web/pangbai1.html
