# headach3

> 分类：Web

## 题目描述
题目源码如下：

```php
<?php
header("fl3g: flag{You_Ar3_R3Ally_A_9ooD_d0ctor}");
echo "My HEAD(er) aches!!!!!<br>HELP ME DOCTOR!!!<br>";
?>
```

## 考察知识点
- HTTP 响应头
- 浏览器开发者工具（Network 选项卡）

## 解法
打开浏览器开发者工具的「网络」（Network）选项卡，刷新网页，点击第一个请求，查看响应头，可以看到 flag。

## 参考答案
flag{You_Ar3_R3Ally_A_9ooD_d0ctor}

## 来源
- 作者：NewStar CTF 2024 官方 WriteUp | https://newstar.wiki/wp/2024/week1/web/headach3.html
