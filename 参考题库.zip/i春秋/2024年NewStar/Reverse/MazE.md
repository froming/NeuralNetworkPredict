# MazE

> 分类：Reverse

## 题目描述
出题思路：搞了两个进程，用 pipe 通信，父进程作为客户端显示界面，子进程作为服务端计算数据。地图数据以加密加压缩的方式存储在全局变量里。运行过程中对已走到位置所在的 3×3 矩形进行解密并传输给父进程输出。

解题思路：分析地图解密算法，将全部地图数据复制下来全部解密，然后跑搜索算法。

## 考察知识点
- 双进程 pipe 通信
- 地图数据压缩与 xor 加密的还原
- DFS/BFS 迷宫求解
- MD5 计算

## 解法
`tobinary` 是关键解密函数，`decrypt` 对 map 中特定字节进行 xor 解密，再分解成二进制提取位置数据。map 存放思路：把只有 0/1 的地图压缩成字节数组，再对字节数组 xor 加密，解密只需反过来。key 为 `tgrddf55`。

```c
// 这里只展示关键部分
unsigned char decrypt(unsigned char* buffer, int index) {
    unsigned char t;
    const unsigned char key[] = "tgrddf55";
    t = buffer[index] ^ key[index % 8];
    return t;
}

int tobinary(unsigned char* buffer, int x, int y) {
    int index1 = (x * 99 + y) / 8;
    int index2 = (x * 99 + y) % 8;
    unsigned char t = decrypt(buffer, index1);
    int bin = t >> (7 - index2);
    bin &= 1;
    return bin;
}
unsigned char mapbyte[] = {0x8b, 0x98, 0x8d, 0x9b, 0x9b, 0x99, ....};  // 省略地图数据
int main() {
    int maptest[99][99] = {0};
    for (int i = 0; i < 99; i++) {
        for (int j = 0; j < 99; j++) {
            int bin = tobinary((unsigned char*)mapbyte, i, j);
            maptest[i][j] = bin;
        }
        return 0;
    }
}
```

DFS 求解迷宫：

```cpp
#include <iostream>
using namespace std;
int Map[] = {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, ...};
int map[99][99];
char t[10000];
int r = 0;
int dx[4] = {-1, 0, 1, 0};
int dy[4] = {0, 1, 0, -1};
char op[4] = {'w', 'd', 's', 'a'};
bool check(int qx, int qy) {
    if (qx >= 0 && qx < 99 && qy >= 0 && qy < 99) {
        if (map[qx][qy] == 0) return 1;
    }
    return 0;
}
void dfs(int x, int y) {
    if (x == 97 && y == 97) {
        for (int i = 0; i < r; i++) cout << t[i];
        cout << endl;
        cout << r;
        cout << endl;
        return;
    }
    for (int i = 0; i < 4; i++) {
        int qx = dx[i] + x;
        int qy = dy[i] + y;
        if (check(qx, qy)) {
            t[r] = op[i];
            r++;
            map[x][y] = 1;
            dfs(qx, qy);
            map[x][y] = 0;
            r--;
            t[r] = 0;
        }
    }
}
int main() {
    for (int i = 0; i < 99; i++) {
        for (int j = 0; j < 99; j++) {
            map[i][j] = Map[99 * i + j];
        }
    }
    dfs(1, 1);
    return 0;
}
/*
ddddssssddssaassssddddssssddssssssssddssaaaawwaawwwwwwaaaawwddwwaaaassssssssddssddssssddddssddwwddssddwwddwwaawwwwwwaawwddddssddddddwwaaaawwwwwwddddddddddssssddssssssaassssaassssddddddddssaassddddssssddwwwwddssssssddddwwddwwaawwaawwwwaawwddwwaawwaawwddddssddwwddddssddwwddwwaaaawwwwddwwwwaaaawwddddddddwwwwaawwaawwddddddddddddssaassssssssaassssssaaaassssssaassddddwwddwwddssssddddssssssssssssssssddwwwwwwwwwwwwwwwwwwaawwddwwddwwddssssssssaassddddwwwwwwddwwwwwwddssssddwwwwwwddddddddddssaaaaaassddddssssaassaaaawwaassaassddssssddwwddwwddddssddddwwwwddddwwwwaaaassaawwwwddwwwwwwaawwwwwwaassssssaaaawwwwaawwwwddwwddssddwwddddddddssaassddssssssddssssssssssssssaassssaassssaassssddssaassssssddddddssssssaassssaaaaaawwwwddddwwwwaassaaaaaaaawwwwaaaassddssssssssssddddssssssssaaaassssaaaassssssssssddddddwwwwwwaaaawwddddwwddwwddwwddddddddddssssaassssaassddssssaaaaaassaaaaaassddddddssddwwddssssaaaaaassddssssaawwaaaaaassssssddwwddddddddddddssdd
936
*/
```

对路径求 MD5 得到 flag。

## 参考答案
flag{4ed5a17ee7aeb95fcf12a3b96a9d4e6f}

## 来源
- 作者：NewStar CTF 2024 官方 WriteUp | https://newstar.wiki/wp/2024/week4/reverse/maze.html
