# simpleAndroid

> 分类：Reverse

## 题目描述
一个 Android apk，使用 jadx 分析。先经过 `checkRoot.check()` 的 root 检测，再跳转到 `CheckActivity`。`CheckData` 是 native 层方法（动态注册在 `JNI_OnLoad` 中），处理逻辑：先对 `UseLess` 的 `CHAR_DATA` 进行换表 Base64 变换，再前后交换位置，然后循环右移 4 位，最后与密文比较。

## 考察知识点
- Android 逆向（jadx）
- JNI 动态注册
- 换表 Base64
- 位运算逆推

## 解法
从后往前逆运算：先循环左移 4 位，再前后交换，最后换表 Base64 解码。

```python
import base64

enc = [
  0xB2, 0x74, 0x45, 0x16, 0x47, 0x34, 0x95, 0x36, 0x17, 0xF4,
  0x43, 0x95, 0x03, 0xD6, 0x33, 0x95, 0xC6, 0xD6, 0x33, 0x36,
  0xA7, 0x35, 0xE6, 0x36, 0x96, 0x57, 0x43, 0x16, 0x96, 0x97,
  0xE6, 0x16
]

for i in range(len(enc)):
    enc[i] = (enc[i] << 4 | enc[i] >> 4) & 0xff

for i in range(len(enc)//2):
    tmp = enc[i]
    enc[i] = enc[len(enc) - i - 1]
    enc[len(enc) - i - 1] = tmp

cipher = ''.join([chr(e) for e in enc])
new_table = "BCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/A"
old_table = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"

print(base64.b64decode(cipher.translate(str.maketrans(new_table, old_table))))
```

## 参考答案
（未给出）

## 来源
- 作者：NewStar CTF 2024 官方 WriteUp | https://newstar.wiki/wp/2024/week3/reverse/simpleandroid.html
