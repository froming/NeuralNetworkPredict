# Ezencypt

> 分类：Reverse

## 题目描述
Android 题目。打开 MainActivity 查看 Onclick 逻辑，`Enc enc = new Enc(tx)`，加密逻辑在 `Enc`。Enc 构造函数里进行第一次加密（ECB 模式 AES，密钥是 MainActivity 的 title），`doEncCheck` 是 native 函数（so 文件）进行第二次加密检查。

## 考察知识点
- Android 逆向
- AES ECB
- native so 逆向
- RC4 + 异或加密

## 解法
IDA 打开 so 文件，找到 `doEncCheck` 的实现。数据经过 `enc` 函数加密，再在循环里检验。`enc` 里一个异或加密，一个 RC4，key 是 `xork`。

解密脚本（C）：

```c
#include "stdio.h"
#include "string.h"

char xork[] = "meow";
#define size 256

unsigned char sbox[257] = {0};

// 初始化 s 盒
void init_sbox(char *key) {
    unsigned int i, j, k;
    int tmp;

    for (i = 0; i < size; i++) {
        sbox[i] = i;
    }

    j = k = 0;
    for (i = 0; i < size; i++) {
        tmp = sbox[i];
        j = (j + tmp + key[k]) % size;
        sbox[i] = sbox[j];
        sbox[j] = tmp;
        if (++k >= strlen((char *)key)) k = 0;
    }
}

// 加解密函数
void encc(char *key, char *data) {
    int i, j, k, R, tmp;

    init_sbox(key);

    j = k = 0;
    for (i = 0; i < strlen((char *)data); i++) {
        j = (j + 1) % size;
        k = (k + sbox[j]) % size;

        tmp = sbox[j];
        sbox[j] = sbox[k];
        sbox[k] = tmp;

        R = sbox[(sbox[j] + sbox[k]) % size];

        data[i] ^= R;
    }
}

void enc(char *in) {
    int len = strlen(in);
    for (int i = 0; i < len; ++i) {
        in[i] ^= xork[i % 4];
    }
    encc(xork, in);
}

int main() {
    unsigned char mm[] = {0xc2, 0x6c, 0x73, 0xf4, 0x3a, 0x45, 0x0e, 0xba, 0x47, 0x81, 0x2a,
                          0x26, 0xf6, 0x79, 0x60, 0x78, 0xb3, 0x64, 0x6d, 0xdc, 0xc9, 0x04,
                          0x32, 0x3b, 0x9f, 0x32, 0x95, 0x60, 0xee, 0x82, 0x97, 0xe7, 0xca,
                          0x3d, 0xaa, 0x95, 0x76, 0xc5, 0x9b, 0x1d, 0x89, 0xdb, 0x98, 0x5d};
    enc(mm);
    for (size_t i = 0; i < 44; i++) {
        putchar(mm[i]);
    }
    puts("");
}
```

将 so 层解密后的数据（输出）用 CyberChef 进行 Base64 和 AES 解密即可。AES 密钥为 `IamEzEncryptGame`（MainActivity 的 title）。

## 参考答案
flag 未在 writeup 中给出（见 CyberChef 截图）。

## 来源
- 作者：NewStar CTF 2024 官方 WriteUp | https://newstar.wiki/wp/2024/week2/reverse/ezencypt.html
