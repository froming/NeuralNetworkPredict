# drink_tea

> 分类：Reverse

## 题目描述
使用 DIE 查看，无壳，64 位。主函数逻辑简单：判断输入字符串长度是否为 32，然后和 key 进入一个加密函数，即 TEA 算法。

## 考察知识点
- TEA 加密算法
- 逆向解密

## 解法
密钥为 `WelcomeToNewStar`，密文 32 字节。TEA 解密脚本（C）：

```c
#include <stdio.h>
#include <stdint.h>

// 解密函数
void decrypt (uint32_t* v, uint32_t* k) {
    uint32_t v0 = v[0], v1 = v[1], i;
    uint32_t delta = 2654435769;
    uint32_t sum = (32)*delta;
    uint32_t k0 = k[0], k1 = k[1], k2 = k[2], k3 = k[3];
    for (i = 0; i < 32; i++) { // 解密时将加密算法的顺序倒过来，+= 变为 -=
        v1 -= ((v0 << 4) + k2) ^ (v0 + sum) ^ ((v0>>5) + k3);
        v0 -= ((v1 << 4) + k0) ^ (v1 + sum) ^ ((v1>>5) + k1);
        sum -= delta;
    }
    v[0] = v0; v[1] = v1; // 解密后再重新赋值
}


unsigned char keys[] = "WelcomeToNewStar";
unsigned char cipher[] = { 0x78,0x20,0xF7,0xB3,0xC5,0x42,0xCE,0xDA,0x85,0x59,0x21,0x1A,0x26,0x56,0x5A,0x59,0x29,0x02,0x0D,0xED,0x07,0xA8,0xB9,0xEE,0x36,0x59,0x11,0x87,0xFD,0x5C,0x23,0x24 };
int main()
{
    unsigned char a;
    uint32_t *v = (uint32_t*)cipher;
    uint32_t *k = (uint32_t*)keys;

    for (int i = 0; i < 8; i += 2)
    {
        decrypt(v + i, k);
    }

    for (int i = 0; i < 32; i++) {
        printf("%c", cipher[i]);
    }

    return 0;
}
```

## 参考答案
flag 未在 writeup 中以文本形式给出（运行脚本得到）。

## 来源
- 作者：NewStar CTF 2024 官方 WriteUp | https://newstar.wiki/wp/2024/week2/reverse/drink_tea.html
