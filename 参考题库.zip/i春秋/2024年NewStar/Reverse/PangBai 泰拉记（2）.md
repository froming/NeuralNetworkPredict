# PangBai 泰拉记（2）

> 分类：Reverse

## 题目描述
最普通的 VM，加密是换表（防止约束爆破直接出）。前面有针对表的伪随机，可动调或直接复现。

## 考察知识点
- VM 逆向（opcode 还原流程图）
- 换表加密 + 伪随机数（srand/rand）复现

## 解法
opcode 打印还原流程图。表由 `srand(0x114514)` 打乱生成，可动调出，也可直接复现：

```c
#include <stdio.h>
#include <stdlib.h>
int main() {
    unsigned char array[128];
    for (int i = 0; i < 128; i++) {
        array[i] = i;
    }
    srand(0x114514);
    for (int i = 127; i > 0; i--) {
        int j = rand() % (i + 1);
        int temp = array[i];
        array[i] = array[j];
        array[j] = temp;
    }
    unsigned char pw[24]={0x28,0x79,0x17,0x4,0xc,0x73,0x26,0x36,0x50,0x39,0x7e,0x24,0x51,0x17,0x44,0x25,0x6,0x70,0x4d,0x40,0x79,0x35,0x73,0x21};
    for(int i=0;i<24;i++)
    {
        for(int j=0;j<128;j++)
        {
            if(pw[i]==(array[j]^i))
            {
                printf("%c",(j-i+128)%128);
            }
        }
    }
    return 0;
}
// flag{W0w_y0u_$01v3_VM!!}
```

## 参考答案
flag{W0w_y0u_$01v3_VM!!}

## 来源
- 作者：NewStar CTF 2024 官方 WriteUp | https://newstar.wiki/wp/2024/week5/reverse/pangbai-terra2.html
