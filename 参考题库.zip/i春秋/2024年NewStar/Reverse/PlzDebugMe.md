# PlzDebugMe

> 分类：Reverse

## 题目描述
一道 Android 逆向题，推荐使用 frida（spawn 模式无 ptrace 特征）。软件有虚拟机检测，需要去掉。key 是在 `g4tk4y` 调用后得到的，`FishEnc` 里是 Blowfish，数据加密后传入 so 层检验。

```java
if (MainActivity$$ExternalSyntheticBackport0.m(valueOf)) {
    new MaterialAlertDialogBuilder(this)
        .setTitle((CharSequence) "CheckResult")
        .setPositiveButton((CharSequence) "确定", (DialogInterface.OnClickListener) null)
        .setMessage((CharSequence) "不准拿空的骗我哟")
        .create().show();
    return;
} else if (check(new FishEnc(g4tk4y()).doEnc(valueOf))) {
    ...Congratulations...
} else {
    ...Wrong...
}
```

## 考察知识点
- frida hook（绕过虚拟机检测、获取 key）
- JNI / so 层逆向
- Blowfish 加密
- Base64 换位换表魔改

## 解法
用 frida 绕过虚拟机检测并 hook `g4tk4y` 获取返回值 `jRLgC/Pi`（这是 Key）：

```javascript
Java.perform(function () {
  let MainActivity = Java.use("work.pangbai.debugme.MainActivity");
  MainActivity["isEmu"].implementation = function () {
    console.log(`MainActivity.isEmu is called`);
    return 0;
  };
});
```

```javascript
MainActivity["g4tk4y"].implementation = function () {
  console.log(`MainActivity.g4tk4y is called`);
  let result = this["g4tk4y"]();
  console.log(`MainActivity.g4tk4y result=${result}`);
  return result;
};
```

IDA 打开 so，自写加密与 `status` 有关，`status` 通过 JNI `GetStaticIntField` 获取。交叉引用 `qword_3800` 发现是 `Java_work_pangbai_debugme_MainActivity_g4tk4y` 初始化的字段。jadx 里 `status = getApplicationInfo().flags & 2`，故 status 为 0 或 1，编写脚本尝试即可。

```c
#include "stdio.h"
#include "string.h"

unsigned char mm[] = {0x08,0x55,0x5f,0x9c,0x70,0x19,0x56,0x40,0x04,0x69,0x67,0x58,0x85,0x52,0x3e,0xc1,0x4c,0x2d,0xdc,0x75,0xaf,0x6e,0xf0,0x06,0xa5,0x5d,0x7b,0x6e,0x2a,0xae,0x7e,0xe3,0xfd,0xfe,0xb9,0xf1,0xac,0x6b,0x96,0x06,0x43,0xbf,0x21,0x4a,0x12,0xf5,0xdb,0x47};
#define ROR(v, n) (v >> n | v << (32 - n))
#define ROL(v, n) (v << n | v >> (32 - n))
void decrypt(char *in, int num, int status)
{
    unsigned int *p = (unsigned int *)(in);
    p[0] ^= p[num - 1];
    p[0] = status ? ROL(p[0], num) : ROR(p[0], num);
    p[0] ^= p[num - 1];
    for (int i = num - 2; i >= 0; --i)
    {
        p[i + 1] ^= p[i];
        p[i + 1] = status ? ROL(p[i + 1], (i + 1)) : ROR(p[i + 1], (i + 1));
        p[i + 1] ^= p[i];
    }
    puts(in);
}
int main()
{
    int status = 0;
    decrypt(mm, 12, status);
}
// XMvFLgfEmEZFtNLkyupZSOEncBR/BVaqzil47iBYYFE=
```

拿 key `jRLgC/Pi` 和密文去 CyberChef 解密：[Recipe](https://gchq.github.io/CyberChef/#recipe=From_Base64\('A-Za-z0-9%2B/%3D',true,false\)Blowfish_Decrypt\(%7B'option':'UTF8','string':'jRLgC/Pi'%7D,%7B'option':'Hex','string':''%7D,'ECB','Raw','Raw'\)&input=WE12RkxnZkVtRVpGdE5Ma3l1cFpTT0VuY0JSL0JWYXF6aWw0N2lCWVlGRT0).

## 参考答案
flag{U_@r4_r4v4r54_m@s74r}

## 来源
- 作者：NewStar CTF 2024 官方 WriteUp | https://newstar.wiki/wp/2024/week4/reverse/plzdebugme.html
