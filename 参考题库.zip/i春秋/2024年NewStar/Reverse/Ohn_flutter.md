# Ohn_flutter!!!

> 分类：Reverse

## 题目描述
Flutter 逆向题。用 blutter 反编译得到 asm 和 ida_script，在 IDA 中加载头文件和脚本获取符号。核心加密流程为：XXTEA -> AES -> Base64 -> 对比。

## 考察知识点
- Flutter 逆向（blutter + IDA 脚本恢复符号）
- XXTEA 识别与解密
- AES（Key/IV 从动调获取）
- Base64 编解码

## 解法
blutter 反编译得到 `asm` 文件夹和 `ida_script` 文件夹，`ida_script` 在 IDA 里先加载 `ida_dart_struct.h` 头文件再运行 `addNames.py` 脚本可得到大部分符号。

在 IDA 中函数列表搜索 `check`，交叉引用溯源找到主逻辑 `_anon_closure_2d4f08`。分析 `jumppp_2fe3c8`：
- `KeyStub`、`IVStub`、`AESStub`：AES 加密特征
- `_encryptUint32List_2fe5ec` 中 `((z>>5^y<<2)+(y>>3^z<<4)) ^ ((sum^y)+(key[(p&3)^e]^z))` 一眼是 XXTEA
- 最后是 base64 和 `check`

在 `_anon_closure_2d4f08` 开头下断点，单步调试在判断处拿到密文、Key 和 IV；XXTEA 的 Key 在加密特征处（`&3` 运算附近）拿到。

解密代码（XXTEA + Base64）：

```c
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <stdlib.h>
typedef unsigned int uint32_t;
#define DELTA 0x9e3779b9
#define MX (((z>>5^y<<2) + (y>>3^z<<4)) ^ ((sum^y) + (key[(p&3)^e] ^ z)))
// 容易魔改
void btea(uint32_t * v, int n, uint32_t const key[4]) {
    uint32_t y,  z, sum;  unsigned p, rounds, e;
    if (n > 1) {
        rounds = 6 + 52 / n;
        sum = 0;
        z = v[n - 1];
        do {
            sum += DELTA;
            e = (sum >> 2) & 3;
            for (p = 0; p < n - 1; p++) {
                y = v[p + 1];
                z = v[p] += MX;
            }
            y = v[0];
            z = v[n - 1] += MX;
        } while (-- rounds );
    } else if (n < -1) {
        n = -n;
        rounds = 6 + 52 / n;
        sum = rounds * DELTA;
        y = v[0];
        do {
            e = (sum >> 2) & 3;
            for (p = n - 1; p > 0; p--) {
                z = v[p - 1];
                y = v[p] -= MX;
            }
            z = v[n - 1];
            y = v[0] -= MX;
            sum -= DELTA;
        } while (-- rounds );
    }
}

char base64[65] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
// ... encodeBase64 / decodeBase64 实现（略，见原文）

int main(){
// 密文在 Java 层 "/oIHOyDg6s6yqVd26AnYJ6u2YjPcMhawTe93+AJPAUiwGZM4KWvXjsib1tcnZHSnglaaVpbcOaTtNoMCr5od2A=="
// Key 和 IV 很容易得到，拿去 AES 解密
char mm[]="v9JIAiQs2XJBl49MyDo4dEMac6RvSLxy+YKcj6OdvpcQB3pt";
char *mm1;
char *mm2;

decodeBase64(mm,strlen(mm),&mm2);
char key[]="ohn_flutterkkkkk";
btea((uint32_t*)mm2,-(strlen(mm)/4*3/4),(uint32_t*)key);
puts(mm2);
}
```

AES 解密可参见 CyberChef Recipe（Key/IV 动调得到）：
https://gchq.github.io/CyberChef/#recipe=From_Base64\('A-Za-z0-9%2B/%3D',true,false\)AES_Decrypt\(...)

## 参考答案
flag{U_@r4_F1u774r_r4_m@ster}

## 来源
- 作者：NewStar CTF 2024 官方 WriteUp | https://newstar.wiki/wp/2024/week5/reverse/ohn_flutter.html
