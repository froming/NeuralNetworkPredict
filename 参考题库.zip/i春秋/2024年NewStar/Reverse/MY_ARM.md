# MY_ARM

> 分类：Reverse

## 题目描述
静态编译的 ARM 程序，使用 TEA 加密，未做魔改。需要注意有一个函数在 `main` 执行前就执行了，覆盖了密文数组和密钥数组——这个函数才是真正运行的，其他几个函数都是用来迷惑的。

## 考察知识点
- ARM 逆向（qemu 动态调试）
- TEA 加密识别与解密
- 构造函数（`main` 前执行）覆盖关键数据

## 解法
使用 qemu 进行动态调试（可参考 https://xz.aliyun.com/t/10214 ），程序本身没有加很多混淆，静态分析也可。程序用标准 TEA 加密，无魔改。真正执行加密的函数在 `main` 之前运行。

解密代码：

```c
// exp.c
#include<stdio.h>
#include<stdlib.h>
#include<stdbool.h>
unsigned int delta=0x9e3779b9;
int rounds=32;
unsigned char true_enc[]={0x44,0xcb,0xf8,0xa0,0xcf,0x83,0x2f,0xf8,0xc2,0x48,0x5e,0xa5,0x0a,0xe0,0x26,0x7a,0xc9,0x54,0xe3,0xf1,0x15,0x99,0x7d,0x68,0xe8,0x16,0x88,0xf8,0x86,0x8e,0x87,0x90,0x98,0x62,0xb0,0x3a,0x8b,0xe7,0xcf,0xcb,0x50,0x0f,0x8f,0x57,0x65,0x3c,0x9e,0xc3,0x84,0x2b,0xe9,0xbb,0xa2,0x2c,0x8a,0x12,0xf5,0x03,0x8f,0xdb,0xe2,0xf8,0x82,0x84};
unsigned int true_key[4] = {0x11223344, 0x55667788, 0x9900aabb, 0xccddeeff};
void tea_decrypt(unsigned int *v,unsigned int *k) {
    int v0 = v[0], v1 = v[1];
    int sum = delta * rounds;
    for (int i = 0; i < rounds; i++) {
        v1 -= ((v0 << 4) + k[2]) ^ (v0 + sum) ^ ((v0 >> 5) + k[3]);
        v0 -= ((v1 << 4) + k[0]) ^ (v1 + sum) ^ ((v1 >> 5) + k[1]);
        sum -=delta;
    }
    v[0] = v0;
    v[1] = v1;
}
void tea(unsigned int* v,unsigned int* k){
    for(int i=0;i<16;i+=2){
        tea_decrypt(v+i,k);
    }
}

int main(){
    tea((unsigned int*)true_enc, true_key);
    for(int i=0;i<64;i++){
        printf("%c",true_enc[i]);
    }
    printf("\n");
    return 0;
}
```

## 参考答案
（未给出）

## 来源
- 作者：NewStar CTF 2024 官方 WriteUp | https://newstar.wiki/wp/2024/week5/reverse/my_arm.html
