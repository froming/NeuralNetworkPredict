# begin

> 分类：Reverse

## 题目描述
一个入门级 Reverse 题目，通过 IDA 逐步引导，找到被拆分成多部分的 flag。

## 考察知识点
- IDA 基础使用（F5、Shift+F12、X 交叉引用）
- 字符串定位与变量查看

## 解法
首先运行一下这个程序，可以发现很多提示，我们根据提示首先使用 IDA 打开，接下来按下 F5 得到伪代码。

根据提示，点击 `flag_part1` 这个变量，从而得到 flag 的第一部分。如果 IDA 显示是十六进制数据，则可以在十六进制数据那按下 A，从而得到字符串。

接下来返回主函数界面，可以点击标签栏中的 Pseudocode-A。再根据提示，按下 Shift+F12，可以看到一个很明显的字符串，点进去，从而得到 flag 第二部分。

根据提示，在 Format 上按下 X 查看是谁引用了这个字符串。再根据提示，在函数名字上按下 X 键找到是哪个函数引用了这个函数。

根据提示，这个函数名就是最后一部分，并且在最后加上 `}`。

则最后拼起来的 flag 是 `flag{Mak3_aN_3Ff0rt_tO_5eArcH_F0r_th3_f14g_C0Rpse}`。

## 参考答案
flag{Mak3_aN_3Ff0rt_tO_5eArcH_F0r_th3_f14g_C0Rpse}

## 来源
- 作者：NewStar CTF 2024 官方 WriteUp | https://newstar.wiki/wp/2024/week1/reverse/begin.html
