# ezAndroidStudy

> 分类：Reverse

## 题目描述
本题主要考查对 APK 基本结构的掌握，flag 被分成五部分藏在 APK 的不同位置。

## 考察知识点
- APK 基本结构
- Jadx 反编译
- AndroidManifest.xml、resources.arsc、layout、raw 资源
- SO 文件逆向（IDA64）

## 解法

### 第一部分
查看 `AndroidManifest.xml` 可以发现 activity 只有 `Homo` 和 `MainActivity`。用 Jadx 打开 `work.pangbai.ezandroidstudy.Homo` 就可以获得 flag1。

### 第二部分
打开 `resources.arsc/res/value/string.xml` 搜索 flag2 即可。

### 第三部分
按描述到 `/layout/activity_main.xml` 找即可。

### 第四部分
`/res/raw/flag4.txt` 里。

### 第五部分
IDA64 打开 `lib/x86_64/libezandroidstudy.so`，找到以 Java 开始的函数，按 F5 即可。

## 参考答案
flag{Y0u_@r4_900d_andr01d_r4V4rs4r}

## 来源
- 作者：NewStar CTF 2024 官方 WriteUp | https://newstar.wiki/wp/2024/week1/reverse/ezandroidstudy.html
