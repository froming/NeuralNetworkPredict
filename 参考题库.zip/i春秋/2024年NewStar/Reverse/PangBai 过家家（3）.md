# PangBai 过家家（3）

> 分类：Reverse

## 题目描述
用 DIE 检测可知是 PyInstaller 打包的 Python 程序。使用 PyInstaller Extractor 解包后得到一个目录，我们只关心与程序同名的 `NotNormalExe.pyc`，反编译它看逻辑即可。

## 考察知识点
- PyInstaller 解包
- pyc 反编译
- 异或逻辑分析

## 解法
解包方法很多（如 PyInstaller Extractor）。反编译方法包括在线网站（如 tool.lu/pyc）或 pycdas。由于字节码版本较高，直接反编译可能出错，可猜测是异或，或用 pycdas 看机器码找到关键的异或逻辑。

本题主打查询资料能力，本质是异或逻辑。

## 参考答案
（未给出）

## 来源
- 作者：NewStar CTF 2024 官方 WriteUp | https://newstar.wiki/wp/2024/week3/reverse/pangbai3.html
