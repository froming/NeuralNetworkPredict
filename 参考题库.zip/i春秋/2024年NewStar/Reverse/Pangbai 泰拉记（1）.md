# Pangbai 泰拉记（1）

> 分类：Reverse

## 题目描述
主函数是一个很简单的 flag 异或一个 key，但在主函数前，有个前置函数会对 key 进行修改。前置函数里写了两个很经典的反调试。

## 考察知识点
- 反调试
- 交叉引用（X）
- 动态调试（改跳转 / 改寄存器）

## 解法
逻辑：当检测到调试时，key 会被异或替换成错误的 key；正常运行则 key 被替换异或成正确的 key。

- 解法 1：直接把反调试函数 `nop` 掉（不太推荐，对汇编不熟悉的话会报错）
- 解法 2：改跳转（推荐）。断到关键处时，改 `jz` 为 `jnz` 或改 ZF 寄存器，跳到正确的 key，得到正确的 flag
- 解法 3：安装自动绕过反调试插件（小幽灵）

得到正确的 flag 和 key 后即可解出。

## 参考答案
flag 未在 writeup 中给出（见截图）。

## 来源
- 作者：NewStar CTF 2024 官方 WriteUp | https://newstar.wiki/wp/2024/week2/reverse/pangbai-terra1.html
