# ezrust

> 分类：Reverse

## 题目描述
一道 Rust 编写的逆向题，建议使用 IDA 8.3 及以上分析。通过 `string` 找到主逻辑，`stdin.read_line` 读入数据，`v6` 是密文，后面有判断密文相等的逻辑，并存在一个 `loverust` 字符串。

## 考察知识点
- Rust 二进制逆向（IDA 8.3+）
- 动态调试（硬件断点）
- 交叉引用定位加密循环
- 异或解密

## 解法
Rust 语言调用链复杂，加密逻辑与主逻辑包裹多层，故采用动调。基本分析后可知 `loverust` 是加密的 key。在 `loverust` 上下硬件断点开始动调，IDA 断在加密处。对函数按 X 多次交叉引用找到加密循环。

查看变量可知 `a3` 是输入，`a1` 是 `loverust`，`v5` 是指针。`v7 = 8 - 1 = 7`，即 `key[7 - (i % 8)]` 的逻辑——`loverust` 逆序与输入进行异或。

```python
en=[
    0x12, 0x1f, 0x14, 0x15, 0x1e, 0x0f, 0x5f, 0x39, 0x2b, 0x33, 0x07, 0x41,
    0x3a, 0x4f, 0x5f, 0x03, 0x10, 0x2c, 0x35, 0x06, 0x3a, 0x04, 0x1a, 0x1f,
    0x00, 0x0e
  ]
s=''
key='loverust'
for i in range(len(en)):
  s+=chr(en[i]^ord(key[7 - (i % 8)]))
print(s)
```

## 参考答案
（未给出，运行脚本输出即 flag）

## 来源
- 作者：NewStar CTF 2024 官方 WriteUp | https://newstar.wiki/wp/2024/week4/reverse/ezrust.html
