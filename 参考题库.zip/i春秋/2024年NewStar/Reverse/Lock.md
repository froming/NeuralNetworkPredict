# Lock

> 分类：Reverse

## 题目描述
程序告诉你每次输入对了多少个字符，因此可以逐位爆破。程序由 Cython 编写（把 Python 转化为 C 语言），逆向极为复杂。

## 考察知识点
- 逐位爆破（oracle：返回正确字符个数）
- Cython 打包程序的逆向思路

## 解法
利用程序会返回"输入正确了多少个字符"这一信息，逐位爆破 password。

EXP：

```python
import check

password = "00000000000000000000"
table = "123456789abcdef"
ret = check.check(password)

password_list = list(password)

for i in range(20):
    for j in range(16):
        newpassword_list = password_list.copy()
        newpassword_list[i] = table[j]
        newpassword = ''.join(newpassword_list)
        # print(newpassword)
        newret = check.check(newpassword)
        if newret == ret + 1:
            password_list[i] = table[j]
            ret = newret
            break
        elif newret == ret:
            continue
        elif newret == ret - 1:
            break

print(newpassword)
```

## 参考答案
（未给出）

## 来源
- 作者：NewStar CTF 2024 官方 WriteUp | https://newstar.wiki/wp/2024/week5/reverse/lock.html
