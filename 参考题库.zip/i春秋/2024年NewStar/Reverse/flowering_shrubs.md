# flowering_shrubs

> 分类：Reverse

## 题目描述
程序在随机位置添加了同一个花指令，导致 IDA 无法正常分析。需要用 IDAPython 自动去除花指令后再 F5 反编译。

## 考察知识点
- 花指令
- IDAPython 脚本去花
- 递归加密逻辑逆推

## 解法
使用 IDAPython 去除花指令（`lis` 为花指令的完整内容），将匹配到的 27 字节全部 nop 掉：

```python
# remove_flower.py
import idc
import idaapi
startaddr=0x1100
endaddr=0x15FF
lis=[0x50, 0x51, 0x52, 0x53, 0xE8, 0x00, 0x00, 0x00, 0x00, 0x5B, 0x48, 0x81, 0xC3, 0x12, 0x00, 0x00, 0x00, 0x48, 0x89, 0x5C, 0x24, 0x18, 0x48, 0x83, 0xC4, 0x18,0xC3]
for i in range(startaddr,endaddr):
    flag=True
    for j in range(i,i+27):
        if idc.get_wide_byte(j)!=lis[j-i]:
            flag=False
    if flag==True:
        for addr in range(i,i+27):
            idc.patch_byte(addr,0x90)

for i in range(startaddr,endaddr):
    idc.del_items(i)
for i in range(startaddr,endaddr):
    if idc.get_wide_dword(i)==0xFA1E0FF3: #endbr64
        idaapi.add_func(i)
```

在 IDA 中选择 **File » Script file** 运行，之后 F5 得到清晰伪代码。关键内容是 `encrypt` 函数，使用递归：40 字节每 4 字节一组共 10 组，通过 `get_next_rand` 得到下一组加密字节。

```python
#solve.py
lis=[0x54,0xf4,0x20,0x47,0xfc,0xc4,0x93,0xe6,0x39,0xe0,
     0x6e,0x00,0xa5,0x6e,0xaa,0x9f,0x7a,0xa1,0x66,0x39,
     0x76,0xb7,0x67,0x57,0x3d,0x95,0x61,0x22,0x55,0xc9,
     0x3b,0x4e,0x4f,0xe8,0x66,0x08,0x3d,0x50,0x43,0x3e]
str="uarefirst."
offset_buf=[0,4,32,12,8,24,16,20,28,36]
truekey=[]
for i in str:
    truekey.append(ord(i))
def decrypt(offset,key):
    a=lis[offset]
    b=lis[offset+1]
    c=lis[offset+2]
    d=lis[offset+3]
    flagc=((c+key)&0xff)^b
    flagd=c^d
    flaga=a^d^key
    flagb=((b-key)&0xff)^flaga^key
    lis[offset]=flaga
    lis[offset+1]=flagb
    lis[offset+2]=flagc
    lis[offset+3]=flagd
for i in range(10):
    decrypt(offset_buf[i],truekey[i])
print(bytes(lis).decode('utf-8'))
```

## 参考答案
flag{y0u_C4n_3a51ly_Rem0v3_CoNfu510n-!!}

## 来源
- 作者：NewStar CTF 2024 官方 WriteUp | https://newstar.wiki/wp/2024/week3/reverse/flowering-shrubs.html
