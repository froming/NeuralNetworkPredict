# Dirty_flowers

> 分类：Reverse

## 题目描述
考查花指令。实际考查内容是如何用 `nop` 改汇编指令。按下 Shift+F12 查找字符串即可发现提示：将 `0x4012f1`~`0x401302` 的指令全部改成 `nop` 指令，随后在函数头位置按下 U、P。

## 考察知识点
- 花指令去除（nop）
- IDA 反编译修复
- 异或解密

## 解法
将从 `push eax` 到 `pop eax` 这一段全部 nop 掉，然后在函数头位置按下 U P，再按 F5 即可正确反编译。基本思路是：先判断长度是否为 36，再进行加密，最后比较。

点进 `check` 函数可找到密文，加密函数里也有同样的花指令，再次 nop 掉即可。加密函数非常简单（异或）：

```python
# exp.py
lis = [0x02, 0x05, 0x13, 0x13, 0x02, 0x1e, 0x53, 0x1f, 0x5c, 0x1a, 0x27, 0x43, 0x1d, 0x36, 0x43,
       0x07, 0x26, 0x2d, 0x55, 0x0d, 0x03, 0x1b, 0x1c, 0x2d, 0x02, 0x1c, 0x1c, 0x30, 0x38, 0x32,
       0x55, 0x02, 0x1b, 0x16, 0x54, 0x0f]
str = "dirty_flower"
flag = ""
for i in range(len(lis)):
    lis[i] ^= ord(str[i % len(str)])
    flag += chr(lis[i])
print(flag)
# flag{A5s3mB1y_1s_r3ally_funDAm3nta1}
```

## 参考答案
flag{A5s3mB1y_1s_r3ally_funDAm3nta1}

## 来源
- 作者：NewStar CTF 2024 官方 WriteUp | https://newstar.wiki/wp/2024/week2/reverse/dirty-flowers.html
