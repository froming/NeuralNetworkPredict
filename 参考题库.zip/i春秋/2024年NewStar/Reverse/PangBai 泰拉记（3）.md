# PangBai 泰拉记（3）

> 分类：Reverse

## 题目描述
iOS 安装包（ipa），可执行文件为 Swift 编写。核心逻辑涉及 RC4 与 AES（ECB）加密。通过搜字符串和交叉引用定位关键函数，最终用 CyberChef 解密得到 flag。

## 考察知识点
- iOS/Swift 逆向（ipa 解包、可执行文件反编译）
- 字符串搜索定位关键逻辑
- RC4 加密识别
- AES-ECB 加密识别与解密（CyberChef）

## 解法
用压缩包方式打开 ipa，找到可执行文件 `test`，反编译（全是 Swift）。最简单的做法是搜字符串。搜 `input your flag` 交叉引用到 `contentView`，发现倒置的 `click me`、`correct`、`wrong` 等提示，定位关键函数。

分析几个函数的特征：
- `set256able`（`rc4_init`）和 `rc4_encrypt`：结尾一个异或，结合偏移和数据，符合 RC4。
- AES 部分：ECB 模式、分组加密，大概率是调库的 AES-ECB 加密。

剩下密文和密钥：发现两个奇怪的字符串——第一个是密文，第二个是密钥（`0x10` 恰好 16 位，符合 AES 密钥长度）。

用 CyberChef 进行 AES 解密得到 flag。

## 参考答案
flag{Sw1ft_$0_funny!}

## 来源
- 作者：NewStar CTF 2024 官方 WriteUp | https://newstar.wiki/wp/2024/week5/reverse/pangbai-terra3.html
