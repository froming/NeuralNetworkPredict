# 洞 OVO

> 分类：Reverse

## 题目描述
根据题目信息直接搜索给定版本的 WinRAR，确定漏洞为 WinRAR version 6.22 - Remote Code Execution via ZIP archive（CVE-2023-38831）。题目要求找的函数段大概率是「释放到临时目录」这一段。

## 考察知识点
- CVE-2023-38831（WinRAR 代码执行漏洞）原理
- bindiff 对比新旧版本差异定位修复函数
- 函数调用链溯源

## 解法
漏洞主要流程：获取点击的文件 → 释放到临时目录 → 执行。网上文章一般给出的是 `0x140089948` 这个 `compare` 函数：

```c
// 0x140089948
char __fastcall compare(WCHAR *click_name, WCHAR *deFileName, int a3)
{
  ...
  if ( (_WORD)a3 )
  {
    v7 = -1i64;
    tName_len = -1i64;
    do
      ++tName_len;
    while ( click_name[tName_len] );
    if ( (unsigned int)(unsigned __int16)a3 - 2 > 2 )
    {
      if ( a3 >= 0 )
        v9 = sub_1400AF168(click_name, deFileName);
      else
        v9 = wcsncmp(click_name, deFileName, tName_len);
      if ( !v9 )
      {
        tail = deFileName[tName_len];
        if ( tail == '\\' || tail == '/' || !tail )
          return 1;
      }
      if ( v3 == 1 )
        return 0;
    }
    ...
}
```

向上溯源，结合 bindiff，得到答案 `sub_1400EF508`。调用链如下：

> `sub_1400EF508` -> `sub_140009290` -> `sub_14000A650` -> `sub_1400D6070` -> `0x1400D6478` -> `0x1400D3474` -> `0x1400CEBF4` -> `0x140077054` -> `0x140089948`

参考文章：
- [WinRAR 代码执行漏洞（CVE-2023-38831）的原理分析](https://www.cnblogs.com/GoodFish-/p/17715977.html)

## 参考答案
答案：`sub_1400EF508`（未给出具体 flag 字符串）

## 来源
- 作者：NewStar CTF 2024 官方 WriteUp | https://newstar.wiki/wp/2024/week4/reverse/dongovo.html
