# easygui

> 分类：Reverse

## 题目描述
一个 Windows GUI 程序。`sub_140001490` 是回调函数，包含主要逻辑。先有一个反调试函数（`IsDebuggerPresent`），需 patch 返回值或 nop 掉调用。之后读取文本框字符串进行加密比较。

加密逻辑：首先对所有字符查表代换，之后每四个字节一组整体循环右移 3 位，最后使用 RC4 算法加密（key 为 `easy_GUI`）。

## 考察知识点
- Windows 消息循环机制
- 反调试绕过（IsDebuggerPresent）
- 查表代换（S-box）+ 循环移位 + RC4 组合加密
- 逆向写解密脚本

## 解法
加密算法：S-box 代换 -> 4 字节循环右移 3 位 -> RC4（key `easy_GUI`）。写出解密脚本：

```c
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
void shiftright(unsigned char* input) {
    unsigned char a, b, c, d;
    a = input[0]; b = input[1]; c = input[2]; d = input[3];
    unsigned char a2, b2, c2, d2;
    a2 = (a << 3) | (b >>5 );
    b2 = (b << 3) | (c >> 5);
    c2 = (c << 3) | (d >> 5);
    d2 = (d << 3) | (a >> 5);
    input[0] = a2; input[1] = b2; input[2] = c2; input[3] = d2;
}
void subbytes_reverse(unsigned char* input, int length) {
    char table_reverse[] = { 18, 66, 86, 4, 12, 35, 16, 124, 21, 84, 109, 22, 64, 108, 34, 70, 93, 106, 46, 23, 62, 37, 58, 47, 73, 126, 27, 68, 61, 123, 117, 14, 3, 20, 80, 127, 118, 38, 36, 105, 79, 43, 45, 103, 29, 100, 48, 26, 67, 0, 115, 53, 104, 9, 97, 17, 92, 49, 8, 33, 42, 51, 87, 72, 119, 44, 11, 15, 54, 91, 90, 57, 94, 101, 121, 25, 114, 116, 122, 65, 88, 31, 24, 5, 2, 82, 30, 50, 112, 28, 63, 81, 113, 77, 85, 60, 96, 98, 71, 39, 40, 10, 52, 120, 69, 74, 78, 13, 55, 75, 99, 56, 7, 59, 83, 111, 1, 125, 19, 110, 6, 95, 41, 89, 102, 107, 76, 32 };
    for (int i = 0; i < length; i++) {
        input[i] = table_reverse[input[i]];
    }
}
void rc4_init(unsigned char* s, unsigned char* key, int Len_k)
{
    int i = 0, j = 0;
    char k[256] = { 0 };
    unsigned char tmp = 0;
    for (i = 0; i < 256; i++) {
        s[i] = i;
        k[i] = key[i % Len_k];
    }
    for (i = 0; i < 256; i++) {
        j = (j + s[i] + k[i]) % 256;
        tmp = s[i];
        s[i] = s[j];
        s[j] = tmp;
    }
}
void rc4_crypt(unsigned char* Data, int Len_D, unsigned char* key, int Len_k)
{
    unsigned char s[256];
    rc4_init(s, key, Len_k);
    int i = 0, j = 0, t = 0;
    int k = 0;
    unsigned char tmp;
    for (k = 0; k < Len_D; k++) {
        i = (i + 1) % 256;
        j = (j + s[i]) % 256;
        tmp = s[i];
        s[i] = s[j];
        s[j] = tmp;
        t = (s[i] + s[j]) % 256;
        Data[k] = Data[k] ^ s[t];
    }
}
void decrypt() {
    unsigned char char_array[] = { 0xdf ,0xc7 ,0x4d ,0x14 ,0xc1 ,0xec ,0x08 ,0xe4 ,0x5f ,0x3f ,0x03 ,0xb4 ,0x90 ,0x4a ,0xb9 ,0x8f ,0x8f ,0xfa ,0x71 ,0x43 ,0xc7 ,0xf1 ,0x9d ,0xdd ,0x4f ,0xc0 ,0x12 ,0x44 ,0x5c ,0x9d ,0x88 ,0x36 ,0x2d ,0x16 ,0x1d ,0xed ,0xbc ,0xef ,0xbb ,0x5b ,0x9f ,0x77 ,0xeb ,0x58 };
    unsigned char key[] = "easy_GUI";
    int keylength = 8;
    int length=strlen((const char*)char_array);
    rc4_crypt(char_array, length, key, keylength);
    for (int i = 0; i < length; i += 4) {
        shiftright(char_array + i);
    }
    subbytes_reverse(char_array, length);
    printf("%s",char_array);
}
int main(){
    decrypt();
    return 0;
}
```

`table_reverse` 由原始 table 生成：

```python
table = [49, 116, 84, 32, 3, 83, 120, 112, 58, 53, 101, 66, 4, 107, 31, 67, 6, 55, 0, 118, 33, 8, 11, 19, 82, 75, 47, 26, 89, 44, 86, 81, 127, 59, 14, 5, 38, 21, 37, 99, 100, 122, 60, 41, 65, 42, 18, 23, 46, 57, 87, 61, 102, 51, 68, 108, 111, 71, 22, 113, 95, 28, 20, 90, 12, 79, 1, 48, 27, 104, 15, 98, 63, 24, 105, 109, 126, 93, 106, 40, 34, 91, 85, 114, 9, 94, 2, 62, 80, 123, 70, 69, 56, 16, 72, 121, 96, 54, 97, 110, 45, 73, 124, 43, 52, 39, 17, 125, 13, 10, 119, 115, 88, 92, 76, 50, 77, 30, 36, 64, 103, 74, 78, 29, 7, 117, 25, 35]
table_reverse = [0] * 128
for i in range(128):
    table_reverse[table[i]] = i
print(table_reverse)
```

## 参考答案
flag{GU!_r3v3R5e_3nG1n3er1ng_i5_v3ry_s1mpl3}

## 来源
- 作者：NewStar CTF 2024 官方 WriteUp | https://newstar.wiki/wp/2024/week4/reverse/easygui.html
