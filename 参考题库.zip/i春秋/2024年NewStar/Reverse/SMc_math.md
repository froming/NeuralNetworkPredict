# SMc_math

> 分类：Reverse

## 题目描述
程序使用了 SMC（自修改代码），静态难以直接分析。可在 for 循环结束处下断点（此时解密完成），进入 `encrypt` 函数后在指令开头按 C 键识别指令，再在函数头处按 U 和 P 键，然后 F5 反编译，得到一个七元一次方程组。

## 考察知识点
- SMC（自修改代码）
- 动态调试
- z3 求解线性方程组

## 解法
用 z3 求解七元一次方程组：

```python
from z3 import *
import struct

x1,x2,x3,x4,x5,x6,x7=Ints('x1 x2 x3 x4 x5 x6 x7')
s=Solver()
s.add(5*x1 + 5*x2 + 4*x3 + 6*x4 + x5 + 2*x6 + 9*x7 - 57391174911 == 0)
s.add(9*x1 + 10*x2 + 6*x3 + 3*x4 + 3*x5 + 9*x6 + 4*x7 - 69310186571 == 0)
s.add(4*x1 + 5*x2 + 4*x3 + 4*x4 + 9*x5 + 10*x6 + 3*x7 - 57272085433 == 0)
s.add(5*x1 + 9*x2 + 2*x3 + 4*x4 + 10*x5 + 2*x6 + 9*x7 - 66739156986 == 0)
s.add(7*x1 + 2*x2 + x3 + 9*x4 + 5*x5 + 9*x6 + 3*x7 - 57213499403 == 0)
s.add(6*x1 + 5*x2 + 10*x3 + 6*x4 + 9*x5 + 3*x6 + 8*x7 - 76815456371 == 0)
s.add(x1 + 4*x2 + 4*x3 + 8*x4 + 9*x5 + x6 + 3*x7 - 48137765857 == 0)
s.check()
m=s.model()
x=[0]*7
x[0]=m[x1].as_long()
x[1]=m[x2].as_long()
x[2]=m[x3].as_long()
x[3]=m[x4].as_long()
x[4]=m[x5].as_long()
x[5]=m[x6].as_long()
x[6]=m[x7].as_long()

byte_data = b''.join(struct.pack('<I', value) for value in x)
result_string = byte_data.decode('ascii')
print(result_string)
```

## 参考答案
（未给出）

## 来源
- 作者：NewStar CTF 2024 官方 WriteUp | https://newstar.wiki/wp/2024/week3/reverse/smc-math.html
