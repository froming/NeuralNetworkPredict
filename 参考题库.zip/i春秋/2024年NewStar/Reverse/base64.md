# base64

> 分类：Reverse

## 题目描述
此题目是教大家定位主函数、Base64 的一个常见的魔改方式——换表，以及 CTF 一个编解码工具 CyberChef。程序让你输入一个字符串，然后会判断对错。

## 考察知识点
- 定位主函数（字符串定位）
- Base64 换表（魔改码表）
- CyberChef 使用

## 解法
双击打开程序，可以看到让你输入一个字符串，然后会判断对错。一般来说，`Enter the flag:` 这个字符串会离主逻辑不远，所以我们找到这个字符串的位置就可以定位到主逻辑。

在 IDA 中，按 Shift+F12 调出字符串界面，双击转到对应的 IDA View。双击 `DATA XREF` 右边的地址加偏移，就可以到引用它的地方，按下 F5，即可反编译这段逻辑。

这就是主逻辑了。看到 `=` 结尾的字符串可以想到 Base64（常识）。但是直接解会出乱码。

此处需要大家识别出 Base64 算法的魔改点。标准 Base64 码表是 `ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/`，这里换成了：

```
WHydo3sThiS7ABLElO0k5trange+CZfVIGRvup81NKQbjmPzU4MDc9Y6q2XwFxJ/
```

推荐使用 CyberChef 进行解密：把左边的「From base64」拖到「Recipe」那一栏，然后把「Alphabet」换成上面说的魔改后的码表，「Input」处输入密文，「Output」处就得到 flag 了。当然，编写脚本解码也是可以的。

## 参考答案
（未给出，需通过 CyberChef 换表解码得到）

## 来源
- 作者：NewStar CTF 2024 官方 WriteUp | https://newstar.wiki/wp/2024/week1/reverse/base64.html
