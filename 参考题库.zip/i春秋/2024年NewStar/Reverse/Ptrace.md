# Ptrace

> 分类：Reverse

## 题目描述
`father` 文件使用 `fork` 创建子进程，子进程通过 `execl` 启动 `./son s`，并传递输入的数值 `s` 作为新进程参数。`father` 使用 `ptrace(PTRACE_POKEDATA, addr, addr, 3)` 修改子进程数据。

## 考察知识点
- fork / execl 进程关系
- ptrace 调试（PTRACE_TRACEME / PTRACE_POKEDATA / PTRACE_CONT）
- 循环移位逆变换

## 解法
`son` 文件主函数把 `s` 进行移位操作，然后比对内置数据 `byte_60004020`。`father` 中的 `ptrace(PTRACE_POKEDATA, addr, addr, 3)` 把 `addr`（0x60004040）指向的数据由 `4` 改为 `3`，即把偏移量从 4 改为 3。

所以只需把子进程中的密文按照偏移 3 进行逆变换即可：

```python
enc = [204, 141,  44, 236, 111, 136, 237, 235,  47, 237,
       174, 235,  78, 172,  44, 141, 141,  47, 235, 109,
       205, 237, 238, 235,  14, 142,  78,  44, 108, 172,
       231, 175]
for i in range(len(enc)):
    enc[i] = (enc[i] << 3 | enc[i] >> 5) & 0xff
print(''.join([chr(e) for e in enc]))
```

## 参考答案
flag 未在 writeup 中以文本形式给出（运行脚本得到）。

## 来源
- 作者：NewStar CTF 2024 官方 WriteUp | https://newstar.wiki/wp/2024/week2/reverse/ptrace.html
