# UPX

> 分类：Reverse

## 题目描述
使用 IDA 查看文件，发现主函数很复杂。根据文件名称和提示，与 UPX 相关联（可执行程序文件压缩器，一种压缩壳）。使用 DIE 查看，特征也显示为 UPX。

## 考察知识点
- UPX 脱壳
- RC4 流密码
- `.init_array` 段
- 多种解题方法（脚本解密 / 动态调试 / 异或 / 爆破）

## 解法
### 脱壳
使用 UPX 工具（https://github.com/upx/upx/releases/）直接脱壳，文件体积变大，再使用 IDA 打开，主函数逻辑清晰。

### 分析
`main` 通过 `%22s` 输入，flag 长度为 22 字节，输入 `s` 和 `key` 经过 RC4 函数加密，然后与内置的 `data` 比较。密钥为 `NewStar`，密文 `data` 在 `.init_array` 段被 `before_main` 函数赋值（在 main 之前执行）。

密文（22 字节）：
```
0xC4, 0x60, 0xAF, 0xB9, 0xE3, 0xFF, 0x2E, 0x9B, 0xF5, 0x10,
0x56, 0x51, 0x6E, 0xEE, 0x5F, 0x7D, 0x7D, 0x6E, 0x2B, 0x9C,
0x75, 0xB5
```

### 方法一：套用 RC4 解密
```c
#include <stdio.h>
#include <string.h>

unsigned char sbox[256] = {0};
const unsigned char* key = (const unsigned char*)"NewStar";
unsigned char data[22] = {-60, 96,  -81, -71, -29, -1,  46,  -101, -11,  16,  86,
                          81,  110, -18, 95,  125, 125, 110, 43,   -100, 117, -75};

void swap(unsigned char* a, unsigned char* b) {
    unsigned char tmp = *a;
    *a = *b;
    *b = tmp;
}

void init_sbox(const unsigned char key[]) {
    for (unsigned int i = 0; i < 256; i++) sbox[i] = i;
    unsigned int keyLen = strlen((const char*)key);
    unsigned char Ttable[256] = {0};
    for (int i = 0; i < 256; i++) Ttable[i] = key[i % keyLen];
    for (int j = 0, i = 0; i < 256; i++) {
        j = (j + sbox[i] + Ttable[i]) % 256;
        swap(&sbox[i], &sbox[j]);
    }
}

void RC4(unsigned char* data, unsigned int dataLen, const unsigned char key[]) {
    unsigned char k, i = 0, j = 0, t;
    init_sbox(key);
    for (unsigned int h = 0; h < dataLen; h++) {
        i = (i + 1) % 256;
        j = (j + sbox[i]) % 256;
        swap(&sbox[i], &sbox[j]);
        t = (sbox[i] + sbox[j]) % 256;
        k = sbox[t];
        data[h] ^= k;
    }
}

int main(void) {
    unsigned int dataLen = sizeof(data) / sizeof(data[0]);
    RC4(data, dataLen, key);
    for (unsigned int i = 0; i < dataLen; i++) {
        printf("%c", data[i]);
    }
    return 0;
}
```

### 方法二：动调替换输入为密文
在输入后和比对处下断点，动调时将输入 `s` 替换为密文（使用 IDAPython `patch_byte` 或手动 Change byte），让 RC4 再次加密（即解密），得到 flag。

```python
from ida_bytes import *
enc = [0xC4, 0x60, 0xAF, 0xB9, 0xE3, 0xFF, 0x2E, 0x9B, 0xF5, 0x10,
       0x56, 0x51, 0x6E, 0xEE, 0x5F, 0x7D, 0x7D, 0x6E, 0x2B, 0x9C,
       0x75, 0xB5]
for i in range(22):
    patch_byte(addr + i, enc[i])
print('Done')
```

### 方法三：提取异或值
在 RC4 最后一步异或处下条件断点，提取每次异或的值，再与密文异或得到 flag：

```python
xor_data = [0xa2, 12, 206, 222, 152, 187, 65, 196, 140,
            127, 35, 14, 5, 128, 48, 10, 34, 59, 123, 196, 74, 200]
enc = [0xC4, 0x60, 0xAF, 0xB9, 0xE3, 0xFF, 0x2E, 0x9B, 0xF5, 0x10,
       0x56, 0x51, 0x6E, 0xEE, 0x5F, 0x7D, 0x7D, 0x6E, 0x2B, 0x9C,
       0x75, 0xB5]
for i in range(len(enc)):
    enc[i] ^= xor_data[i]
print(''.join(chr(e) for e in enc))
```

### 方法四：exit 退出码爆破
主函数存在 `exit`，`status` 是循环下标（单字节判断），根据退出码逐字节爆破：

```python
from pwn import *
from tqdm import tqdm
context(arch='amd64', os='linux', log_level="error")

str = string.printable
flag = b"a"*22
tmp = 0

for i in tqdm(range(len(flag))):
    for j in str.encode():
        p = process("./upx")
        new_flag = flag[:i] + chr(j).encode() + flag[i+1:]
        p.sendafter(b"input your flag:\n", new_flag)
        p.wait()
        exit_code = p.poll()
        p.close()
        if exit_code > tmp or (exit_code == 0 and tmp != 0):
            flag = new_flag
            tmp = exit_code
            break
print(f"[*] Successfully get the flag : {flag}")
```

## 参考答案
flag 未在 writeup 中以文本形式给出（见截图，可运行脚本得到）。

## 来源
- 作者：NewStar CTF 2024 官方 WriteUp | https://newstar.wiki/wp/2024/week2/reverse/upx.html
