# Maze_Rust

> 分类：Pwn

## 题目描述
一道 Rust 编写的 Pwn 题，进入程序是一个简单迷宫，解出迷宫后会让输入，随便试试发现这是一个 `system()`，可以执行输入的内容。

## 考察知识点
- Rust 二进制逆向（IDA 8.3+）
- 迷宫求解（BFS/DFS）
- 后门/隐藏菜单发现（菜单只显示 1、3，跳过 2）
- 字符串比较提取（xmm 寄存器）

## 解法

### 解法一：黑盒解迷宫
直接当黑盒打，解出迷宫后到达 `system()`。示例脚本（GPT 生成）：

```python
#!/usr/bin/env python3
from pwn import *

context(log_level='debug', arch='amd64', os='linux')
context.terminal = ["tmux", "splitw", "-h"]
uu64 = lambda x: u64(x.ljust(8, b'\x00'))
s = lambda x: p.send(x)
sa = lambda x, y: p.sendafter(x, y)
sl = lambda x: p.sendline(x)
sla = lambda x, y: p.sendlineafter(x, y)
r = lambda x: p.recv(x)
ru = lambda x: p.recvuntil(x)

p = process('./Maze_Rust')
elf = ELF('./Maze_Rust')

sla(b'3: Handle The Maze', b'3')
p.recvline()

maze = []
while True:
    line = p.recvline().decode().strip()
    if "quit" in line:
        break
    maze.append(line)

DIRECTIONS = [(-1, 0, 'W'), (1, 0, 'S'), (0, -1, 'A'), (0, 1, 'D')]

def find_positions(maze):
    start = end = None
    for i, row in enumerate(maze):
        if 'P' in row:
            start = (i, row.index('P'))
        if 'G' in row:
            end = (i, row.index('G'))
    return start, end

def can_move(maze, x, y):
    return 0 <= x < len(maze) and 0 <= y < len(maze[0]) and maze[x][y] in ' PG'

def dfs(maze, x, y, end, path, visited, direction_path):
    if (x, y) == end:
        return True
    visited.add((x, y))
    for dx, dy, direction in DIRECTIONS:
        nx, ny = x + dx, y + dy
        if can_move(maze, nx, ny) and (nx, ny) not in visited:
            path.append((nx, ny))
            direction_path.append(direction)
            if dfs(maze, nx, ny, end, path, visited, direction_path):
                return True
            path.pop()
            direction_path.pop()
    return False

def solve_maze(maze):
    start, end = find_positions(maze)
    path = [start]
    direction_path = []
    visited = set()
    if dfs(maze, start[0], start[1], end, path, visited, direction_path):
        return direction_path
    else:
        return None

path = solve_maze(maze)
path_ = "".join(path).lower()
sl(path_)
p.interactive()
```

### 解法二：逆向找后门
菜单只出现 1、3，唯独跳过 2。输入 `2` 得到提示，需要输入数字 `0721`（对绫地宁宁的理解）。

Rust 编译的程序主函数在 `Maze_Rust::main` 中。通过逆向找到程序对 DEBUG 全局变量的修改，X 键查交叉引用找到 Backdoor 的 Stage2。最终发现输入的字符串与 `v20` 做 `cmp` 比较（Rust 用 xmm 寄存器提升字符串比较效率）。

提取两处字符（Shift+E），合起来是 `I'm the best pwner!!!`，输入即可 Get Shell。

## 参考答案
（未给出）

## 来源
- 作者：NewStar CTF 2024 官方 WriteUp | https://newstar.wiki/wp/2024/week4/pwn/maze_rust.html
