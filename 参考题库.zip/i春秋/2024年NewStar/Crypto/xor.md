# xor

> 分类：Crypto

## 题目描述
最简单的签到，但对完完全全零基础的同学来说，这道题涉及的知识点可能还不少，我们看题：

```python
from pwn import xor
from Crypto.Util.number import bytes_to_long

key = b'New_Star_CTF'
flag='flag{*******************}'

m1 = bytes_to_long(bytes(flag[:13], encoding='utf-8'))
m2 = flag[13:]

c1 = m1 ^ bytes_to_long(key)
c2 = xor(key, m2)
print('c1=',c1)
print('c2=',c2)
```

## 考察知识点
- pwntools / pycryptodome 库
- Python3 中 bytes 与 str 的区别
- bytes_to_long / long_to_bytes
- 异或（XOR）运算及其自反性质

## 解法
首先使用两个 Python 库：

```bash
pip install pwntools
pip install pycryptodome
```

`bytes_to_long` 函数将 `bytes` 类型转换为数字。例如：

```python
text=b'NewStar'
print(bytes_to_long(text))     # 22066611359080818
print(hex(bytes_to_long(text))) # 0x4e657753746172
```

本题重点考查**异或（XOR）**，规则是：当两个输入位不同时输出为 `1`，相同时输出为 `0`。当两个数异或之后，异或的结果与其中一个数再异或即可得到剩下的一个数字。

已知 `key` 的话，利用异或的性质，再异或 1 次即可获得 flag：

```python
from pwn import xor
from Crypto.Util.number import long_to_bytes,bytes_to_long

key = b'New_Star_CTF'

c1 = 8091799978721254458294926060841
c2 = b';:\x1c1<\x03>*\x10\x11u;'

m1 = c1 ^ bytes_to_long(key)
m2 = xor(key, c2)

flag = long_to_bytes(m1) + m2
print(flag)
# flag{0ops!_you_know_XOR!}
```

## 参考答案
flag{0ops!_you_know_XOR!}

## 来源
- 作者：NewStar CTF 2024 官方 WriteUp | https://newstar.wiki/wp/2024/week1/crypto/xor.html
