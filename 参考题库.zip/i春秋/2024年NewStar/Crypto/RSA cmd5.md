# RSA? cmd5!

> 分类：Crypto

## 题目描述
RSA 签名题。发送方用不安全的哈希算法（MD5）计算消息摘要，可能被窃密者利用得到明文。已知 `c`、`s`（签名）、`n`、`e`，其中签名 `s = (bytes_to_long(md5(m).encode()))^d mod n`。

## 考察知识点
- RSA 签名原理（`s = hm1^d mod n`，`s^e mod n` 还原 hm1）
- MD5 摘要在线查询（cmd5.com）
- 结合题目信息拼接 flag

## 解法
```python
def get_MD5(m0):
    md5_object = hashlib.md5(m0.encode())
    md5_result = md5_object.hexdigest()
    return md5_result

def get_s(m0, d0, n0):
    hm0 = get_MD5(m0)
    hm1 = bytes_to_long(hm0.encode())
    s0 = pow(hm1, d0, n0)
    return s0
```
有 `s = hm1^d mod n`，由于 `e·d ≡ 1 (mod φ)`，`s^e ≡ hm1 (mod n)`，即可还原 hm1。再到 cmd5.com 查询该 MD5 得到 `m = adm0n12`。

EXP：
```python
from Crypto.Util.number import *
from gmpy2 import *

s = 7270513885194445005322518350289419893608325839878215682947885852347014936106128407554345668066935779849573932055239642406851308417046145495939362638652861562381316163080735160853285303356461796079298817982074998651099375222398758502559657988024308504098238446594559605603104540325738607539729848183025647146
e = 65537
n = 118167767283404647838357773955032661171703847685597271116789633496884884504237966404005641401909577369476550625894333528860763752286157264860218284704704444830864099870199623580368198306940575628872723737071517733553706154898255520538220530675603850372384339470410704813339357637359108745206967929184573003377

def get_flag(m0):
    import hashlib
    flag = 'flag{th1s_1s_my_k3y:' + m0 + '0x' + hashlib.sha256(m0.encode()).hexdigest() + '}'
    print(flag)

hm_int = pow(s, e, n)
hm_str = long_to_bytes(hm_int).decode()
print(hm_str)  # 86133884de98baada58a8c4de66e15b8

m = 'adm0n12'
get_flag(m)
```

## 参考答案
flag{th1s_1s_my_k3y:adm0n120xbfab06114aa460b85135659e359fe443f9d91950ca95cbb2cbd6f88453e2b08b}

## 来源
- 作者：NewStar CTF 2024 官方 WriteUp | https://newstar.wiki/wp/2024/week5/crypto/rsa_cmd5.html
