# Since you konw something

> 分类：Crypto

## 题目描述
题目代码：

```python
from pwn import xor
# The Python pwntools library has a convenient xor() function that can XOR together data of different types and lengths
from Crypto.Util.number import bytes_to_long

key = ?? # extremely short
FLAG = 'flag{????????}'
c = bytes_to_long(xor(FLAG,key))

print("c={}".format(c))

'''
c=218950457292639210021937048771508243745941011391746420225459726647571
'''
```

## 考察知识点
- 异或（xor）
- 已知明文攻击（利用 flag 格式头）

## 解法
flag 格式明确以 `flag{` 开头，key 极短，直接把 `c` 和 `flag{` 异或看看：

```python
from pwn import xor
from Crypto.Util.number import long_to_bytes

flag_head = 'flag{'
c=218950457292639210021937048771508243745941011391746420225459726647571
guess_key = xor(long_to_bytes(c), flag_head)
print(guess_key)
# b"nsnsnL2gVcf/xKa}1MQ8z@m'aa1`t"
```

`key` 前一部分是重复的 `ns`，可猜 key 就是 `ns`：

```python
from pwn import xor
from Crypto.Util.number import long_to_bytes
c=218950457292639210021937048771508243745941011391746420225459726647571
key='ns'
flag = xor(long_to_bytes(c),key)
print(flag)
# b'flag{Y0u_kn0w_th3_X0r_b3tt3r}'
```

## 参考答案
flag{Y0u_kn0w_th3_X0r_b3tt3r}

## 来源
- 作者：NewStar CTF 2024 官方 WriteUp | https://newstar.wiki/wp/2024/week2/crypto/since-you-know-something.html
