# I wanna be a Rust Master

> 分类：Misc

## 题目描述
Rust 代码沙箱题。检测分两部分：明文检测（`contains`）和基于 syn/quote 库检测 TokenStream。检测了 `std`、`unsafe`、`flag` 等。需要在不使用标准库宏的情况下读取并输出 `/flag`。

## 考察知识点
- Rust 宏（`include_str!` / `include_bytes!` / `concat!`）
- syn/quote 库对宏内 TokenStream 不检测的特性
- 用报错（`Option::expect`）带出输出

## 解法
syn 库在解析宏时直接返回 TokenStream（不解析宏内部），因此可以把恶意代码塞进宏里绕过基于 syn 的检测。但明文匹配检测（`contains("std")`、`contains("flag")` 等）仍然生效。

`include_str!` 会在编译期读取文件内容作为字符串编译，但 `include_str!("/flag")` 中 `flag` 被明文检测；且 `include_str!` 需要字符串字面量，不能用变量。使用 `concat!` 在编译期拼接字符串字面量绕过：

```rust
let f = include_str!(concat!("/fl", "ag"));
```

输出方面，`println!` 等宏都被 ban 了，也无法直接访问 `std::io`。利用报错带出输出——用 `Option::None.expect(...)`，让报错信息包含我们想输出的内容：

```rust
fn main() {
    Option::<()>::None.expect(include_str!(concat!("/fl","ag")));
}
```

## 参考答案
（未给出）

## 来源
- 作者：NewStar CTF 2024 官方 WriteUp | https://newstar.wiki/wp/2024/week5/misc/rust-master.html
