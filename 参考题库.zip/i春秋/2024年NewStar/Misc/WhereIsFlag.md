# WhereIsFlag

> 分类：Misc

## 题目描述
在后续，大家会接触到很多拿到服务器 Shell 后找到 flag 的场景。本题主要考查了这部分知识，在各个常见位置设置了或真或假的 flag。并且介绍了 `cd`、`ls`、`cat` 等常用命令的基础用法。

其实这题的后端是个 Python 程序（Virtual Linux）。

## 考察知识点
- Linux 基础命令（cd / ls / cat）
- 找到 flag 的常见位置
- /proc 虚拟文件系统

## 解法
真正的 flag 在 `/proc/self/environ` 文件（可用于获取当前进程的环境变量）内，只要执行下面的命令就能拿到 flag：

```shell
cat /proc/self/environ
```

`proc` 目录是对当前操作系统进程的虚拟映射，在许多攻击场景中都有妙用。

## 参考答案
（未给出，需通过 `cat /proc/self/environ` 获取）

## 来源
- 作者：NewStar CTF 2024 官方 WriteUp | https://newstar.wiki/wp/2024/week1/misc/whereisflag.html
