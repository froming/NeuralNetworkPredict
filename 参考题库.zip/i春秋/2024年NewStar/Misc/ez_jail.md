# ez_jail

> 分类：Misc

## 题目描述
原意只考查 `{}` 在 C++ 里的（宏）替代运算符这一知识点。`check` 函数：

```python
def cpp_code_checker(code):
    if "#include" in code:
        return False, "Code is not allowed to include libraries"
    if "#define" in code:
        return False, "Code is not allowed to use macros"
    if "{" in code or "}" in code:
        return (
            False,
            "Code is not allowed to use `{` or `}`,but it needs to be a single function",
        )
    if len(code) > 100:
        return False, "Code is too long"
    return True, "Code is valid"
```

## 考察知识点
- C++ 替代运算符（digraph `<% %>`）
- 预处理宏绕过（`#` 后加空格）
- 空函数 / 全局变量执行输出

## 解法
预期解：使用 C++ 替代运算符 `<% %>` 替换 `{}`：

```cpp
void user_code()<%write(1, "Hello, World!\n", 14);%>
```

非预期解 1（`#` 后加空格绕过过滤，宏定义预处理）：
```cpp
# define user_code() write(STDOUT_FILENO, "Hello, World!", 13);
```

非预期解 2（把 `user_code()` 变成空函数，通过全局变量接收输出函数的返回值）：
```cpp
int a=puts("Hello, World!");
int (*user_code)()=rand;
```

非预期解 3：
```cpp
int x = (printf("Hello, World!\n"), 0);
using user_code = void(*)();
```

## 参考答案
（未给出）

## 来源
- 作者：NewStar CTF 2024 官方 WriteUp | https://newstar.wiki/wp/2024/week3/misc/ez_jail.html
