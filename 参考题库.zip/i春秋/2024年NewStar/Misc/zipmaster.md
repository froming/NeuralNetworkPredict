# zipmaster

> 分类：Misc

## 题目描述
多阶段 zip 题目：
1. 加密压缩包内有 4 个长度仅为 3 字节的相同文件，用 CRC32 爆破得到密码。
2. 解压出下一个压缩包，使用 ZipCrypto 明文攻击（bkcrack）恢复密钥。
3. 解压出 `flag.zip`（压缩包炸弹），提取 Base64 解密得到新压缩包。
4. 末尾 hint 给出密码的 Base64（`f4tj4oGMRuI=`），但密码是不可见字符，写脚本解压得到 flag。

## 考察知识点
- ZIP 结构分析
- CRC32 爆破
- ZipCrypto 明文攻击（bkcrack）
- 压缩包炸弹
- Base64 解码与不可见字符密码

## 解法

### 1. CRC32 爆破
4 个 3 字节文件，用 CRC 值爆破内容：

```python
import binascii
import string

def crack_crc():
    print('-------------Start Crack CRC-------------')
    crc_list = [0x35f321cd, 0xa0bb977c, 0x4eb5f650, 0x3c90238]
    comment = ''
    chars = string.printable
    for crc_value in crc_list:
        for char1 in chars:
            for char2 in chars:
                for char3 in chars:
                    res_char = char1 + char2 + char3
                    char_crc = binascii.crc32(res_char.encode())
                    calc_crc = char_crc & 0xffffffff
                    if calc_crc == crc_value:
                        print('[+] {}: {}'.format(hex(crc_value),res_char))
                        comment += res_char
    print('-----------CRC Crack Completed-----------')
    print('Result: {}'.format(comment))

if __name__ == '__main__':
    crack_crc()
```

得到密码 `this_is_key!`，解压 `3077.zip` 得到 `114514.zip`（无密码），再解压得到 `0721.zip` 和 `hint.txt`（内容："看起来好像和某个文件是一样的欸"）。

### 2. ZipCrypto 明文攻击
`0721.zip` 中有一个原始大小与外面 `hint.zip` 完全一样的文件，加密算法为 ZipCrypto，用 bkcrack 明文攻击恢复密钥。注意 `-c` 参数写破解文件中的明文文件绝对路径（压缩包内还有一层 `0721` 文件夹，路径写 `0721/hint.txt`）。

爆破出密钥后构造弱密码 `123456` 的压缩包，解压 `0721.zip` 得到 `flag.zip`。

### 3. 压缩包炸弹
`flag.zip` 是压缩包炸弹，用 010 Editor 查看结构，发现很多 Base64 字符串，提取后解密（CyberChef）得到新压缩包；把 16 进制内容存为新压缩包，末尾有 hint（`f4tj4oGMRuI=`）。

### 4. 不可见字符密码
`f4tj4oGMRuI=` 是密码的 Base64，解密后是不可见字符，用脚本解压：

```python
import base64
import pyzipper

target_zip = '1.zip'
outfile = './solved'

pwd = base64.b64decode(b'f4tj4oGMRuI=')
with pyzipper.AESZipFile(target_zip, 'r') as f:
    f.pwd = pwd
    f.extractall(outfile)
```

解压后得到 Z1 文件，记事本打开即 flag。

## 参考答案
flag{ecebbd61-2bb9-4eda-b4ca-f24b895be2e3}

## 来源
- 作者：NewStar CTF 2024 官方 WriteUp | https://newstar.wiki/wp/2024/week5/misc/zipmaster.html
