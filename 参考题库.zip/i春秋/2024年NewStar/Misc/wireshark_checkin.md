# wireshark_checkin

> 分类：Misc

## 题目描述
题目给出一堆数据包，需要快速定位到 flag。

## 考察知识点
- Wireshark 流量分析
- HTTP 协议
- TCP 过滤
- TCP 三次握手 / 四次挥手

## 解法
标绿色的是 HTTP 协议相关条目，点击 `GET /reverse.c` 条目，看 Wireshark 界面左下角写着 `Port: 7070`（HTTP 服务器的开放端口）。

在搜索框输入 `tcp.port == 7070` 快速过滤所有有关此端口的 TCP 报文（HTTP 建立在 TCP 之上）。

只想看 `GET /flag.txt` 的请求流程：找到 `Src port: 33751`，过滤器写 `tcp.port == 33751`（同一 HTTP 请求和响应的客户端用同一端口），即可只看 flag.txt 的这次请求和响应的所有过程（3 次握手、四次挥手）。

flag 在响应报文的右下角（HTTP/1.1 内容中）。

## 参考答案
flag 未在 writeup 中以文本形式给出（见流量截图右下角）。

## 来源
- 作者：NewStar CTF 2024 官方 WriteUp | https://newstar.wiki/wp/2024/week2/misc/wireshark-checkin.html
