# ezblockchain

> 分类：Misc

## 题目描述
一道区块链题。需要调用合约的 `unlock` 函数，传入 `re@1lY_eA3y_Bl0ckCh@1n` 并发送 0.0721 个 eth，使 `isSolved` 变为 true 后获取 flag。

## 考察知识点
- MetaMask 网络配置与交互
- Remix 编辑器部署/加载合约
- 合约函数调用与转账

## 解法
1. 浏览器安装 MetaMask，添加网络（网络符号、货币符号随意）。
2. 用账号地址在 faucet 获取测试代币。
3. `nc` 获得合约部署账号，用 MetaMask 向其转账。
4. 交互部署合约，获得合约地址和代码。
5. 将代码复制进 [Remix](https://remix.ethereum.org)，编译后切换到「部署 & 发交易」，环境选 Injected Provider，选择有 eth 的账户，加载 nc 获得的合约地址。
6. 阅读合约代码，调用 `unlock` 函数：传入 `re@1lY_eA3y_Bl0ckCh@1n` 并发送 0.0721 eth。由于无法填小数，将 0.0721 eth 转为 `72100000` Gwei，在 unlock 填入参数后点击交易。
7. 交易确认后点击 `isSolved`，变为 `true`，再 `nc` 交互得到 flag。

## 参考答案
（未给出）

## 来源
- 作者：NewStar CTF 2024 官方 WriteUp | https://newstar.wiki/wp/2024/week4/misc/ezblockchain.html
