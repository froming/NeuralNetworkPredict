# PlzLoveMe

> 分类：Misc

## 题目描述

音频采样数据 + LCD 图片 + ARM 二进制（AXF）综合题。音频是 PCM 采样，LCD 显示特殊字体歌词，AXF 文件包含 ARM 符号信息用于还原 flag。

## 考察知识点

- PCM 音频播放与听歌识曲
- 特殊字体对照（LVDC-Secret-Passage 字体）
- ARM 二进制逆向（IDA）
- UART 串口回调异或解密

## 解法

1. **音频**：音频采样数据一般是 PCM，根据采样率用[线上网站](https://pcm.stanwind.com/)播放。听歌识曲可知歌曲是 `world.execute(me);`。

2. **LCD 图片对照歌词**：播放到 03:01 的歌词对照 LCD 图片。LCD 上显示的是歌词（第一行是 `Question me`，后面有 `LO-O-OVE`），符号是特殊字体（LVDC-Secret-Passage 字体）。对照歌词可得符号对应关系。

3. **提取符号**：歌词倒数第四排是 `flag:`，后三排对照得到：
   - `fhwdLd`
   - `mnwdOnV`
   - `mnwdOnV`

4. **AXF 文件逆向**：剩下一个 AXF 文件（包含 ARM 符号信息的二进制，用 IDA 打开）。`file SD_MP3_RC.axf` 输出：`ELF 32-bit LSB executable, ARM, EABI5, statically linked, with debug_info, not stripped`。IDA32 函数列表搜索 `UART`，找到 `RxCpltCallback`（串口回调），F5 伪代码：

```c
void __fastcall HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
  // ...
  UART1_Rx_Buf[UART1_Rx_cnt] = UART1_temp[0] ^ 1;  // 异或 0x1
  // ...
}
```

只有个异或 `0x1`。用 [CyberChef XOR 0x01](https://gchq.github.io/CyberChef/#recipe=XOR(%7B'option':'Hex','string':'01'%7D,'Standard',false)&input=Zmh3ZExkbW53ZE9uVm1ud2RPblY) 解密 `fhwdLdmnwdOnVmnwdOnV`，得到 `giveMeloveNoWloveNoW`。

5. 包上 `flag{}` 提交。

## 参考答案

`flag{giveMeloveNoWloveNoW}`

## 来源

- 作者：NewStar CTF 2024 官方 WriteUp | https://newstar.wiki/wp/2024/week5/misc/plzloveme.html
