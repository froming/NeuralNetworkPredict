# Alt

> 分类：Misc

## 题目描述
一道键盘流量解析题。数据为 usbhid 格式。flag 含有非 ASCII 字符且语义较通顺。

## 考察知识点
- USB 键盘流量分析（tshark 提取）
- 键码对照表（含 KeyPad 区，见 HID Usage Tables 文档）
- Alt + 数字键输入 Unicode 字符
- backspace 键的处理

## 解法
1. 用 tshark 提取 USB 数据：

```bash
tshark -r keyboard.pcapng -T fields -e usbhid.data > usbdata.txt
```

2. 用文本编辑器批量替换空行。示例数据：

```
0400000000000000
0400590000000000
0400000000000000
0400620000000000
...
```

3. 第一字节代表控制键，第二字节保留为 `0x00`，第三到八字节是敲击的键。键码对照表见 [Universal Serial Bus (USB) HID Usage Tables](https://www.usb.org/sites/default/files/documents/hut1_12v2.pdf) 第 55 页。
4. 第一字节的 `0x04` 表示按着 Alt 键。整个击键流程：保持 Alt 按下，按下几个数字键，松开 Alt——这是按 Unicode 码值输入字符。
5. 对 backspace 键的疑惑：直接忽略退格键，得到正确结果（第一段非 ASCII 字符是「键盘流量」）。可直接用 Python `chr` 函数将十进制码值转换为字符。

## 参考答案
（未给出）

## 来源
- 作者：NewStar CTF 2024 官方 WriteUp | https://newstar.wiki/wp/2024/week4/misc/alt.html
