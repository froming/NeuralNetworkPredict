# AmazingGame

> 分类：Misc

## 题目描述
安卓私有目录位于 `/data/user/0/<包名>` 下，`shared_prefs` 一般用来存放软件配置数据。修改文件即可更改已通过的关卡数据。

## 考察知识点
- Android 私有目录 / shared_prefs
- adb 修改配置文件
- run-as 命令

## 解法
通过第一关后关掉游戏（这点很重要）。ADB 连接手机执行：

```shell
adb shell
run-as com.pangbai.projectm
cd shared_prefs
cat net.osaris.turbofly.JumpyBall.xml
```

得到：
```xml
<?xml version='1.0' encoding='utf-8' standalone='yes' ?>
<map>
    <boolean name="cockpitView" value="true" />
    <int name="unlockedsolotracks" value="2" />
    <int name="unlockedtracks" value="2" />
    <int name="best0m0" value="130" />
    <int name="unlockedships" value="1" />
    <int name="userid" value="9705893" />
</map>
```

软件有 23 个关卡，把关卡解锁数改为 23：

```shell
sed -i 's/2/23/g' net.osaris.turbofly.JumpyBall.xml
```

打开游戏发现关卡全部解锁，随便游玩 23 关，等游戏结束即可获得 flag。

## 参考答案
（未给出）

## 来源
- 作者：NewStar CTF 2024 官方 WriteUp | https://newstar.wiki/wp/2024/week3/misc/amazinggame.html
