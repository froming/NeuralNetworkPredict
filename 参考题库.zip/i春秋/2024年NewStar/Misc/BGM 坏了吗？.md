# BGM 坏了吗？

> 分类：Misc

## 题目描述
用 Audacity 打开音频，结尾处右声道有信息，左声道是噪音。根据题目描述是拨号音（DTMF）。

## 考察知识点
- 音频隐写
- DTMF 按键音识别

## 解法
1. 用 Audacity 打开音频，发现结尾处右声道有信息，左声道是噪音。
2. 选择「分离立体音到单声道 » 关闭左声道 » 导出」删除噪音。
3. 用 DTMF 解码网站 [DTMF Decoder](https://dtmf.netlify.app/) 解码。
4. 包上 `flag{}` 即可。

## 参考答案
（未给出，DTMF 解码结果见截图）

## 来源
- 作者：NewStar CTF 2024 官方 WriteUp | https://newstar.wiki/wp/2024/week3/misc/bgm-broken.html
