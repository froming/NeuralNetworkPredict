# pleasingMusic

> 分类：Misc

## 题目描述
题目描述中提到：

> 一首歌可以好听到**正反都好听**

## 考察知识点
- 音频反向处理（倒放）
- 摩斯电码（Morse Code）

## 解法
根据提示（其实也能听出来后半段音乐是倒放出来的）将音频进行反向处理实现**倒放**，再解析其中的摩斯电码（Morse Code）。

可以手动翻译摩斯电码表，也可以使用[在线解码](https://www.lddgo.net/encrypt/morse)。

## 参考答案
（未给出，需倒放音频后解析摩斯电码）

## 来源
- 作者：NewStar CTF 2024 官方 WriteUp | https://newstar.wiki/wp/2024/week1/misc/pleasingmusic.html
