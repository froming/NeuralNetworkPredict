# wireshark_secret

> 分类：Misc

## 题目描述
学会怎么从一个 HTTP 响应的流量中导出图片。

## 考察知识点
- Wireshark 流量分析
- 从 HTTP 响应导出图片

## 解法
点击 `secret.png` 数据包，左下角找到 File Data 字段，右键点击「导出分组字节流」，将文件保存为 PNG，即可打开图片得到 flag。

## 参考答案
flag 未在 writeup 中以文本形式给出（见图片截图）。

## 来源
- 作者：NewStar CTF 2024 官方 WriteUp | https://newstar.wiki/wp/2024/week2/misc/wireshark-secret.html
