# phpstudy

> 分类：Web

## 题目描述

小皮面板（phpstudy）类题目，NKCTF 2023 - xiaopi 原题。首页 404，通过代码分析在 WebServer.php 找到请求头判断逻辑。

## 考察知识点

- 请求头绕过（X-Requested-With）
- 堆叠注入（SQL 注入）
- 后台 RCE（计划任务）

## 解法

1. 通过代码分析，在 WebServer.php 里有判断 `HTTP_X_REQUESTED_WITH`，如果等于 `XMLHttpRequest` 则返回 true。构造请求头 `X-Requested-With: XMLHttpRequest` 进入后台登录界面。

2. 通过堆叠注入修改后台用户密码（密码是五次 MD5 加密的特殊值）：

```
admin';UPDATE ADMINS set PASSWORD = '17e7007726eeb36a85a5573e6a04bc1b';--
```

（或用 `admin';UPDATE ADMINS set PASSWORD = '202cb962ac59075b964b07152d234b70';--`，即 `123` 的 MD5）

3. 重启服务后用 `admin/123` 登录后台。

4. 两种方式拿 flag：
   - 通过计划任务反弹 shell
   - 通过修改设置/文件管理直接查看 flag（文件管理一直退到根目录）

## 参考答案

（flag 通过后台计划任务 RCE 或文件管理读取）

## 来源

- 作者：Ten（Ahisec） | https://cn-sec.com/archives/1802791.html
- 作者：Lazzaro | https://lazzzaro.github.io/2023/05/19/match-2023%E5%B9%B4%E6%98%A5%E7%A7%8B%E6%9D%AF%E7%BD%91%E7%BB%9C%E5%AE%89%E5%85%A8%E8%81%94%E8%B5%9B-%E6%98%A5%E5%AD%A3%E8%B5%9B/index.html
