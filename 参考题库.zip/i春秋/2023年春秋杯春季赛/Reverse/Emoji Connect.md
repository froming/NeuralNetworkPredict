# Emoji Connect

> 分类：Reverse

## 题目描述

连连看游戏（Unity/ILSpy 分析），内含 48×48 emoji 表情矩阵，通过选中相同 emoji 触发 number 数组运算，最终输出 flag。

## 考察知识点

- .NET 逆向（ILSpy）
- 游戏逻辑模拟

## 解法

用 ILSpy 分析 Game 模块，内含 48×48 emoji 表情矩阵。关键逻辑：

```csharp
private int[] number = new int[48] { 25588, 31114, ... };

private void Select_Unit(Range Target) {
    // 选中两个相同 emoji 时：
    int num = (array[0] - 55296) * 1024 + array[1] - 56320 + 65536 - 128512;
    number[num] -= (list[1].Row - 1) * (list[1].Column - 1);
    number[num] -= (list[0].Row - 1) * (list[0].Column - 1);
    // ...
}

private void check() {
    // 全部消除后：MessageBox.Show(Encoding.ASCII.GetString(number.Select(n => (byte)n)));
}
```

每选中相同的两个 emoji，按 emoji 对应的 array 值，将 number 数组对应下标的值减去两个 emoji 所在行列号之积。写脚本模拟连连看过程，最终 number 数组转 ASCII 得到 flag。

## 参考答案

（flag 通过模拟连连看游戏逻辑后 number 数组转 ASCII 得到）

## 来源

- 作者：Lazzaro | https://lazzzaro.github.io/2023/05/19/match-2023%E5%B9%B4%E6%98%A5%E7%A7%8B%E6%9D%AF%E7%BD%91%E7%BB%9C%E5%AE%89%E5%85%A8%E8%81%94%E8%B5%9B-%E6%98%A5%E5%AD%A3%E8%B5%9B/index.html
