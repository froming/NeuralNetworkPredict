# BWBA

> 分类：Reverse

## 题目描述

一位 85 岁大爷写的 C++ 程序，`encrypt()` 函数识别为离散余弦变换（DCT）算法，需写逆算法解密。

## 考察知识点

- 离散余弦变换（DCT）识别
- IDCT 逆变换

## 解法

分析 `encrypt()` 函数，识别为离散余弦变换（DCT）算法（`cos((j+0.5)*pi*i/n)` 和 `sqrt(2/n)`、`sqrt(1/n)` 系数）。写逆算法（IDCT）解密：

```python
import numpy as np

c = [float(k) for k in "370.75 234.362 ...".split(' ')]

def idct(signal):
    n = len(signal)
    x = np.zeros(n)
    for i in range(n):
        y = 0
        for j in range(n):
            if j == 0:
                y += signal[j] / np.sqrt(n)
            else:
                y += signal[j] * np.sqrt(2/n) * np.cos((np.pi*(2*i+1)*j)/(2*n))
        x[i] = y
    return np.round(x).tolist()

out = idct(c)
out = [int(k) for k in out]
print(bytes(out))
```

## 参考答案

`flag{9ab488a7-5b11-1b15-04f2-c230704ecf72}`

## 来源

- 作者：Lazzaro | https://lazzzaro.github.io/2023/05/19/match-2023%E5%B9%B4%E6%98%A5%E7%A7%8B%E6%9D%AF%E7%BD%91%E7%BB%9C%E5%AE%89%E5%85%A8%E8%81%94%E8%B5%9B-%E6%98%A5%E5%AD%A3%E8%B5%9B/index.html
