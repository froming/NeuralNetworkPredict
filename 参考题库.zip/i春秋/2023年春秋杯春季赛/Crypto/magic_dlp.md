# magic_dlp

> 分类：Crypto

## 题目描述

超椭圆曲线（hyperelliptic curve）DLP 问题。给 p、D1、D2（Jacobian 上的点）和密文，需恢复 r 解 AES。

## 考察知识点

- 超椭圆曲线（HyperellipticCurve）
- 恢复曲线 f（CRT + LLL/RLWE）
- BSGS 算法解 DLP

## 解法

1. 首先恢复 f（g=3，f 是 7 次多项式，系数 128 位），用 CRT 得到 f：

```python
rems = [D1[1]^2, D2[1]^2]
mods = [D1[0], D2[0]]
ff = crt(rems, mods)
```

2. p 为 256 位，f 系数 128 位，用类似 RLWE 的方法 LLL 算出 f：

```python
M = matrix(ZZ, [vector(ff.padded_list(8)), vector(L.padded_list(8)),
                vector((L*x).padded_list(8)), *list(matrix.identity(8)*p)])
M = M.augment(vector([1] + [0]*(2+8)))
M[:, -1] *= 2**128
M = M.LLL()
# 找到 f
```

3. r 不到 40 位，用 BSGS 求解 DLP（`D2 = r * D1`）：

```python
M = 2**20
lhs = {}
T = D2
for v in range(M):
    lhs[T] = v
    T = T - D1
MD1 = M * D1
T = 0 * MD1
for u in range(M):
    if T in lhs:
        v = lhs[T]
        r = u*M + v
        break
    T = T + MD1
```

4. `key = sha256(str(r)).digest()` 解 AES。

## 参考答案

`flag{72825d3f-74f0-0a0e-ba1c-895eee99dc29}`

## 来源

- 作者：Lazzaro | https://lazzzaro.github.io/2023/05/19/match-2023%E5%B9%B4%E6%98%A5%E7%A7%8B%E6%9D%AF%E7%BD%91%E7%BB%9C%E5%AE%89%E5%85%A8%E8%81%94%E8%B5%9B-%E6%98%A5%E5%AD%A3%E8%B5%9B/index.html
