# Cisticola

> 分类：Crypto

## 题目描述

多项式上的模运算。给 Q（多项式）、pos、hint，key 是第 17 个多项式系数，需求解线性方程组恢复 key 解 AES-CBC。

## 考察知识点

- 多项式模运算
- 线性方程组求解（矩阵方程）

## 解法

1. 用 sage 推导多项式 `hint = Σ poly[i]*x^pos[i] % Q`，得到 429 次多项式。
2. 将同次项系数归类，形成 A/B 矩阵。发现大部分含 8 项的系数与 `a0/a1/a3/a6/a8/a10/a15/a17` 变量有关。
3. 选取 8 组同次项与结果做系数对比，求解矩阵方程：

```python
A = matrix(Zmod(p), A)
B = vector(Zmod(p), B[:8])
sol = A \ B
# (232766905492121523584723111736297361759, ..., 275609957223526193497841020687316070508)
```

4. 得到 `key = a17 = 275609957223526193497841020687316070508`，解 AES：

```python
from Crypto.Util.number import *
from Crypto.Cipher import AES

enc = 'e086deeb9f060c014867c5adbd1ee1b449193b6e6177f58a36948282e1728f3b529b2def3c39f69c7a9001b4cac4d1d5'
key = long_to_bytes(275609957223526193497841020687316070508)
cipher = AES.new(key=key, iv=bytes(range(16)), mode=AES.MODE_CBC)
m = cipher.decrypt(bytes.fromhex(enc))
print(m)
```

## 参考答案

`flag{182273bd-61f2-7147-acd8-d571de11bb40}`

## 来源

- 作者：Lazzaro | https://lazzzaro.github.io/2023/05/19/match-2023%E5%B9%B4%E6%98%A5%E7%A7%8B%E6%9D%AF%E7%BD%91%E7%BB%9C%E5%AE%89%E5%85%A8%E8%81%94%E8%B5%9B-%E6%98%A5%E5%AD%A3%E8%B5%9B/index.html
