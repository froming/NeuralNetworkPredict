# checkin

> 分类：Crypto

## 题目描述

签到题。PELL 方程 + 二项式定理应用。flag 分成两半，分别用 `enc1`、`enc2` 加密。

## 考察知识点

- PELL 方程求解
- 二项式定理（模 n^3）

## 解法

题目满足 `x^2 - D*y^2 == 1`（D=1117），`enc1 = pow(233*n^2+1, part1, n^3)`，`enc2 = pow(y*n+1, part2, n^3)`。

用 sage 解 PELL 方程：

```python
def solve_pell(N, numTry=100):
    cf = continued_fraction(sqrt(N))
    for i in range(numTry):
        denom = cf.denominator(i)
        numer = cf.numerator(i)
        if numer^2 - N*denom^2 == 1:
            return numer, denom
    return None, None

N = 1117
x, y = solve_pell(N)

flag1 = (enc1 - 1) // n**2 * inverse_mod(233, n) % n
flag2 = (enc2 % n**2 - 1) // n * inverse_mod(y, n) % n

print(bytes.fromhex(hex(flag1)[2:]) + bytes.fromhex(hex(flag2)[2:]))
```

原理：`(a*n^2+1)^m mod n^3 = m*a*n^2 + 1`（二项式展开，高阶项模 n^3 为 0）；`(y*n+1)^m mod n^3` 展开，m*y*n 项在 n^2 级别。

## 参考答案

`flag{11e89e28-4e27-47f0-a7c7-8e66c18881be}`

## 来源

- 作者：Lazzaro | https://lazzzaro.github.io/2023/05/19/match-2023%E5%B9%B4%E6%98%A5%E7%A7%8B%E6%9D%AF%E7%BD%91%E7%BB%9C%E5%AE%89%E5%85%A8%E8%81%94%E8%B5%9B-%E6%98%A5%E5%AD%A3%E8%B5%9B/index.html
