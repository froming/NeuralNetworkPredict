# backdoor

> 分类：Crypto

## 题目描述

恶意 ECDH 密钥交换题。题目实现了带后门的 ECDH，`z = (k1 - w*t)*G + (-a*k1 - b)*Y`，通过给出的点还原共享密钥解 AES。

## 考察知识点

- ECDH（椭圆曲线 Diffie-Hellman）
- 椭圆曲线点运算
- AES-ECB 解密

## 解法

题目给出了 `(w,a,b,x)`、`(A,B,P)`、`G`、`M1`、`M2`、`B_` 的坐标。关键推导：

```
z = (k1 - wt)G + (-ak1 - b)Y
  = k1*G - wt*G + (-ak1*Y - b*Y)
  = M1 - w*t*G - a*x*M1 - b*x*G    （Y = x*G, M1 = k1*G）
```

又 `key2 = k2 * B_`（shared_key1 == shared_key2 == k2 * B_），其中 `k2 = sha256(str(z[0]))[:6]`。

```python
w, a, b, x = (31889563, 31153, 28517, 763220531)
A, B, P = (...)
G = (...); M1 = (...); M2 = (...); B_ = (...)
enc = b'...'

E = EllipticCurve(GF(P), [A, B])
G, M1, M2, B_ = [E(_) for _ in [G, M1, M2, B_]]
t = 1
z = M1 - w*t*G - a*x*M1 - b*x*G
k2 = sha256(str(z[0]).encode()).digest()[:6]
k2 = bytes_to_long(k2)
key = k2 * B_

key = md5(str(int(key[0])).encode()).digest()
cipher = AES.new(key, AES.MODE_ECB)
flag = cipher.decrypt(enc)
print(flag)
```

## 参考答案

`flag{63259ab8-4916-4095-8888-d92c2b003e18}`

## 来源

- 作者：Lazzaro | https://lazzzaro.github.io/2023/05/19/match-2023%E5%B9%B4%E6%98%A5%E7%A7%8B%E6%9D%AF%E7%BD%91%E7%BB%9C%E5%AE%89%E5%85%A8%E8%81%94%E8%B5%9B-%E6%98%A5%E5%AD%A3%E8%B5%9B/index.html
