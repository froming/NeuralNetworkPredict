# ecdsa

> 分类：Crypto

## 题目描述

ECDSA 签名题。两个签名用了相差很小的 nonce（`k1 - k2 = Δk` 很小，因为 `gen = lambda: p + getPrime(16)`，两个 k 只有低 16 位素数不同）。

## 考察知识点

- ECDSA（SECP256k1）
- 相同 nonce / 小 Δk 攻击

## 解法

选取标准曲线 SECP256k1，sig = r_str + s_str。

根据式子：
- `s1 ≡ k1^(-1)(z1 + r1*d) (mod n)`
- `s2 ≡ k2^(-1)(z2 + r2*d) (mod n)`

已知 r1,s1,r2,s2,z1,z2，且 `k1 - k2 = Δk` 很小，联立用 Δk 表示 d，再爆破 Δk 值得到正确的 d：

```python
def inv(x): return inverse_mod(x, n)

r1 = int(sig1[:64], 16); s1 = int(sig1[64:], 16)
r2 = int(sig2[:64], 16); s2 = int(sig2[64:], 16)

for dk in range(-2^16, 2^16):
    x = (dk - (inv(s2)*h2 - inv(s1)*h1)) * inv(inv(s2)*r2 - inv(s1)*r1) % n
    if x.nbits() <= 30*8:
        flag = int(sha512(bytes.fromhex(hex(x)[2:])).hexdigest(), 16) ^^ int(enc, 16)
        print(bytes.fromhex(hex(flag)[2:]))
```

## 参考答案

`flag{2f64731e-785b-4259-4566-3d17554bfb7b}`

## 来源

- 作者：Lazzaro | https://lazzzaro.github.io/2023/05/19/match-2023%E5%B9%B4%E6%98%A5%E7%A7%8B%E6%9D%AF%E7%BD%91%E7%BB%9C%E5%AE%89%E5%85%A8%E8%81%94%E8%B5%9B-%E6%98%A5%E5%AD%A3%E8%B5%9B/index.html
