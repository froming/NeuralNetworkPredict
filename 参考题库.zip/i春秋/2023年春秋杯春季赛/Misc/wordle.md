# wordle

> 分类：Misc

## 题目描述

做题累了，跟小楠楠一起玩 wordle 猜词游戏，通关即拿 flag。

## 考察知识点

- 猜词游戏（送分题）

## 解法

wordle 猜词游戏，6 次内猜对一个 5 字母单词即可拿到 flag。纯送分题。

## 参考答案

（flag 通过猜词通关获得）

## 来源

- 作者：Lazzaro | https://lazzzaro.github.io/2023/05/19/match-2023%E5%B9%B4%E6%98%A5%E7%A7%8B%E6%9D%AF%E7%BD%91%E7%BB%9C%E5%AE%89%E5%85%A8%E8%81%94%E8%B5%9B-%E6%98%A5%E5%AD%A3%E8%B5%9B/index.html
