# happy2forensics

> 分类：Misc（取证）

## 题目描述

内存/磁盘取证题。流量包里导出 secret.rar，解压出 bitlocker 加密的磁盘，需提取 bitlocker 密码，并破解 flag2.zip。

## 考察知识点

- 流量分析（HTTP 对象导出）
- BitLocker 加密磁盘解密
- 文件恢复（回收站）
- binwalk / 图片拼接

## 解法

1. 查看流量包 http 对象，导出 `secret.rar`，解压出 `secret.vhdx`（bitlocker 加密磁盘）。
2. 捕获源端口 20、目的端口 80 的 TCP 流量，获得 bitlocker 密码：

```
bitlocker 120483-350966-299189-055297-225478-133463-431684-359403
```

3. 在回收站找到 `flag2.zip`（需密码）。将所有小图片拼接得到 `password: 856a-a56b6a705653`，解压得到 `flag2:-919c-a140d7054ac5`。
4. 一堆小图片中有一个大小不同的 `210-1.png`，binwalk 分解，分解出的 jpg 的 APP1 块里藏有另一个 `FFD8` 头，提取出新的 jpg，得到 `flag1:f97d5b05-d312-46ac`。
5. 合并得到 flag。

## 参考答案

`flag{f97d5b05-d312-46ac-919c-a140d7054ac5}`

## 来源

- 作者：Lazzaro | https://lazzzaro.github.io/2023/05/19/match-2023%E5%B9%B4%E6%98%A5%E7%A7%8B%E6%9D%AF%E7%BD%91%E7%BB%9C%E5%AE%89%E5%85%A8%E8%81%94%E8%B5%9B-%E6%98%A5%E5%AD%A3%E8%B5%9B/index.html
