# snack

> 分类：Reverse

## 题目描述

Python 打包的 exe 逆向题，用 pyinstxtractor 解包，pycdc 反编译，分析发现是 RC4 加密（多了一个异或下标 i）。

## 考察知识点

- PyInstaller 解包（pyinstxtractor）
- pyc 反编译（pycdc）
- RC4 加密逆向（带下标异或变种）

## 解法

1. 查壳发现是 python 打包的 exe，用 pyinstxtractor 解包，找到 `snack.pyc`，用 pycdc 转为 py 文件。
2. 分析代码发现是 RC4 加密，但多了一个异或下标 i 的操作，并 import 了一个 key 模块。
3. 找到 `key.pyc` 转成 py，得到 key 为 `V3rY_v3Ry_Ez`。
4. 写解密脚本（RC4 的逆操作）：

```python
def initialize(key):
    key_length = len(key)
    S = list(range(256))
    j = 0
    for i in range(256):
        j = (j + S[i] + key[i % key_length]) % 256
        S[i], S[j] = S[j], S[i]
    return S

def generate_key_stream(S, length):
    i = 0
    j = 0
    key_stream = []
    for _ in range(length):
        i = (i + 1) % 256
        j = (j + S[i]) % 256
        S[i], S[j] = S[j], S[i]
        key_stream.append(S[(S[i] + S[j]) % 256])
    return key_stream

def decrypt(data, key):
    S = initialize(key)
    key_stream = generate_key_stream(S, len(data))
    decrypted_data = [i ^ data[i] ^ key_stream[i] for i in range(len(data))]
    for i in decrypted_data:
        print(chr(i), end='')
    return decrypted_data

key = [ord(c) for c in "V3rY_v3Ry_Ez"]
data = [101, 97, 39, 125, 218, 172, 205, 3, 235, 195, 72, 125, 89, 130, 103, 213,
        120, 227, 193, 67, 174, 71, 162, 248, 244, 12, 238, 92, 160, 203, 185, 155]
decrypted = decrypt(data, key)
```

## 参考答案

（flag 由解密脚本输出）

## 来源

- 作者：花草木_逆向小白 | https://blog.csdn.net/qq_67760645/article/details/140244620
