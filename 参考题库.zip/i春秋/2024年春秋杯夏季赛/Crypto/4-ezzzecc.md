# 4-ezzzecc

> 分类：Crypto

## 题目描述

椭圆曲线（ECC）题，给定椭圆曲线参数 a、b，基点 G、公钥 K、两个密文点 c1、c2，以及两个密文整数 cipher_left、cipher_right，要求还原明文 m。

## 考察知识点

- 椭圆曲线（EllipticCurve）
- 求曲线模数 p（gcd 技巧）
- 爆破临时密钥 k

## 解法

1. 利用两个点都在同一曲线上，通过 `gcd` 求模数 p：

```python
l = K[0]**3 + a*K[0] + b - K[1]**2
w = G[0]**3 + a*G[0] + b - G[1]**2
p = gmpy2.gcd(l, w)
```

2. 在 GF(p) 上构造椭圆曲线，爆破临时密钥 k：

```python
E = EllipticCurve(GF(p), [a, b])
c1 = E(c1); c2 = E(c2); G = E(G)
# 爆破 k（k 为素数），使 y = k*G 的 x 坐标等于 K[0]
k = 166909
```

3. 还原明文：

```python
m = c1 - c2 * k
flag = long_to_bytes((cipher_left * inverse(int(m[0]), p)) % p) + long_to_bytes((cipher_right * inverse(int(m[1]), p)) % p)
```

## 参考答案

`flag{2d6a7e4e-02d3-11ef-8836-a4b1c1c5a2d2}`

## 来源

- 作者：花草木_逆向小白 | https://blog.csdn.net/qq_67760645/article/details/140244620
