# Master of DFIR - Coffee

> 分类：Misc

## 题目描述

数字取证。木马通过 WebSocket 传输 AES 加密数据，解密得到主机名、文件名、tomcat 凭证；上传的 war 包含 jsp 加载恶意字节码，找到加解密密钥后解密流量，从 SQLite 数据库找到云存储管理员账户，挖矿配置得到矿池域名。

## 考察知识点

- WebSocket AES 流量解密
- war 包 / jsp 字节码分析
- SQLite 数据库取证
- 挖矿木马 / 计划任务分析

## 解法

1. 木马通过 WebSocket 用 AES 加密传输数据，找到 SystemId，解密得到主机名、下载保存文件名、攻击者上传文件名、tomcat 用户名密码。
2. 上传的 war 包含 jsp 加载字节码（多个 class，第二个 class 为加解密密钥）。
3. 用 CyberChef 解密流量：`From_Base64 → XOR('2ca9b43c1b8ef8c8') → AES_Decrypt('b42e327feb5d923b', ECB/NoPadding) → Zlib_Inflate`。
4. 流量中下载 SQLite 数据库，找到浩瀚云云存储管理员账户和密码哈希（cmd5 可查）。
5. 恶意 powershell 脚本设置计划任务，挖矿配置文件得到回连矿池域名。

## 参考答案

（答案通过 nc 交互提交，含多个取证结论）

## 来源

- 作者：or4nge | https://cn-sec.com/archives/3364589.html
