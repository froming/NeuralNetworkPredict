# pickle_jail

> 分类：Misc

## 题目描述

Python pickle 反序列化 jail。传入 0xfe 长度的 name，利用 +1 取余改变序列化后 name 长度，把 name 内容识别为控制符，通过 pickle 控制符构造栈操作逐字符爆破 flag。

## 考察知识点

- pickle 反序列化（栈操作、控制符）
- 逐字符爆破

## 解法

1. 传入 0xfe 长度的 name，`+1` 取余后序列化长度变 0x00，使 name 内容被识别为 pickle 控制符。
2. 将 name pop 出来，把要爆破的字符串入栈，用 B 控制符把 name_list 和 flag 拼接。
3. 用 flag 结尾的 `}` 作为控制符入栈空字典，最后栈内容为 `(b'flag{xxx', b'CAlicex94...flag{....', {})`。
4. 利用 `if name in players` 逐字符爆破 flag。

## 参考答案

（flag 通过 pickle 栈操作逐字符爆破）

## 来源

- 作者：or4nge | https://cn-sec.com/archives/3364589.html
