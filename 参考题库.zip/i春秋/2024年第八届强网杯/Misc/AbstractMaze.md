# AbstractMaze

> 分类：Misc

## 题目描述

抽象迷宫题，共 5 关（challenge1-5），需要根据机器人寻路策略（优先下右上左 / 贴墙走等）构造墙让程序认为路径为 badpath 或铺满屏幕。

## 考察知识点

- 寻路算法逆向（BFS / 左拐右拐 / 贴墙）
- 交互解题

## 解法

1. challenge1：空的就能过。
2. challenge2：机器人优先下右上左，保证 p1/p2 路径长相同，堵住 (2,2) 每个向下再返回路径的返回位置使其成为 badpath。
3. challenge3：优先向下。
4. challenge4：p1 左拐、p2 右拐，描点找够长路线。
5. challenge5：贴墙走，构造黑色墙铺满整个屏幕（返回色块与来向色块重合）。

## 参考答案

（通过构造墙完成 5 关）

## 来源

- 作者：or4nge | https://cn-sec.com/archives/3364589.html
