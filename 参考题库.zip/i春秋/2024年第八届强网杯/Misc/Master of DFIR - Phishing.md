# Master of DFIR - Phishing

> 分类：Misc

## 题目描述

数字取证。钓鱼邮件解出加密压缩包，其中是伪装的 msc 文件（VBScript 加载恶意 dll），解密下一阶段载荷（远程下载 donut 木马），从流量中 dump 木马并用 donut-decryptor 解密，找到 C2（OrcaC2）及 AES 密钥。

## 考察知识点

- 邮件/压缩包取证
- msc 文件 + VBScript 分析
- MITRE ATT&CK T1574（DLL 侧加载）
- donut 木马解密（donut-decryptor）
- C2 分析

## 解法

1. 从钓鱼邮件解出压缩包密码（攻击者邮箱），得到伪装 msc 文件，第 97 行为 VBScript 执行语句。
2. VBScript 解混淆，恶意 dll 加载位置为 `/MMC_ConsoleFile/BinaryStorage/Binary[@Name='CONSOLE_MENU']`，对应 MITRE ATT&CK T1574。
3. `curl_easy_init` 被修改，解密下一阶段载荷的 key 在 `sub_10001240`，dump 数据后用脚本解密。
4. 下一阶段载荷远程下载 donut 木马，从流量 dump 下来用 donut-decryptor 解密。
5. 反编译发现 decrypt key `pJB`-v)t^ZAsP$|r`，AES 加密，C2 为 OrcaC2。

## 参考答案

（答案通过 nc 交互提交，含多个取证结论）

## 来源

- 作者：or4nge | https://cn-sec.com/archives/3364589.html
