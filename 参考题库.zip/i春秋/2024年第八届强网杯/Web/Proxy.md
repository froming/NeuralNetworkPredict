# Proxy

> 分类：Web

## 题目描述

Go/Gin 服务。`/v1/api/flag` 会执行 `/readflag` 命令，但 nginx 只代理 `/v2` 且 `/v1` 返回 403。利用 `/v2/api/proxy` 的 SSRF 代理请求到本地 `/v1/api/flag` 拿到 flag。

## 考察知识点

- Go Gin + 反向代理 SSRF
- HTTP 代理转发

## 解法

1. 审计 `main.go`：`/v1/api/flag` 执行 `/readflag` 返回 flag，但 `proxy.conf` 中 `/v1` 直接 403，仅 `/v2` 代理到 `localhost:8769`。
2. 用 `/v2/api/proxy` 构造 SSRF 请求到本地 v1：

```json
{
    "url": "http://127.0.0.1:8769/v1/api/flag",
    "method": "POST",
    "follow_redirects": true
}
```

3. 返回 base64 编码的 flag，解码即可。

## 参考答案

`flag{b4531b99-5a58-44f3-8a09-0f7069996c2a}`

## 来源

- 作者：H@yn3$ | https://blog.hayneschen.top/CTF/2024-第八届强网杯.html
- 作者：yemaster | https://blog.yemaster.cn/post/123
- 作者：or4nge | https://cn-sec.com/archives/3364589.html
- 作者：狼组安全团队 | https://cn-sec.com/archives/3354853.html
