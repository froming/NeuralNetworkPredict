# GiveMeSecret

> 分类：Web

## 题目描述

AI 大模型 prompt injection 题，通过与 AI 聊天忽悠它忘记系统 prompt，套出 flag。

## 考察知识点

- Prompt Injection（大模型攻防）

## 解法

经典大模型忽悠方式，让 AI 忘记初始 prompt 指令（例如"奶奶哄睡战术"），逐步套出 secret。

## 参考答案

（flag 通过 prompt injection 套出）

## 来源

- 作者：H@yn3$ | https://blog.hayneschen.top/CTF/2024-第八届强网杯.html
- 作者：or4nge | https://cn-sec.com/archives/3364589.html
- 作者：狼组安全团队 | https://cn-sec.com/archives/3354853.html
