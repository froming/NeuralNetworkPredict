# PyBlockly

> 分类：Web

## 题目描述

用 Python 模拟 Scratch Web IDE，把 blockly JSON 转成 Python 代码执行。黑名单过滤特殊字符，但用 unidecode 可用全角字符绕过；另有 audit hook 限制 event_name 长度，重写 len 函数绕过。flag 无权限，用 SUID 的 dd 读取。

## 考察知识点

- blockly 转 Python 代码执行
- unidecode 全角字符绕过黑名单
- Python audit hook 绕过（重写 len）
- SUID 提权（dd 读 flag）

## 解法

1. 黑名单 `blacklist_pattern` 过滤 ASCII 特殊字符，但 text 块用 `unidecode.unidecode()` 把 Unicode 转 ASCII，全角字符可绕过。
2. 闭合单引号注入代码，重写 `len` 绕过 audit hook 的长度限制：

```python
__builtins__.len = lambda x: 0
__import__('os').system('...')
```

3. 用类似 SSTI 的 payload 拿 os.system（`_wrap_close` 类）。
4. `/flag` 无权限，`find / -perm -u=s` 发现 dd 有 SUID，用 `dd if=/flag` 读取。

## 参考答案

`flag{7c1a4fe8981e295a78508a49146340b9}`

## 来源

- 作者：yemaster | https://blog.yemaster.cn/post/123
- 作者：H@yn3$ | https://blog.hayneschen.top/CTF/2024-第八届强网杯.html
- 作者：or4nge | https://cn-sec.com/archives/3364589.html
- 作者：星盟安全团队 | https://blog.xmcve.com/2024/11/04/强网杯2024-Writeup/
- 作者：狼组安全团队 | https://cn-sec.com/archives/3354853.html
