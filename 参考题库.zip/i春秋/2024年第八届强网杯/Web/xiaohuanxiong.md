# xiaohuanxiong

> 分类：Web

## 题目描述

小浣熊 CMS（xiaohuanxiong）。部分 admin 路由未授权，直接进入后台在支付设置处写入 PHP 代码，蚁剑连接 getshell 读 flag。

## 考察知识点

- 后台未授权访问
- 网站配置写入 webshell
- 蚁剑连接

## 解法

1. Github：https://github.com/forkable/xiaohuanxiong
2. `/admin/admins` 路由未授权，可直接添加管理员账号进入后台。
3. `/admin/payment/index.html` 支付设置可修改 PHP 代码，写入一句话木马（写入 `config/payment.php`）。
4. 用蚁剑连接，在根目录找到 flag 文件。

## 参考答案

（flag 通过蚁剑连接读取）

## 来源

- 作者：yemaster | https://blog.yemaster.cn/post/123
- 作者：or4nge | https://cn-sec.com/archives/3364589.html
- 作者：星盟安全团队 | https://blog.xmcve.com/2024/11/04/强网杯2024-Writeup/
- 作者：狼组安全团队 | https://cn-sec.com/archives/3354853.html
