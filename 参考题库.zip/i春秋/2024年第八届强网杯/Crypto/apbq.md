# apbq

> 分类：Crypto

## 题目描述

多阶段 RSA。stage1 泄露 p+q，可求 phi 得私钥；stage2 泄露 ap+bq，参考 DUCTF 2023 apbq-rsa-ii 解题；stage3 复用 stage2 私钥解密。

## 考察知识点

- RSA（p+q 泄露）
- ap+bq 泄露（参考 DUCTF apbq-rsa-ii）
- 私钥复用

## 解法

1. stage1：已知 `hints = p + q`，`phi = n - hints + 1`，求 d 解出第一部分 flag `flag{yOu_can_`。
2. stage2：泄露 `ai*p + bi*q`，参考 https://github.com/DownUnderCTF/Challenges_2023_Public/blob/main/crypto/apbq-rsa-ii/solve/solv.sage 构造格/方程组求 p、q。
3. stage3：直接复用 stage2 的私钥解密。

## 参考答案

（flag 通过三阶段解密拼出）

## 来源

- 作者：or4nge | https://cn-sec.com/archives/3364589.html
- 作者：狼组安全团队 | https://cn-sec.com/archives/3354853.html
