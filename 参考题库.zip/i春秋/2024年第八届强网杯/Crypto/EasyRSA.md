# EasyRSA

> 分类：Crypto

## 题目描述

common prime RSA（共素数 RSA）。`g` 已知，`N = 2*h*g+1` 且 `h = 2*g*a*b + a + b`。参考 common-prime-rsa 的攻击方法，用 bsgs 求 c 后分解 N。

## 考察知识点

- common prime RSA 分解
- baby-step giant-step（bsgs）
- sage

## 解法

1. 由 `N = 2*h*g+1`，令 `M = (N-1)/(2*g) = 2*g*a*b + a + b`。
2. `u = M//(2*g)`，`v = M - 2*g*u`，则 `ab = u - c`，`a+b = v + 2*g*c`。
3. sage 中用 bsgs 求 c（c 范围接近 N^(0.5-2*gamma)）：

```python
nbits = 2048
gamma = 0.244
cbits = ceil(nbits * (0.5 - 2 * gamma))
M = (N - 1) // (2 * g)
u = M // (2 * g)
v = M - 2 * g * u
GF = Zmod(N)
x = GF.random_element()
y = x ^ (2 * g)
c = bsgs(y, y ^ u, (Integer(2**(cbits-1)), Integer(2**(cbits+1))))
ab = u - c
apb = v + 2 * g * c
P.<x> = ZZ[]
f = x ^ 2 - apb * x + ab
a = f.roots()
a, b = a[0][0], a[1][0]
p = 2 * g * a + 1
q = 2 * g * b + 1
d = gmpy2.invert(65537, (p-1)*(q-1))
print(long_to_bytes(pow(enc, d, N)))
```

## 参考答案

`flag{819fbbea-be48-405b-8d63-d2e1ed26ddcb}`

## 来源

- 作者：or4nge | https://cn-sec.com/archives/3364589.html
- 作者：狼组安全团队 | https://cn-sec.com/archives/3354853.html
