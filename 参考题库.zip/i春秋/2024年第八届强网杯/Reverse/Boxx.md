# Boxx

> 分类：Reverse

## 题目描述

推箱子游戏。逆向 dump 出 map，最后四个地图可看出是 `qwb!`，脚本解单箱子最少步数，多箱子手动玩。

## 考察知识点

- 逆向 dump 地图
- 推箱子最少步数求解

## 解法

1. 逆向 dump 出所有地图，最后四个地图是 `qwb!`。
2. 写 BFS/A* 脚本解单个箱子的最少次数，多个箱子的手动玩。

## 参考答案

`flag{qwb!_d9dfb57a206f4008838417e2b0f88a43}`

## 来源

- 作者：or4nge | https://cn-sec.com/archives/3364589.html
