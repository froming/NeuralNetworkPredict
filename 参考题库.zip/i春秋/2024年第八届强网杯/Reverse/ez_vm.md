# ez_vm

> 分类：Reverse

## 题目描述

基于堆栈的虚拟机，trace + 手撕流程。最终 table 存在多解情况需爆破（加 break 解决）。

## 考察知识点

- 虚拟机逆向（trace）
- 反查表爆破

## 解法

1. trace 虚拟机，手撕基于堆栈的流程。
2. 用反查表（reversetable）逐字节反查密文。
3. table 存在多解，爆破时加 break 解决。

```cpp
for (int i = 0; i < 16; i++) {
    reversetable1 = 0x9000 + (numbertable + 0x100*i);
    for (int j = 0; j < 256; j++) {
        if (reversetable1[j] == testenc[i]) { testenc[i] = j; break; }
    }
}
```

## 参考答案

（flag 通过 trace + 反查表爆破得到）

## 来源

- 作者：星盟安全团队 | https://blog.xmcve.com/2024/11/04/强网杯2024-Writeup/
