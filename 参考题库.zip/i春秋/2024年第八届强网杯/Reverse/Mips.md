# Mips

> 分类：Reverse

## 题目描述

Qemu MIPS 虚拟机逆向。qemu 跑有假 opcode 出假 flag，真 flag 藏在 `/emu` 的加密逻辑里（RC4 + 异或位移混合加密）。去花指令后解密。

## 考察知识点

- Qemu MIPS 虚拟机逆向
- 花指令去除
- 魔改 RC4 解密 + 位移交换

## 解法

1. 编译带符号 qemu 对比找关键逻辑，`sub_7F50E936448E` 为实际加密过程。
2. 两段加密逻辑：0x3DE7A9 和 0x33D8E0（RC4），去花指令后分析。
3. RC4 魔改：`data[t] ^= S[(S[i]+S[j])%256] ^ keyb[t&3]`，再加多段位移/异或混淆（`<<5 ^ 0xDE`、`<<4 ^ 0xAD`、`<<3 ^ 0xBE` 等）。
4. 位移加密为 data[7]/[11]、[12]/[16] 互换，异或单字节爆破。
5. 解密脚本（RC4 + 爆破异或值）输出 flag。

## 参考答案

`flag{QeMu_r3v3rs3in9_h@ck6}`

## 来源

- 作者：or4nge | https://cn-sec.com/archives/3364589.html
- 作者：狼组安全团队 | https://cn-sec.com/archives/3354853.html
- 作者：星盟安全团队 | https://blog.xmcve.com/2024/11/04/强网杯2024-Writeup/
