# chat-with-me

> 分类：Pwn

## 题目描述

类似 vector 的堆题，容量满后 free 再 malloc。存在任意地址 free，把 input buffer free 进 control struct，使其可控，泄露堆、栈地址实现任意地址读写，最终 tcache hijacking + ROP。

## 考察知识点

- 任意地址 free
- tcache hijacking
- 堆/栈/libc 地址泄露
- ROP

## 解法

1. 任意地址 free，把 message 数组 chunk 释放使其携带 libc 信息，用 show 泄露 libc 地址。
2. 在 IO 缓冲区构造 size 0x31 的 chunk 并 free，改 size 为 0x101 劫持 tcache->next。
3. 下一次输入拿出 chunk，释放到 0x101 tcache，劫持目标地址。
4. 最后一次输入构造 ROP 链（pop rdi + "/bin/sh" + system）。

```python
edit(0x80, cyclic(0x20) + p64(0) + p64(0x101) + p64(((heap_addr) >> 12) ^ (stack_addr-0xd8)))
sh.sendline(flat([0, libc_addr + 0x10f75b, libc_addr + 0x1cb42f, libc_addr + 0x582c0 + 2]))
```

## 参考答案

（flag 通过 ROP 拿 shell 读取）

## 来源

- 作者：or4nge | https://cn-sec.com/archives/3364589.html
- 作者：星盟安全团队 | https://blog.xmcve.com/2024/11/04/强网杯2024-Writeup/
