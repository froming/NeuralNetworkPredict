# expect_number

> 分类：Pwn

## 题目描述

有一个栈溢出 backdoor 和 try catch 后门。game_struct 可溢出到后续结构体虚表指针，把低地址盖成 0x60（倒推可推出伪随机序列），栈溢出覆盖返回地址，利用 try catch 执行后门 getshell。

## 考察知识点

- 结构体越界溢出（虚表指针覆盖）
- 栈溢出
- C++ 异常处理（try catch）劫持

## 解法

1. 逆向 game_obj 结构体，发现 pos 边界判断错误导致 game_obj 对象溢出，可改写函数表。
2. 把函数表改为 0x4C60 处的（含栈溢出的函数）。
3. 函数使用 C++ 异常处理，getInt 输入函数中的异常处理直接是 backdoor 调用，把异常处理函数地址覆盖为 `elf_base + 0x251A`。
4. 用 libc.srand(1) 倒推伪随机序列，控制溢出，触发异常 getshell。

```python
libc = cdll.LoadLibrary('/lib/x86_64-linux-gnu/libc.so.6')
libc.srand(1)
# 按 rand()%4+1 控制 game 运算，把虚表指针低地址盖成 0x60
sla(b'choice \n', b'4')
sla(b'Tell me your favorite number.\n', b'a'*0x20 + p64(bss) + p64(elf_base + 0x251A))
```

## 参考答案

（flag 通过触发 backdoor getshell 读取）

## 来源

- 作者：or4nge | https://cn-sec.com/archives/3364589.html
- 作者：星盟安全团队 | https://blog.xmcve.com/2024/11/04/强网杯2024-Writeup/
