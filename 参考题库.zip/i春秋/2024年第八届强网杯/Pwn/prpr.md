# prpr

> 分类：Pwn

## 题目描述

通过注册一系列 printf 处理函数实现了一个虚拟机。漏洞在 mem_and/mem_xor/mem_or 循环终止条件不正确（字符串未被 \0 截断则继续循环覆盖后续数据），可覆盖 return_addr 实现 PC 任意控制，再泄漏堆/ELF/libc 地址，分段读入 ROP 打任意地址读写。

## 考察知识点

- 虚拟机逆向（printf 处理函数注册）
- 循环未截断导致的溢出
- 任意地址读写 + ROP

## 解法

1. 翻译虚拟机指令（250 条），定位 6 个功能，发现 mem_and/xor/or 循环终止条件错误，字符串未 \0 截断则继续覆盖后续数据。
2. 先用功能4（依次异或）填满 memory buf，再用功能3触发未截断循环覆盖 return_addr 为 `50`（`call 60`）。
3. `call 60` 中 r5=0x40，可输入任意数据覆盖 return_addr，实现 pc 任意可控。
4. 伪造虚拟机指令结构体，泄漏堆/ELF 地址（free got），分段读入 ROP。
5. 改 regs 指针结合 push_r 实现任意地址读写，泄漏 environ 得栈地址，用 pop_r 任意写栈，`pop rsp; ret` 到 ROP 执行 orw。

## 参考答案

（flag 通过 ROP orw 读取）

## 来源

- 作者：星盟安全团队 | https://blog.xmcve.com/2024/11/04/强网杯2024-Writeup/
