# baby_heap

> 分类：Pwn

## 题目描述

GLIBC 2.35 堆题，5 个堆块打 large bin attack 修改 `_IO_list_all`，用 `_IO_wfile_jumps_maybe_mmap` 表执行 `_IO_wfile_overflow`，配合 setcontext 构造 openat2 orw 读 flag。

## 考察知识点

- large bin attack
- FSOP（_IO_wfile_jumps_maybe_mmap）
- setcontext
- orw（openat2）

## 解法

1. 5 个堆块（>0x500），large bin attack 修改 `_IO_list_all` 为堆地址（fake IO）。
2. `_IO_wfile_jumps` 表为空，用 `_IO_wfile_jumps_maybe_mmap` 表执行 `_IO_wfile_overflow`。
3. 构造 fake IO 结构体，用 setcontext 跳转 ROP：mprotect 赋予堆段执行权限，再 openat2 orw 读 flag。

```python
pl = p64(0)*3 + p64(IO_list_all-0x20) + ...
pl += p64(setcontext) + ...
pl += p64(rdi) + p64(heap_base >> 12 << 12) + p64(rsi) + p64(0x2000) + p64(rdx_r12) + p64(7)*2 + p64(mprotect) + p64(heap_base + 0x1b60)
pl += asm('mov rax, 0x67616c66; ...')  # openat2 + read/write
```

（另有非预期：用 putenv 触发 `__strncmp_avx2`，改 got 为 printf 泄露环境变量 flag）

## 参考答案

`flag{648fed8f-4c88-4f72-a855-ad444999afbc}`

## 来源

- 作者：星盟安全团队 | https://blog.xmcve.com/2024/11/04/强网杯2024-Writeup/
- 作者：狼组安全团队 | https://cn-sec.com/archives/3354853.html
